package com.minipc.desktop.ui.startmenu

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.domain.model.AppInfo
import com.minipc.desktop.domain.usecase.FuzzyMatcher
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.theme.Accent
import com.minipc.desktop.ui.theme.Brand
import com.minipc.desktop.ui.theme.Navy
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon

/** Ngăn "Ứng dụng": bảng bên trái, có tìm kiếm mờ, công cụ tích hợp, kéo ra Desktop. */
@Composable
fun StartMenu(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val dd = LocalDragDrop.current
    // Giữ composition khi đang kéo (nếu bỏ, cử chỉ kéo bị huỷ) – chỉ làm trong suốt.
    val visible = state.startOpen || dd.payload is DragPayload.App || dd.payload is DragPayload.Tool
    AnimatedVisibility(
        visible, modifier,
        enter = slideInHorizontally { -it / 4 } + fadeIn(),
        exit = slideOutHorizontally { -it / 4 } + fadeOut()
    ) {
        Box(
            Modifier.fillMaxSize().alpha(if (dd.active) 0f else 1f).clip(RoundedCornerShape(24.dp)).background(Color(0xF21A2035))
                .pointerInput(Unit) { detectTapGestures { } }
        ) { DrawerContent(state, onIntent) }
    }
}

@Composable
private fun DrawerContent(state: DesktopState, onIntent: (DesktopIntent) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, state.apps) { FuzzyMatcher.search(query, state.apps) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ứng dụng", color = Color.White, fontSize = 30.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.Refresh, null, tint = Color(0xFF9AA4C0),
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).clickable { onIntent(DesktopIntent.RefreshApps) }.padding(9.dp))
            Icon(Icons.Filled.Close, null, tint = Color(0xFF9AA4C0),
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).clickable { onIntent(DesktopIntent.CloseOverlays) }.padding(9.dp))
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x1FFFFFFF)).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = Color(0xFF9AA4C0), modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text("Tìm ứng dụng…", color = Color(0xFF7D87A5), fontSize = 17.sp)
                BasicTextField(
                    query, { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 17.sp), cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { results.firstOrNull()?.let { onIntent(DesktopIntent.LaunchApp(it.packageName)) } }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (query.isBlank()) {
                item(span = { GridItemSpan(maxLineSpan) }) { Section("Công cụ ${Brand.NAME}") }
                items(Tool.values().toList(), key = { "t_" + it.key }) { ToolTile(it, onIntent) }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column { Spacer(Modifier.height(8.dp)); Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x1FFFFFFF))); Section("Trên máy") }
                }
            }
            if (state.apps.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Accent, strokeWidth = 2.dp, modifier = Modifier.size(36.dp))
                }
            }
            items(results, key = { it.packageName }) { AppTile(it, state, onIntent) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.TouchApp, null, tint = Color(0xFF7D87A5), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Nhấn giữ và kéo ra desktop", color = Color(0xFF7D87A5), fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(Brand.NAME, color = Color(0xFF9AA4C0), fontSize = 13.sp)
        }
    }
}

@Composable
private fun Section(t: String) = Text(t, color = Color(0xFF9AA4C0), fontSize = 15.sp, modifier = Modifier.padding(vertical = 10.dp))

@Composable
private fun ToolTile(tool: Tool, onIntent: (DesktopIntent) -> Unit) {
    val dd = LocalDragDrop.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .dragSource(dd, DragPayload.Tool(tool.key, tool.label))
            .pointerInput(tool.key) { detectTapGestures(onTap = { onIntent(DesktopIntent.OpenInternal(tool.kind)) }) }
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ToolIcon(tool, 54.dp)
        Spacer(Modifier.height(6.dp))
        Text(tool.label, color = Color.White, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
private fun AppTile(app: AppInfo, state: DesktopState, onIntent: (DesktopIntent) -> Unit) {
    val dd = LocalDragDrop.current
    val overlay = LocalOverlay.current
    val onDock = state.pinned.any { it.packageName == app.packageName && it.onDock }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .dragSource(dd, DragPayload.App(app.packageName, app.label))
            .pointerInput(app.packageName) { detectTapGestures(onTap = { onIntent(DesktopIntent.LaunchApp(app.packageName)) }) }
            .secondaryClick { pos ->
                overlay.showMenu(pos, listOf(
                    MenuItem("Mở cửa sổ") { onIntent(DesktopIntent.LaunchApp(app.packageName)) },
                    MenuItem("Mở toàn màn hình") { onIntent(DesktopIntent.LaunchApp(app.packageName, true)) },
                    MenuItem(if (onDock) "Bỏ ghim khỏi Dock" else "Ghim lên Dock") {
                        onIntent(if (onDock) DesktopIntent.UnpinDock(app.packageName) else DesktopIntent.PinDock(app.packageName))
                    },
                    MenuItem("Thông tin ứng dụng") { onIntent(DesktopIntent.AppInfoScreen(app.packageName)) }
                ))
            }.padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app.packageName, 50.dp)
        Spacer(Modifier.height(6.dp))
        Text(app.label, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 15.sp)
    }
}
