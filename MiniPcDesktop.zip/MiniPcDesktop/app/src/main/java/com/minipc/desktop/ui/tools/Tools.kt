package com.minipc.desktop.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import com.minipc.desktop.ui.InternalKind

/** Công cụ tích hợp – chạy trong cửa sổ nội bộ có thanh tiêu đề riêng. */
enum class Tool(val key: String, val label: String, val color: Color, val icon: ImageVector, val kind: InternalKind) {
    NOTES("notes", "Ghi chú", Color(0xFFE9A24E), Icons.Filled.EditNote, InternalKind.NOTES),
    SETTINGS("settings", "Cài đặt", Color(0xFF5B8DEF), Icons.Filled.Settings, InternalKind.SETTINGS),
    SHIZUKU("shizuku", "Shizuku", Color(0xFF3FB59A), Icons.Filled.Link, InternalKind.SHIZUKU),
    ABOUT("about", "Thông tin", Color(0xFF9B7BDC), Icons.Filled.DesktopWindows, InternalKind.ABOUT),
    FILES("files", "Tệp", Color(0xFFE5B84B), Icons.Filled.Folder, InternalKind.FILES),
    TASKS("tasks", "Tác vụ", Color(0xFF55B36B), Icons.Filled.Speed, InternalKind.TASKS);

    companion object {
        fun fromKey(k: String?) = values().firstOrNull { it.key == k }
        fun fromKind(k: InternalKind) = values().first { it.kind == k }
    }
}

@Composable
fun ToolIcon(tool: Tool, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(size * 0.28f))
            .background(Brush.verticalGradient(listOf(tool.color, tool.color.copy(alpha = 0.72f)))),
        contentAlignment = Alignment.Center
    ) { Icon(tool.icon, null, tint = Color.White, modifier = Modifier.size(size * 0.52f)) }
}
