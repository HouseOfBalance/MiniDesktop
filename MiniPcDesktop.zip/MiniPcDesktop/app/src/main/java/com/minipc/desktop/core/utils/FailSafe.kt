package com.minipc.desktop.core.utils

import com.minipc.desktop.core.shizuku.DpiScaler
import com.minipc.desktop.core.shizuku.ShellExecutor
import javax.inject.Inject
import javax.inject.Singleton

/** Cơ chế cứu hộ: crash handler + khôi phục khẩn cấp. Chỉ động tới DPI khi app thực sự đang áp dụng DPI Desktop. */
@Singleton
class FailSafe @Inject constructor(
    private val shell: ShellExecutor,
    private val dpi: DpiScaler
) {
    fun installCrashHandler() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            restoreBlocking()
            prev?.uncaughtException(t, e)
        }
    }

    /** Đồng bộ, không phụ thuộc hàng đợi/coroutine (an toàn khi crash hoặc onDestroy). */
    fun restoreBlocking() {
        if (!dpi.active) return
        shell.oneShotBlocking("${dpi.restoreCommand}; ${dpi.clearMarkerCommand}; settings put secure show_ime_with_hard_keyboard 1")
        dpi.active = false
    }

    suspend fun panicRestore() {
        dpi.restore()
        shell.exec("settings put secure show_ime_with_hard_keyboard 1")
    }
}
