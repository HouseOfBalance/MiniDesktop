package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.*
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.common.LocalOverlay
import com.minipc.desktop.ui.common.MenuItem

/** 8.2 – Cụm nút nổi căn chỉnh nhanh cửa sổ đang active. */
@Composable
fun WindowHelperOverlay(visible: Boolean, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    if (!visible) return
    val overlay = LocalOverlay.current
    var quarterPos by remember { mutableStateOf(Offset.Zero) }
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC1C1F24)).padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Btn(Icons.Filled.West) { onIntent(DesktopIntent.Snap(SnapRegion.LEFT)) }
        Btn(Icons.Filled.East) { onIntent(DesktopIntent.Snap(SnapRegion.RIGHT)) }
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).onGloballyPositioned { quarterPos = it.positionInRoot() }
                .clickable {
                    overlay.showMenu(quarterPos.copy(y = quarterPos.y - 190f), listOf(
                        MenuItem("Góc trên trái") { onIntent(DesktopIntent.Snap(SnapRegion.TOP_LEFT)) },
                        MenuItem("Góc trên phải") { onIntent(DesktopIntent.Snap(SnapRegion.TOP_RIGHT)) },
                        MenuItem("Góc dưới trái") { onIntent(DesktopIntent.Snap(SnapRegion.BOTTOM_LEFT)) },
                        MenuItem("Góc dưới phải") { onIntent(DesktopIntent.Snap(SnapRegion.BOTTOM_RIGHT)) }
                    ))
                },
            contentAlignment = Alignment.Center
        ) { Text("¼", color = Color.White, fontSize = 14.sp) }
        Btn(Icons.Filled.CropSquare) { onIntent(DesktopIntent.Snap(SnapRegion.MAXIMIZE)) }
        Btn(Icons.Filled.Remove) { onIntent(DesktopIntent.ShowDesktop) }
        Btn(Icons.Filled.Close) { onIntent(DesktopIntent.CloseActiveWindow) }
    }
}

@Composable
private fun Btn(icon: ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}
