package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.InternalKind
import com.minipc.desktop.ui.common.AppIcon
import com.minipc.desktop.ui.common.LocalOverlay
import com.minipc.desktop.ui.common.MenuItem
import com.minipc.desktop.ui.common.secondaryClick
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon

/** Stage Manager: dải cửa sổ đang ẩn ở mép trái; chạm để đưa lên sân khấu, chuột phải để gộp/đóng. */
@Composable
fun StageStrip(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    if (!state.stageEnabled) return
    val hidden = state.internalWindows.filter { it.minimized }
    if (hidden.isEmpty()) return
    val overlay = LocalOverlay.current
    Column(modifier.width(92.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        hidden.take(6).forEach { w ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xF21A2035))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
                    .clickable { onIntent(DesktopIntent.StageSwap(w.id)) }
                    .secondaryClick { pos ->
                        overlay.showMenu(pos, listOf(
                            MenuItem("Đưa lên sân khấu") { onIntent(DesktopIntent.StageSwap(w.id)) },
                            MenuItem("Thêm vào stage hiện tại") { onIntent(DesktopIntent.StageSwap(w.id, true)) },
                            MenuItem("Đóng cửa sổ") { onIntent(DesktopIntent.CloseInternal(w.id)) }
                        ))
                    }.padding(vertical = 10.dp, horizontal = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (w.kind == InternalKind.APP && w.pkg != null) AppIcon(w.pkg, 40.dp) else ToolIcon(Tool.fromKind(w.kind), 40.dp)
                Spacer(Modifier.height(4.dp))
                Text(w.title ?: Tool.fromKind(w.kind).label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
