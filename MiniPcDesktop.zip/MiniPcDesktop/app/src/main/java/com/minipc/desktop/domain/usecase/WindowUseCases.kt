package com.minipc.desktop.domain.usecase

import com.minipc.desktop.core.shizuku.ShellExecutor
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.core.window.WindowMath
import com.minipc.desktop.core.window.WindowTracker
import com.minipc.desktop.data.db.AppBoundsDao
import com.minipc.desktop.data.db.AppBoundsEntity
import com.minipc.desktop.data.db.ShortcutDao
import com.minipc.desktop.domain.model.Bounds
import com.minipc.desktop.domain.model.ScreenMetrics
import com.minipc.desktop.domain.model.WindowInfo
import kotlinx.coroutines.delay
import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/**
 * 8.1 – Mở app như một cửa sổ desktop thật.
 * Cách 1 (chính): startActivity kèm ActivityOptions(launchBounds + windowingMode=FREEFORM) → hệ thống đặt cửa sổ
 * đúng khung ngay từ đầu, KHÔNG bao giờ chui dưới taskbar. Cách 2: `am start --windowingMode 5` rồi `am task resize`.
 */
class LaunchAppUseCase @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val shell: ShellExecutor,
    private val tracker: WindowTracker,
    private val boundsDao: AppBoundsDao,
    private val shortcutDao: ShortcutDao
) {
    /** @return true nếu app chạy ở chế độ Freeform (hoặc không xác định được). */
    suspend operator fun invoke(component: String, pkg: String, screen: ScreenMetrics, fullscreen: Boolean): Boolean {
        val existing = tracker.windows.value.firstOrNull { it.packageName == pkg }
        if (existing != null && !fullscreen) { shell.exec("am start -n $component"); return true }
        if (fullscreen) { shell.exec("am start -n $component --windowingMode 1"); return true }

        val saved = Bounds.parse(boundsDao.get(pkg) ?: shortcutDao.getAll().firstOrNull { it.packageName == pkg }?.lastBounds)
        val b = clamp(saved ?: WindowMath.defaultBounds(screen.widthPx, screen.heightPx, screen.topInsetPx), screen)

        if (!launchWithOptions(component, b)) shell.exec("am start -n $component --windowingMode 5")

        repeat(7) {
            delay(300)
            val w = tracker.refresh().firstOrNull { it.packageName == pkg } ?: return@repeat
            val tooHigh = (w.bounds?.top ?: screen.topInsetPx) < screen.topInsetPx - 4
            if (w.mode != "freeform" || tooHigh) shell.exec("am task resize ${w.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
            return w.mode == "freeform"
        }
        return true
    }

    private fun clamp(b: Bounds, s: ScreenMetrics): Bounds {
        val c = WindowMath.clampBelowDock(b, s.topInsetPx)
        return Bounds(c.left.coerceAtLeast(0), c.top, c.right.coerceAtMost(s.widthPx), c.bottom.coerceAtMost(s.heightPx))
    }

    private fun launchWithOptions(component: String, b: Bounds): Boolean = runCatching {
        val cn = ComponentName.unflattenFromString(component) ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(b.left, b.top, b.right, b.bottom))
        runCatching { ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(opts, 5) }
        ctx.startActivity(i, opts.toBundle())
        true
    }.getOrDefault(false)
}

/** 8.2 – Snap / maximize cửa sổ đang active. */
class WindowActionsUseCase @Inject constructor(
    private val shell: ShellExecutor,
    private val boundsDao: AppBoundsDao,
    private val shortcutDao: ShortcutDao
) {
    suspend fun snap(win: WindowInfo, region: SnapRegion, s: ScreenMetrics) {
        val b = WindowMath.region(region, s.widthPx, s.heightPx, s.topInsetPx)
        shell.exec("am task resize ${win.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
        boundsDao.upsert(AppBoundsEntity(win.packageName, b.serialize()))
        shortcutDao.updateBounds(win.packageName, b.serialize())
    }

    suspend fun forceStop(pkg: String) { shell.exec("am force-stop $pkg") }
}
