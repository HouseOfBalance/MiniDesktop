package com.minipc.desktop.domain.model

import android.app.PendingIntent
import android.graphics.Bitmap
import kotlin.math.roundToInt

data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width get() = right - left
    val height get() = bottom - top
    fun serialize() = "$left,$top,$right,$bottom"
    fun coversScreen(w: Int, h: Int) = width >= w * 0.95f && height >= h * 0.85f

    companion object {
        fun parse(s: String?): Bounds? = s?.split(",")?.mapNotNull { it.trim().toIntOrNull() }
            ?.takeIf { it.size == 4 }?.let { Bounds(it[0], it[1], it[2], it[3]) }
    }
}

data class ScreenMetrics(val widthPx: Int = 1920, val heightPx: Int = 1080, val density: Float = 2f) {
    /** Top Dock chiếm 52dp (40dp + lề) – cửa sổ không bao giờ chui dưới dock. */
    val topInsetPx get() = (64 * density).roundToInt()
}

data class AppInfo(
    val packageName: String,
    val label: String,
    val component: String,      // flattenToShortString: pkg/.Activity
    val searchKey: String       // label đã bỏ dấu, lowercase
)

enum class ShortcutType { APP, FILE, TOOL }

data class DesktopShortcut(
    val id: Long,
    val type: ShortcutType,
    val packageName: String,
    val title: String,
    val filePath: String?,
    val gridCol: Int,
    val gridRow: Int,
    val lastBounds: Bounds?
)

data class WindowInfo(
    val taskId: Int,
    val packageName: String,
    val component: String?,
    val bounds: Bounds?,
    val mode: String,
    val visible: Boolean
)

data class NotifItem(
    val key: String,
    val groupKey: String?,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    val icon: Bitmap?,
    val intent: PendingIntent?,
    val postTime: Long,
    val clearable: Boolean,
    val isSummary: Boolean
)

data class FileItem(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long
)

data class ProcessMetric(val packageName: String, val pid: Int, val cpuPercent: Float, val ramKb: Long)

data class SystemMetrics(
    val cpuTotalPercent: Float = 0f,
    val ramUsedKb: Long = 0,
    val ramTotalKb: Long = 1,
    val processes: List<ProcessMetric> = emptyList()
)

enum class WallpaperType { NONE, IMAGE, GIF, VIDEO }

data class AppSettings(
    val wallpaperPath: String? = null,
    val wallpaperType: WallpaperType = WallpaperType.NONE,
    val customDpi: Int = 0,
    val originalDpi: Int = 0,
    val kioskLocked: Boolean = false,
    val onboardingDone: Boolean = false,
    val seeded: Boolean = false,
    val lastAppliedDpi: Int = 0
)
