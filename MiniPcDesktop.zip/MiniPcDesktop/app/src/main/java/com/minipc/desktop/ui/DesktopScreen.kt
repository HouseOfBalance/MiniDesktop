package com.minipc.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.minipc.desktop.domain.model.ShortcutType
import com.minipc.desktop.domain.model.WallpaperType
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.desktop.*
import com.minipc.desktop.ui.fileexplorer.FileExplorerWindow
import com.minipc.desktop.ui.fileexplorer.InternalWindowFrame
import com.minipc.desktop.ui.fileexplorer.WindowGeom
import com.minipc.desktop.ui.tools.*
import com.minipc.desktop.ui.systemtray.BrandLabel
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import com.minipc.desktop.ui.onboarding.OnboardingScreen
import com.minipc.desktop.ui.startmenu.StartMenu
import com.minipc.desktop.ui.systemtray.ControlCenter
import com.minipc.desktop.ui.systemtray.SystemTray
import com.minipc.desktop.ui.taskmanager.TaskManagerWindow
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.topdock.TopDock
import java.io.File

@Composable
fun DesktopRoot(vm: DesktopViewModel) {
    val state by vm.state.collectAsState()
    val overlay = remember { UiOverlay() }
    val dd = remember { DragDropState() }

    CompositionLocalProvider(LocalIconCache provides vm.iconCache, LocalOverlay provides overlay, LocalDragDrop provides dd) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (!state.booted) OnboardingScreen(vm, state)
            else DesktopScreen(vm, state, overlay, dd)
            OverlayHost(overlay)
        }
    }
}

@Composable
private fun DesktopScreen(vm: DesktopViewModel, state: DesktopState, overlay: UiOverlay, dd: DragDropState) {
    val onIntent: (DesktopIntent) -> Unit = vm::onIntent
    val holder = remember { GridHolder() }
    val density = LocalDensity.current
    val s = state.settings
    val geoms = remember { HashMap<Int, WindowGeom>() }
    LaunchedEffect(state.internalWindows.map { it.id }) { geoms.keys.retainAll(state.internalWindows.map { it.id }.toSet()) }

    // VisibilityTracker: chỉ phát video khi Activity resumed, màn hình bật và không có app phóng to che desktop.
    var resumed by remember { mutableStateOf(true) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true else if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    // Tạm dừng video nền khi có cửa sổ app đang mở → nhường GPU/CPU cho app (giảm lag đáng kể)
    val anyApp = state.internalWindows.any { it.kind == InternalKind.APP && !it.minimized }
    val playing = resumed && state.screenOn && !anyApp

    // Backdrop cho GlassSurface
    val backdrop: (@Composable () -> Unit)? = null

    // Kéo thả: bắt đầu kéo từ Start Menu → đóng menu (menu vẫn giữ composition, chỉ trong suốt)
    LaunchedEffect(dd.payload) { if (dd.payload is DragPayload.App || dd.payload is DragPayload.Tool) onIntent(DesktopIntent.CloseOverlays) }

    val screenShortcutMenu: (Long, androidx.compose.ui.geometry.Offset) -> Unit = { id, pos ->
        state.shortcuts.firstOrNull { it.id == id }?.let { overlay.showMenu(pos, shortcutMenu(it, onIntent)) }
    }
    dd.onReleaseWithoutMove = { p, pos ->
        when (p) {
            is DragPayload.Shortcut -> screenShortcutMenu(p.id, pos)
            is DragPayload.File -> p.onRelease?.invoke(pos)
            else -> {}
        }
    }
    dd.onDrop = { p, pos ->
        val spec = holder.spec
        if (spec.contains(pos.x, pos.y)) {
            val (c, r) = spec.cellOf(pos.x, pos.y)
            when (p) {
                is DragPayload.App -> onIntent(DesktopIntent.DropApp(p.pkg, c, r))
                is DragPayload.Shortcut -> onIntent(DesktopIntent.MoveShortcut(p.id, c, r))
                is DragPayload.File -> onIntent(DesktopIntent.DropFile(p.path, p.title, c, r))
                is DragPayload.Tool -> onIntent(DesktopIntent.DropTool(p.key, c, r))
            }
        }
    }

    CompositionLocalProvider(LocalBackdrop provides backdrop) {
        Box(Modifier.fillMaxSize()) {
            // 1. Hình nền
            WallpaperLayer(s.wallpaperPath, s.wallpaperType, playing)

            // 2. Lưới shortcut (chừa vùng Top Dock)
            Box(Modifier.fillMaxSize().padding(top = Dims.Reserved + 26.dp).windowInsetsPadding(WindowInsets.displayCutout)) {
                DesktopGrid(state, holder, onIntent,
                    onWallpaperDialog = { overlay.showDialog { d -> WallpaperDialog(vm, d) } },
                    onDpiDialog = { overlay.showDialog { d -> DpiDialog(vm, d) } })
            }

            // 3. Cửa sổ: app trên màn hình ảo + công cụ + File Explorer + Task Manager
            val lastVisible = state.internalWindows.indexOfLast { !it.minimized }
            val cfg = LocalConfiguration.current
            state.internalWindows.forEachIndexed { idx, w ->
                key(w.id) {
                    val isApp = w.kind == InternalKind.APP
                    val tool = if (isApp) null else Tool.fromKind(w.kind)
                    val geom = geoms.getOrPut(w.id) {
                        val off = with(density) { (idx % 6 * 32).dp.toPx() }
                        val titleH = with(density) { 49.dp.toPx() }
                        val availH = with(density) { (cfg.screenHeightDp.dp - Dims.Reserved - 24.dp).toPx() }
                        val availW = with(density) { cfg.screenWidthDp.dp.toPx() }
                        val (fw, fh) = when {
                            isApp && w.portrait -> {                       // dạng điện thoại 9:16 (như TikTok trên PC)
                                val ch = minOf(availH - titleH, with(density) { 760.dp.toPx() })
                                (ch * 9f / 16f) to (ch + titleH)
                            }
                            isApp -> {                                     // app ngang 16:10
                                val cw = minOf(with(density) { 960.dp.toPx() }, availW - with(density) { 160.dp.toPx() })
                                val ch = minOf(cw * 10f / 16f, availH - titleH)
                                cw to (ch + titleH)
                            }
                            else -> {
                                val (wd, ht) = when (w.kind) {
                                    InternalKind.ABOUT -> 640 to 430
                                    InternalKind.SHIZUKU -> 640 to 400
                                    InternalKind.NOTES -> 520 to 380
                                    InternalKind.SETTINGS -> 640 to 440
                                    InternalKind.FILES -> 780 to 480
                                    else -> 740 to 480
                                }
                                with(density) { wd.dp.toPx() } to with(density) { ht.dp.toPx() }
                            }
                        }
                        WindowGeom(with(density) { 200.dp.toPx() } + off, with(density) { (Dims.Reserved + 12.dp).toPx() } + off, fw, fh)
                    }
                    if (!w.minimized) InternalWindowFrame(
                        title = if (isApp) (w.title ?: w.pkg ?: "App") else tool!!.label,
                        icon = { if (isApp) AppIcon(w.pkg!!, 26.dp) else ToolIcon(tool!!, 26.dp) },
                        geom = geom, focused = idx == lastVisible, rotatable = isApp,
                        onClose = { onIntent(DesktopIntent.CloseInternal(w.id)) },
                        onMinimize = { onIntent(DesktopIntent.MinimizeInternal(w.id)) },
                        onFocus = { onIntent(DesktopIntent.FocusInternal(w.id)) }
                    ) {
                        when (w.kind) {
                            InternalKind.APP -> EmbeddedAppView(vm.sessions, w.id, Modifier.fillMaxSize())
                            InternalKind.FILES -> FileExplorerWindow(vm, w.path)
                            InternalKind.TASKS -> TaskManagerWindow(vm, state)
                            InternalKind.NOTES -> NotesWindow()
                            InternalKind.SETTINGS -> SettingsWindow(vm, state)
                            InternalKind.SHIZUKU -> ShizukuWindow(vm, state)
                            InternalKind.ABOUT -> AboutWindow()
                        }
                    }
                }
            }

            // 3b. Dải Stage Manager
            StageStrip(state, onIntent, Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = Dims.Reserved + 10.dp))

            // 5. Scrim đóng menu khi chạm ra ngoài
            if (state.startOpen || state.controlCenterOpen) {
                Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onIntent(DesktopIntent.CloseOverlays) } })
            }

            // 6. Taskbar (TRÊN cùng), nhãn, tray, ngăn ứng dụng, Control Center, toast
            Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
                BrandLabel(Modifier.align(Alignment.TopStart).padding(start = 24.dp, top = 14.dp))
                TopDock(state, onIntent, Modifier.align(Alignment.TopCenter).padding(top = Dims.DockTop))
                SystemTray(state, onIntent, Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 16.dp))
                StartMenu(state, onIntent, Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = Dims.Reserved, bottom = 16.dp).width(460.dp).fillMaxHeight())
                ControlCenter(state, onIntent, Modifier.align(Alignment.TopEnd).padding(top = Dims.Reserved, end = 12.dp))
                if (!state.controlCenterOpen)
                    NotificationToast(state, onIntent, Modifier.align(Alignment.TopEnd).padding(top = Dims.Reserved + 6.dp, end = 12.dp))
                // Nút Hiện desktop ở mép trái
                Box(
                    Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(36.dp).clip(CircleShape)
                        .background(Color(0x66000000)).clickable { onIntent(DesktopIntent.ShowDesktop) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.DesktopWindows, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                // Tiêu đề khu vực desktop
                Text("KHÔNG GIAN CỦA BẠN", color = Color(0xFF9AA0B5), fontSize = 12.sp, letterSpacing = 2.sp,
                    modifier = Modifier.align(Alignment.TopStart).padding(start = 24.dp, top = Dims.Reserved + 4.dp))
            }

            // 8. Bóng kéo thả
            DragShadow(dd)

            // 9. Cảnh báo ROM
            if (state.compatOk == false) {
                androidx.compose.material3.Text(
                    "Chưa mở được cửa sổ app: cần Shizuku đang chạy", color = Color(0xFFFFB74D),
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp), fontSize = 12.sp)
            }

            // 10. Góc cứu hộ: chạm 5 lần liên tiếp ở góc trên-trái trong 3 giây
            PanicCorner(Modifier.align(Alignment.TopStart)) { onIntent(DesktopIntent.Panic) }
        }
    }
}

@Composable
private fun PanicCorner(modifier: Modifier, onPanic: () -> Unit) {
    var taps by remember { mutableStateOf(listOf<Long>()) }
    Box(modifier.size(56.dp).pointerInput(Unit) {
        detectTapGestures {
            val now = System.currentTimeMillis()
            taps = taps.filter { now - it < 3000 } + now
            if (taps.size >= 5) { taps = emptyList(); onPanic() }
        }
    })
}
