package com.minipc.desktop.ui.desktop

import android.net.Uri
import android.os.Build
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import com.minipc.desktop.domain.model.WallpaperType
import java.io.File

@Composable
fun DefaultGradient() = Box(
    Modifier.fillMaxSize().background(
        Brush.linearGradient(listOf(Color(0xFF0B3D91), Color(0xFF1B1464), Color(0xFF0F2027)))
    )
)

/** 4.2 – Render đa định dạng: ảnh tĩnh, GIF (Coil), video loop (ExoPlayer + SurfaceView). */
@Composable
fun WallpaperLayer(path: String?, type: WallpaperType, playing: Boolean) {
    val ok = path != null && File(path).exists()
    if (!ok || type == WallpaperType.NONE) { DefaultGradient(); return }
    when (type) {
        WallpaperType.IMAGE, WallpaperType.GIF -> {
            val ctx = LocalContext.current
            val loader = remember {
                ImageLoader.Builder(ctx).components {
                    if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
                }.build()
            }
            AsyncImage(File(path!!), null, imageLoader = loader, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        WallpaperType.VIDEO -> VideoWallpaperSurface(path!!, playing)
        else -> DefaultGradient()
    }
}

/** Video nền: tắt tiếng, lặp vô hạn; tự pause khi playing=false (VisibilityTracker); release khi rời composition. */
@Composable
fun VideoWallpaperSurface(path: String, playing: Boolean) {
    val ctx = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(ctx).build().apply {
            volume = 0f
            repeatMode = Player.REPEAT_MODE_ONE
            videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            trackSelectionParameters = trackSelectionParameters.buildUpon().setMaxVideoSize(1280, 720).build()
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }   // giải phóng bộ giải mã khi chuyển sang ảnh tĩnh
    LaunchedEffect(player, playing) { if (playing) player.play() else player.pause() }
    AndroidView(
        factory = { c -> SurfaceView(c).also { player.setVideoSurfaceView(it) } },
        modifier = Modifier.fillMaxSize()
    )
}

/** Bản tĩnh dùng làm nền cho GlassSurface (ảnh/GIF hiển thị frame đầu). */
@Composable
fun StaticBackdrop(path: String?, type: WallpaperType) {
    if (path != null && File(path).exists() && (type == WallpaperType.IMAGE || type == WallpaperType.GIF))
        AsyncImage(File(path), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    else DefaultGradient()
}
