package com.minipc.desktop.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "shortcuts")
data class ShortcutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val title: String,
    val type: String,               // "APP" | "FILE"
    val gridCol: Int,
    val gridRow: Int,
    val lastBounds: String? = null, // "l,t,r,b"
    val filePath: String? = null
)

@Entity(tableName = "pinned_apps")
data class PinnedAppEntity(
    @PrimaryKey val packageName: String,
    val onDock: Boolean = true,
    val inStartMenu: Boolean = true,
    val sortOrder: Int = 0
)

/** Bounds cuối cùng của mọi app (kể cả app không có shortcut). */
@Entity(tableName = "app_bounds")
data class AppBoundsEntity(@PrimaryKey val packageName: String, val bounds: String)

@Dao
interface ShortcutDao {
    @Query("SELECT * FROM shortcuts") fun observeAll(): Flow<List<ShortcutEntity>>
    @Query("SELECT * FROM shortcuts") suspend fun getAll(): List<ShortcutEntity>
    @Insert suspend fun insert(e: ShortcutEntity): Long
    @Query("DELETE FROM shortcuts WHERE id = :id") suspend fun delete(id: Long)
    @Query("UPDATE shortcuts SET gridCol = :c, gridRow = :r WHERE id = :id") suspend fun move(id: Long, c: Int, r: Int)
    @Query("UPDATE shortcuts SET lastBounds = :b WHERE packageName = :pkg AND type = 'APP'")
    suspend fun updateBounds(pkg: String, b: String)
}

@Dao
interface PinnedAppDao {
    @Query("SELECT * FROM pinned_apps ORDER BY sortOrder") fun observeAll(): Flow<List<PinnedAppEntity>>
    @Query("SELECT * FROM pinned_apps WHERE packageName = :pkg") suspend fun get(pkg: String): PinnedAppEntity?
    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM pinned_apps") suspend fun maxOrder(): Int
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: PinnedAppEntity)
    @Query("DELETE FROM pinned_apps WHERE packageName = :pkg") suspend fun delete(pkg: String)
}

@Dao
interface AppBoundsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: AppBoundsEntity)
    @Query("SELECT bounds FROM app_bounds WHERE packageName = :pkg") suspend fun get(pkg: String): String?
}

@Database(
    entities = [ShortcutEntity::class, PinnedAppEntity::class, AppBoundsEntity::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun shortcutDao(): ShortcutDao
    abstract fun pinnedAppDao(): PinnedAppDao
    abstract fun appBoundsDao(): AppBoundsDao
}
