# Shizuku gọi newProcess() bằng reflection
-keep class rikka.shizuku.** { *; }
-keep class org.lsposed.hiddenapibypass.** { *; }
-dontwarn org.lsposed.hiddenapibypass.**
# Hilt / Room dùng consumer rules của thư viện
-keepclassmembers class * { @javax.inject.Inject <init>(...); }
