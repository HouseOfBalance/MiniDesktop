package com.minipc.desktop.ui.common

import android.graphics.Bitmap
import android.os.Build
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.data.repository.IconCache
import kotlin.math.roundToInt

// ---------- CompositionLocals ----------
val LocalIconCache = staticCompositionLocalOf<IconCache> { error("IconCache") }
val LocalOverlay = staticCompositionLocalOf<UiOverlay> { error("UiOverlay") }
val LocalDragDrop = staticCompositionLocalOf<DragDropState> { error("DragDropState") }
val LocalBackdrop = compositionLocalOf<(@Composable () -> Unit)?> { null }

// ---------- Overlay: context menu + modal (không dùng Popup/Dialog để không làm hiện lại thanh hệ thống) ----------
class MenuItem(val label: String, val enabled: Boolean = true, val action: () -> Unit)

@Stable
class UiOverlay {
    var menuPos by mutableStateOf<Offset?>(null)
    var menuItems by mutableStateOf<List<MenuItem>>(emptyList())
    var dialog by mutableStateOf<(@Composable (dismiss: () -> Unit) -> Unit)?>(null)

    fun showMenu(pos: Offset, items: List<MenuItem>) { menuItems = items; menuPos = pos }
    fun hideMenu() { menuPos = null }
    fun showDialog(content: @Composable (dismiss: () -> Unit) -> Unit) { dialog = content }
    fun hideDialog() { dialog = null }
}

@Composable
fun OverlayHost(o: UiOverlay) {
    val d = o.dialog
    if (d != null) {
        Box(
            Modifier.fillMaxSize().background(Color(0x99000000)).pointerInput(Unit) { detectTapGestures { o.hideDialog() } },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.pointerInput(Unit) { detectTapGestures { } }) { d { o.hideDialog() } }
        }
    }
    val pos = o.menuPos
    if (pos != null) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { o.hideMenu() } })
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val density = LocalDensity.current
            val w = with(density) { 200.dp.toPx() }
            val h = with(density) { (o.menuItems.size * 40 + 12).dp.toPx() }
            val x = pos.x.coerceIn(0f, (constraints.maxWidth - w).coerceAtLeast(0f))
            val y = pos.y.coerceIn(0f, (constraints.maxHeight - h).coerceAtLeast(0f))
            Column(
                Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }.width(200.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Color(0xFF262A31))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(10.dp)).padding(vertical = 6.dp)
            ) {
                o.menuItems.forEach { item ->
                    Text(
                        item.label, color = if (item.enabled) Color.White else Color.Gray, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().height(40.dp)
                            .clickable(enabled = item.enabled) { o.hideMenu(); item.action() }
                            .padding(horizontal = 14.dp).wrapContentHeight(Alignment.CenterVertically)
                    )
                }
            }
        }
    }
}

// ---------- 3.3 Chuột phải (BUTTON_SECONDARY) ----------
/** Bắt nút phải chuột và nuốt sự kiện để hệ thống không biến nó thành phím Back. Trả toạ độ trong root. */
fun Modifier.secondaryClick(onClick: (Offset) -> Unit): Modifier = composed {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val cb by rememberUpdatedState(onClick)
    this.onGloballyPositioned { origin = it.positionInRoot() }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                    if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                        val ch = ev.changes.first()
                        cb(origin + ch.position)
                        ev.changes.forEach { it.consume() }
                    }
                }
            }
        }
}

/** Nhấn giữ (cảm ứng) hoặc chuột phải → cùng 1 callback. */
fun Modifier.contextClick(onTap: (() -> Unit)? = null, onClick: (Offset) -> Unit): Modifier = composed {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val cb by rememberUpdatedState(onClick)
    val tap by rememberUpdatedState(onTap)
    this.onGloballyPositioned { origin = it.positionInRoot() }
        .pointerInput(Unit) { detectTapGestures(onTap = { tap?.invoke() }, onLongPress = { cb(origin + it) }) }
        .secondaryClick(onClick)
}

// ---------- 5.2 Kéo thả ----------
sealed interface DragPayload {
    val title: String
    data class App(val pkg: String, override val title: String) : DragPayload
    data class Shortcut(val id: Long, val pkg: String, override val title: String, val isFile: Boolean, val toolKey: String? = null) : DragPayload
    data class Tool(val key: String, override val title: String) : DragPayload
    data class File(val path: String, override val title: String, val isDir: Boolean, val onRelease: ((Offset) -> Unit)? = null) : DragPayload
}

@Stable
class DragDropState {
    var payload by mutableStateOf<DragPayload?>(null)
    var position by mutableStateOf(Offset.Zero)
    private var travelled = 0f
    val active get() = payload != null
    var onDrop: (DragPayload, Offset) -> Unit = { _, _ -> }
    var onReleaseWithoutMove: (DragPayload, Offset) -> Unit = { _, _ -> }

    fun start(p: DragPayload, pos: Offset) { payload = p; position = pos; travelled = 0f }
    fun move(d: Offset) { position += d; travelled += d.getDistance() }
    fun drop() {
        val p = payload ?: return
        val pos = position
        payload = null
        if (travelled > 12f) onDrop(p, pos) else onReleaseWithoutMove(p, pos)
    }
    fun cancel() { payload = null }
}

fun Modifier.dragSource(dd: DragDropState, payload: DragPayload): Modifier = composed {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val p by rememberUpdatedState(payload)
    this.onGloballyPositioned { origin = it.positionInRoot() }
        .pointerInput(Unit) {
            detectDragGesturesAfterLongPress(
                onDragStart = { dd.start(p, origin + it) },
                onDrag = { c, d -> c.consume(); dd.move(d) },
                onDragEnd = { dd.drop() },
                onDragCancel = { dd.cancel() }
            )
        }
}

// ---------- Icon ----------
@Composable
fun AppIcon(pkg: String, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    val cache = LocalIconCache.current
    val bmp: Bitmap? = remember(pkg) { cache.get(pkg) }
    if (bmp != null) Image(bmp.asImageBitmap(), null, modifier.size(size))
    else Box(modifier.size(size).clip(CircleShape).background(Color(0x55FFFFFF)))
}

// ---------- 6.1 Kính mờ ----------
/** Khung kính: nền navy bán trong suốt + viền mảnh. (Không blur backdrop vì vẽ lại cả hình nền mỗi khung hình rất nặng.) */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape,
    tint: Color = Color(0xFF1A2035),
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.clip(shape).background(tint).border(1.dp, Color(0x33FFFFFF), shape)) { content() }
}

@Composable
fun DotIndicator(modifier: Modifier = Modifier) {
    Box(modifier.size(4.dp).clip(CircleShape).background(Color(0xFF7DD3FC)))
}

@Composable
fun MenuText(text: String, color: Color = MaterialTheme.colorScheme.onSurface, size: Int = 13) =
    Text(text, color = color, fontSize = size.sp, maxLines = 1)
