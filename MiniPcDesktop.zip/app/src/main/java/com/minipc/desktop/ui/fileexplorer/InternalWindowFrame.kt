package com.minipc.desktop.ui.fileexplorer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.theme.Dims
import kotlin.math.roundToInt

/** 9.1 – Khung cửa sổ riêng trong Desktop: thanh tiêu đề kéo được, 2 góc đổi kích thước, phóng to, đóng. */
@Composable
fun InternalWindowFrame(
    title: String,
    initialX: Float, initialY: Float, initialWdp: Int, initialHdp: Int,
    onClose: () -> Unit, onFocus: () -> Unit,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    val cfg = LocalConfiguration.current
    val screenW = with(density) { cfg.screenWidthDp.dp.toPx() }
    val screenH = with(density) { cfg.screenHeightDp.dp.toPx() }
    val top = with(density) { Dims.Reserved.toPx() }
    val minW = with(density) { 320.dp.toPx() }
    val minH = with(density) { 220.dp.toPx() }

    var x by remember { mutableFloatStateOf(initialX) }
    var y by remember { mutableFloatStateOf(initialY.coerceAtLeast(top)) }
    var w by remember { mutableFloatStateOf(with(density) { initialWdp.dp.toPx() }) }
    var h by remember { mutableFloatStateOf(with(density) { initialHdp.dp.toPx() }) }
    var maximized by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(floatArrayOf()) }

    fun toggleMax() {
        if (!maximized) { saved = floatArrayOf(x, y, w, h); x = 0f; y = top; w = screenW; h = screenH - top }
        else { x = saved[0]; y = saved[1]; w = saved[2]; h = saved[3] }
        maximized = !maximized
    }

    Box(
        Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .size(with(density) { w.toDp() }, with(density) { h.toDp() })
            .clip(RoundedCornerShape(12.dp)).background(Color(0xFF1E2127))
            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(12.dp))
            .pointerInput(Unit) {   // focus mà không nuốt sự kiện
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        if (e.type == PointerEventType.Press) onFocus()
                    }
                }
            }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(36.dp).background(Color(0xFF2A2E36))
                    .pointerInput(Unit) {
                        detectDragGestures { c, d ->
                            c.consume()
                            if (!maximized) { x += d.x; y = (y + d.y).coerceAtLeast(top) }
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { toggleMax() }) }
                    .padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.CropSquare, null, tint = Color.White,
                    modifier = Modifier.size(36.dp).clickable { toggleMax() }.padding(10.dp))
                Icon(Icons.Filled.Close, null, tint = Color.White,
                    modifier = Modifier.size(36.dp).clickable { onClose() }.padding(10.dp))
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        }
        // Tay nắm góc phải-dưới
        Icon(Icons.Filled.DragHandle, null, tint = Color(0x88FFFFFF),
            modifier = Modifier.align(Alignment.BottomEnd).size(22.dp).pointerInput(Unit) {
                detectDragGestures { c, d -> c.consume(); if (!maximized) { w = (w + d.x).coerceAtLeast(minW); h = (h + d.y).coerceAtLeast(minH) } }
            })
        // Tay nắm góc trái-dưới
        Icon(Icons.Filled.DragHandle, null, tint = Color(0x88FFFFFF),
            modifier = Modifier.align(Alignment.BottomStart).size(22.dp).pointerInput(Unit) {
                detectDragGestures { c, d ->
                    c.consume()
                    if (!maximized) { val nw = (w - d.x).coerceAtLeast(minW); x += (w - nw); w = nw; h = (h + d.y).coerceAtLeast(minH) }
                }
            })
    }
}
