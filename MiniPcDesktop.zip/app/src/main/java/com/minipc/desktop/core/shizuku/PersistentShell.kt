package com.minipc.desktop.core.shizuku

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException

/** Giữ 1 phiên shell mở sẵn; mỗi lệnh kết thúc bằng marker để biết điểm dừng output. */
class PersistentShell(private val spawn: () -> Process) {
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private var reader: BufferedReader? = null

    @Synchronized
    fun exec(cmd: String): String {
        if (proc == null) open()
        val marker = "__MPC_END_${System.nanoTime()}__"
        val w = writer!!
        w.write("( $cmd ) 2>&1\n")
        w.write("echo $marker\n")
        w.flush()
        val sb = StringBuilder()
        val r = reader!!
        while (true) {
            val line = r.readLine() ?: throw IOException("shell closed")
            if (line == marker) break
            sb.append(line).append('\n')
        }
        return sb.toString().trimEnd()
    }

    private fun open() {
        val p = spawn()
        proc = p
        writer = p.outputStream.bufferedWriter()
        reader = p.inputStream.bufferedReader()
    }

    @Synchronized
    fun close() {
        runCatching { writer?.write("exit\n"); writer?.flush() }
        runCatching { proc?.destroy() }
        proc = null; writer = null; reader = null
    }
}
