package com.minipc.desktop.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object Dims {
    val DockHeight = 52.dp
    val DockTop = 6.dp
    val Reserved = 64.dp      // vùng Top Dock chiếm
    val CellW = 96.dp
    val CellH = 104.dp
}

val Accent = Color(0xFF8C9EFF)
val Navy = Color(0xFF1A2035)
val NavyDeep = Color(0xFF131829)

object Brand {
    const val NAME = "Mini PC"      // đổi tên hiển thị ở đây
    const val TAGLINE = "Không gian nhỏ. Khả năng lớn."
}

@Composable
fun MiniPcTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Color.Black,
        surface = Color(0xFF1C1F24), onSurface = Color.White,
        background = Color.Black, onBackground = Color.White
    ),
    content = content
)
