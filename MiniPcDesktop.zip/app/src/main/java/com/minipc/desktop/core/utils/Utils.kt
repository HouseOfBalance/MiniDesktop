package com.minipc.desktop.core.utils

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.Normalizer

object StringUtils {
    private val diacritics = Regex("\\p{InCombiningDiacriticalMarks}+")

    /** Bỏ dấu tiếng Việt + lowercase. */
    fun normalize(s: String): String =
        diacritics.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "")
            .replace('đ', 'd').replace('Đ', 'd').lowercase()
}

object Permissions {
    fun notificationListenerEnabled(c: Context) =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    fun allFilesAccess(c: Context) =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(c, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun isDefaultHome(c: Context): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return c.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == c.packageName
    }

    fun openNotificationListenerSettings(c: Context) =
        c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun openAllFilesSettings(c: Context) {
        val i = if (Build.VERSION.SDK_INT >= 30)
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${c.packageName}"))
        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}"))
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun requestHomeIntent(c: Context): Intent =
        if (Build.VERSION.SDK_INT >= 29 && c.getSystemService(RoleManager::class.java).isRoleAvailable(RoleManager.ROLE_HOME))
            c.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_HOME)
        else Intent(Settings.ACTION_HOME_SETTINGS)

    fun appInfoIntent(pkg: String) =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
