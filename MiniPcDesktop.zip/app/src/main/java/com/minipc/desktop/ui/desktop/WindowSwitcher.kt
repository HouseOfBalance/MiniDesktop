package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.InternalKind
import com.minipc.desktop.ui.common.AppIcon
import com.minipc.desktop.ui.theme.Accent
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon

/** Bảng chọn cửa sổ khi giữ Alt và bấm Tab; thả Alt để chuyển. */
@Composable
fun WindowSwitcher(state: DesktopState, modifier: Modifier = Modifier) {
    if (state.switcherIndex < 0) return
    val list = state.internalWindows.filter { it.desktop == state.currentDesktop }.asReversed()
    if (list.isEmpty()) return
    Row(
        modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF141A2B)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp)).padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        list.forEachIndexed { i, w ->
            Column(
                Modifier.width(110.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (i == state.switcherIndex) Color(0x338C9EFF) else Color.Transparent)
                    .border(if (i == state.switcherIndex) 2.dp else 0.dp, Accent, RoundedCornerShape(16.dp)).padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (w.kind == InternalKind.APP && w.pkg != null) AppIcon(w.pkg, 56.dp) else ToolIcon(Tool.fromKind(w.kind), 56.dp)
                Spacer(Modifier.height(6.dp))
                Text(w.title ?: Tool.fromKind(w.kind).label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
