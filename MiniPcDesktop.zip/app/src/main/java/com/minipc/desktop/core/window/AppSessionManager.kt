package com.minipc.desktop.core.window

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.Surface
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.inputmethod.InputMethodManager
import com.minipc.desktop.core.shizuku.ShellExecutor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.lang.ref.WeakReference
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Mỗi cửa sổ app = 1 VirtualDisplay riêng. App chạy trên màn hình ảo đó, hình ảnh vẽ vào SurfaceView/TextureView
 * trong khung cửa sổ của Mini PC – hoàn toàn độc lập với đa cửa sổ của Android.
 */
@Singleton
class AppSessionManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val shell: ShellExecutor
) {
    class Session(val id: Int, val pkg: String, val component: String, val multi: Boolean) {
        var vd: VirtualDisplay? = null
        var displayId = -1
        var surface: Surface? = null
        var ownsSurface = true
        var w = 0
        var h = 0
        var secondaryHeld = false
        var appliedW = 0
        var appliedH = 0
    }

    private val sessions = HashMap<Int, Session>()
    private val views = HashMap<Int, WeakReference<View>>()
    private val thumbs = HashMap<Int, Bitmap>()
    private val kbShown = HashSet<Int>()
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private val _failures = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val failures = _failures.asSharedFlow()

    private val dpi get() = ctx.resources.displayMetrics.densityDpi

    fun supported() = shell.ready && InputInjector.available()
    fun open(id: Int, pkg: String, component: String, multi: Boolean = false) {
        sessions.getOrPut(id) { Session(id, pkg, component, multi) }
    }
    fun displayIdOf(id: Int) = sessions[id]?.displayId ?: -1

    private val pendingResize = HashMap<Int, Runnable>()

    /** Chờ 160ms sau lần đổi kích thước cuối mới áp dụng cho màn hình ảo → kéo cạnh cửa sổ mượt, app không bị giật cấu hình. */
    private fun scheduleResize(s: Session) {
        pendingResize.remove(s.id)?.let { main.removeCallbacks(it) }
        val r = Runnable {
            pendingResize.remove(s.id)
            if (s.w != s.appliedW || s.h != s.appliedH) {
                runCatching { s.vd?.resize(s.w, s.h, dpi) }
                s.appliedW = s.w; s.appliedH = s.h
            }
        }
        pendingResize[s.id] = r
        main.postDelayed(r, 160)
    }

    private fun fit(w: Int, h: Int): Pair<Int, Int> {
        val m = maxOf(w, h)
        val k = if (m > 1920) 1920f / m else 1f
        return (w * k).toInt().coerceAtLeast(64) to (h * k).toInt().coerceAtLeast(64)
    }

    // ---------- Surface ----------
    /** TextureView đã có SurfaceTexture. */
    fun attach(id: Int, st: SurfaceTexture, vw: Int, vh: Int) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        s.w = w; s.h = h
        st.setDefaultBufferSize(w, h)
        if (s.ownsSurface) s.surface?.release()
        val surf = Surface(st)
        s.ownsSurface = true
        s.surface = surf
        bind(s, surf, w, h)
    }

    /** SurfaceView (cửa sổ trên cùng): Surface do hệ thống quản lý, ít tốn GPU hơn. */
    fun attachSurface(id: Int, surf: Surface, vw: Int, vh: Int) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        s.w = w; s.h = h
        if (s.ownsSurface) s.surface?.release()
        s.ownsSurface = false
        s.surface = surf
        bind(s, surf, w, h)
    }

    private fun bind(s: Session, surf: Surface, w: Int, h: Int) {
        val vd = s.vd
        if (vd == null) createDisplay(s, surf) else { runCatching { vd.surface = surf }; scheduleResize(s) }
    }

    fun resize(id: Int, vw: Int, vh: Int, st: SurfaceTexture) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        if (w == s.w && h == s.h) return
        s.w = w; s.h = h
        st.setDefaultBufferSize(w, h)
        scheduleResize(s)
    }

    /** Cửa sổ bị thu nhỏ/gỡ khỏi màn hình: ngắt Surface, app vẫn chạy trên màn hình ảo. */
    fun detach(id: Int) {
        val s = sessions[id] ?: return
        runCatching { s.vd?.surface = null }
        if (s.ownsSurface) s.surface?.release()
        s.surface = null
    }

    private fun createDisplay(s: Session, surf: Surface) {
        if (!supported()) { _failures.tryEmit("Cần Shizuku đang chạy để mở app trong cửa sổ"); return }
        val pub = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        // Không dùng SHOULD_SHOW_SYSTEM_DECORATIONS: cờ đó khiến ROM coi đây là "màn hình ngoài" và bật chế độ cửa sổ nổi.
        val full = pub or (1 shl 6) /* SUPPORTS_TOUCH */
        val name = "MiniPC-${s.pkg}"
        val vd = runCatching { dm.createVirtualDisplay(name, s.w, s.h, dpi, surf, full) }.getOrNull()
            ?: runCatching { dm.createVirtualDisplay(name, s.w, s.h, dpi, surf, pub) }.getOrNull()
        if (vd == null) { _failures.tryEmit("ROM không cho tạo màn hình ảo"); return }
        s.vd = vd
        s.appliedW = s.w; s.appliedH = s.h
        s.displayId = vd.display.displayId
        // Cửa sổ thứ 2 của cùng 1 app: NEW_TASK | MULTIPLE_TASK | NEW_DOCUMENT để tạo task mới thay vì dùng lại task cũ.
        val extra = if (s.multi) " -f 0x18080000" else ""
        scope.launch {
            val out = shell.exec("am start --display ${s.displayId} --windowingMode 1$extra -n ${s.component}")
            if (out.contains("Error", true)) _failures.tryEmit("Không mở được ${s.pkg} trên màn hình ảo")
        }
    }

    /** Đưa tiêu điểm hệ thống sang màn hình ảo của cửa sổ (giúp clipboard/IME hoạt động đúng app). */
    private var lastFocusId = -1
    private var lastFocusAt = 0L

    fun focusDisplay(id: Int) {
        val s = sessions[id] ?: return
        val now = android.os.SystemClock.uptimeMillis()
        if (id == lastFocusId && now - lastFocusAt < 1500) return   // `am start` khởi động cả tiến trình Java → hạn chế gọi
        lastFocusId = id; lastFocusAt = now
        if (s.displayId >= 0) shell.fire("am start --display ${s.displayId} -n ${s.component}")
    }

    fun close(id: Int) {
        val s = sessions.remove(id) ?: return
        views.remove(id); thumbs.remove(id); kbShown.remove(id)
        pendingResize.remove(id)?.let { main.removeCallbacks(it) }
        runCatching { s.vd?.release() }
        if (s.ownsSurface) s.surface?.release()
        // Chỉ buộc dừng app khi không còn cửa sổ nào khác của cùng app
        if (sessions.values.none { it.pkg == s.pkg }) shell.fire("am force-stop ${s.pkg}")
    }

    fun closeAll() { sessions.keys.toList().forEach { close(it) } }

    // ---------- Chuyển tiếp input ----------
    fun touch(id: Int, v: View, e: MotionEvent) {
        val s = sessions[id] ?: return
        if (s.displayId < 0 || v.width == 0 || v.height == 0) return
        val mouse = e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
        if ((mouse && (e.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) || s.secondaryHeld) {
            // Chuột phải = nút Back
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { s.secondaryHeld = true; InputInjector.key(s.displayId, KeyEvent.KEYCODE_BACK) }
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) s.secondaryHeld = false
            return
        }
        val c = MotionEvent.obtain(e)
        c.transform(Matrix().apply { setScale(s.w.toFloat() / v.width, s.h.toFloat() / v.height) })
        c.source = InputDevice.SOURCE_TOUCHSCREEN
        InputInjector.send(c, s.displayId)
    }

    fun generic(id: Int, v: View, e: MotionEvent): Boolean {
        val s = sessions[id] ?: return false
        if (s.displayId < 0 || e.actionMasked != MotionEvent.ACTION_SCROLL || v.width == 0) return false
        val c = MotionEvent.obtain(e)
        c.transform(Matrix().apply { setScale(s.w.toFloat() / v.width, s.h.toFloat() / v.height) })
        c.source = InputDevice.SOURCE_MOUSE
        InputInjector.send(c, s.displayId)
        return true
    }

    fun forwardKey(id: Int, e: KeyEvent): Boolean {
        val s = sessions[id] ?: return false
        if (s.displayId < 0) return false
        InputInjector.send(KeyEvent.changeAction(e, e.action), s.displayId)
        return true
    }

    // ---------- Bàn phím ảo trong cửa sổ app ----------
    fun registerView(id: Int, v: View) { views[id] = WeakReference(v) }

    /** Bật/tắt bàn phím ảo của điện thoại, gõ được chuyển vào app trong cửa sổ (chỉ khi người dùng bấm nút bàn phím). */
    fun toggleKeyboard(id: Int) {
        val v = views[id]?.get() ?: return
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        v.requestFocus()
        if (kbShown.remove(id)) imm.hideSoftInputFromWindow(v.windowToken, 0)
        else { kbShown.add(id); imm.showSoftInput(v, 0) }
    }

    /** ASCII → gửi từng phím; Unicode (tiếng Việt…) → đặt vào clipboard rồi gửi Ctrl+V (KEYCODE_PASTE). */
    fun typeText(id: Int, text: CharSequence) {
        val s = sessions[id] ?: return
        if (s.displayId < 0 || text.isEmpty()) return
        val ascii = text.all { it.code in 32..126 || it == '\n' }
        if (ascii) {
            KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(text.toString().toCharArray())
                ?.forEach { InputInjector.send(it, s.displayId) }
        } else {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("minipc", text))
            InputInjector.key(s.displayId, KeyEvent.KEYCODE_PASTE)
        }
    }

    // ---------- Ảnh thu nhỏ (hover taskbar, Stage Manager) ----------
    fun cachedThumb(id: Int): Bitmap? = thumbs[id]

    /** Chụp nhanh cửa sổ đang hiển thị; nếu không chụp được thì trả ảnh đã lưu lần trước. */
    fun captureThumb(id: Int, done: ((Bitmap?) -> Unit)? = null) {
        val v = views[id]?.get()
        if (v == null || v.width == 0 || v.height == 0 || !v.isAttachedToWindow) { done?.invoke(thumbs[id]); return }
        val w = 320
        val h = (320f * v.height / v.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        runCatching {
            when (v) {
                is TextureView -> { v.getBitmap(bmp); thumbs[id] = bmp; done?.invoke(bmp) }
                is SurfaceView -> PixelCopy.request(v, bmp, { r ->
                    if (r == PixelCopy.SUCCESS) { thumbs[id] = bmp; done?.invoke(bmp) } else done?.invoke(thumbs[id])
                }, main)
                else -> done?.invoke(null)
            }
        }.onFailure { done?.invoke(thumbs[id]) }
    }
}
