package com.minipc.desktop.core.kiosk

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.view.Window
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

object CutoutHandler {
    fun apply(window: Window) {
        if (Build.VERSION.SDK_INT >= 28) {
            val a = window.attributes
            a.layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = a
        }
    }
}

object ImmersiveController {
    fun apply(a: Activity) {
        WindowCompat.setDecorFitsSystemWindows(a.window, false)
        val c = WindowInsetsControllerCompat(a.window, a.window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        CutoutHandler.apply(a.window)
    }

    fun hideIme(a: Activity) {
        WindowInsetsControllerCompat(a.window, a.window.decorView).hide(WindowInsetsCompat.Type.ime())
    }
}

object LauncherUtils {
    /** Tìm Launcher gốc của máy (không phải app này), ưu tiên app hệ thống. */
    fun findOriginalHome(a: Activity): android.content.ComponentName? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val list = a.packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != a.packageName }
        val pick = list.firstOrNull { (it.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0 }
            ?: list.firstOrNull()
        return pick?.let { android.content.ComponentName(it.activityInfo.packageName, it.activityInfo.name) }
    }

    /** Quay về launcher mà người dùng đang dùng (app này không còn là Home). */
    fun launchOriginalHome(a: Activity) {
        a.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
