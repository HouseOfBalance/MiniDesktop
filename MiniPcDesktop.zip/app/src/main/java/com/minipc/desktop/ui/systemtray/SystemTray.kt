package com.minipc.desktop.ui.systemtray

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.GlassSurface
import com.minipc.desktop.ui.theme.Dims
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 7.1 – Khay hệ thống nổi góc phải trên. */
@Composable
fun SystemTray(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val time = remember(state.clockMs) { fmt.format(Date(state.clockMs)) }
    val unread = state.notifs.count { !it.isSummary }
    GlassSurface(modifier.height(Dims.DockHeight), RoundedCornerShape(20.dp)) {
        Row(
            Modifier.fillMaxHeight().clickable { onIntent(DesktopIntent.ToggleControlCenter) }.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val wifiIcon = when {
                !state.wifi.enabled -> Icons.Filled.WifiOff
                !state.wifi.connected -> Icons.Filled.Wifi1Bar
                state.wifi.level >= 3 -> Icons.Filled.Wifi
                state.wifi.level == 2 -> Icons.Filled.Wifi2Bar
                else -> Icons.Filled.Wifi1Bar
            }
            Icon(wifiIcon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (state.battery.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryFull, null,
                    tint = if (state.battery.percent <= 15 && !state.battery.charging) Color(0xFFFF6B6B) else Color.White,
                    modifier = Modifier.size(18.dp))
                Text("${state.battery.percent}%", color = Color.White, fontSize = 12.sp)
            }
            Text(time, color = Color.White, fontSize = 13.sp)
            Box {
                Icon(Icons.Filled.Notifications, null, tint = Color.White, modifier = Modifier.size(18.dp))
                if (unread > 0) Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-4).dp).size(14.dp).clip(CircleShape).background(Color(0xFFFF5252)),
                    contentAlignment = Alignment.Center
                ) { Text(if (unread > 9) "9+" else "$unread", color = Color.White, fontSize = 8.sp) }
            }
        }
    }
}
