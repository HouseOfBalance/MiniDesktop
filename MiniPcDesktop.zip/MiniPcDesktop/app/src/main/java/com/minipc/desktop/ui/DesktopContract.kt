package com.minipc.desktop.ui

import android.net.Uri
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.data.db.PinnedAppEntity
import com.minipc.desktop.data.repository.BatteryState
import com.minipc.desktop.data.repository.WallpaperItem
import com.minipc.desktop.data.repository.WifiState
import com.minipc.desktop.domain.model.*

enum class InternalKind { FILES, TASKS, NOTES, SETTINGS, SHIZUKU, ABOUT }
data class InternalWindow(val id: Int, val kind: InternalKind, val path: String? = null, val minimized: Boolean = false)

/** State duy nhất của màn hình (MVI). */
data class DesktopState(
    val booting: Boolean = false,
    val booted: Boolean = false,
    val privilege: PrivilegeChecker.Mode = PrivilegeChecker.Mode.NONE,
    val compatOk: Boolean? = null,
    val settings: AppSettings = AppSettings(),
    val apps: List<AppInfo> = emptyList(),
    val pinned: List<PinnedAppEntity> = emptyList(),
    val shortcuts: List<DesktopShortcut> = emptyList(),
    val windows: List<WindowInfo> = emptyList(),
    val notifs: List<NotifItem> = emptyList(),
    val internalWindows: List<InternalWindow> = emptyList(),
    val startOpen: Boolean = false,
    val controlCenterOpen: Boolean = false,
    val screen: ScreenMetrics = ScreenMetrics(),
    val gridCols: Int = 10,
    val gridRows: Int = 6,
    val screenOn: Boolean = true,
    val maximizedAppActive: Boolean = false,
    val hasHardKeyboard: Boolean = false,
    val battery: BatteryState = BatteryState(),
    val wifi: WifiState = WifiState(),
    val clockMs: Long = System.currentTimeMillis()
) {
    val activeWindow: WindowInfo? get() = windows.firstOrNull()
}

sealed interface DesktopIntent {
    object Boot : DesktopIntent
    object ToggleStart : DesktopIntent
    object ToggleControlCenter : DesktopIntent
    object CloseOverlays : DesktopIntent
    data class UpdateScreen(val m: ScreenMetrics) : DesktopIntent
    data class UpdateGrid(val cols: Int, val rows: Int) : DesktopIntent
    data class HardKeyboard(val present: Boolean) : DesktopIntent

    // Ứng dụng & Dock
    data class LaunchApp(val pkg: String, val fullscreen: Boolean = false) : DesktopIntent
    data class PinDock(val pkg: String) : DesktopIntent
    data class UnpinDock(val pkg: String) : DesktopIntent
    data class PinStart(val pkg: String) : DesktopIntent
    data class UnpinStart(val pkg: String) : DesktopIntent
    data class ForceStop(val pkg: String) : DesktopIntent
    data class AppInfoScreen(val pkg: String) : DesktopIntent

    // Shortcut
    data class DropApp(val pkg: String, val col: Int, val row: Int) : DesktopIntent
    data class DropFile(val path: String, val name: String, val col: Int, val row: Int) : DesktopIntent
    data class MoveShortcut(val id: Long, val col: Int, val row: Int) : DesktopIntent
    data class RemoveShortcut(val id: Long) : DesktopIntent
    data class OpenShortcut(val id: Long, val fullscreen: Boolean = false) : DesktopIntent
    data class PinShortcutToDock(val id: Long) : DesktopIntent
    object ArrangeIcons : DesktopIntent
    object NewFolder : DesktopIntent

    // Cửa sổ nội bộ + cửa sổ ngoài
    data class OpenInternal(val kind: InternalKind, val path: String? = null) : DesktopIntent
    data class CloseInternal(val id: Int) : DesktopIntent
    data class FocusInternal(val id: Int) : DesktopIntent
    data class MinimizeInternal(val id: Int) : DesktopIntent
    data class ToggleInternal(val id: Int) : DesktopIntent
    data class DropTool(val key: String, val col: Int, val row: Int) : DesktopIntent
    object RefreshApps : DesktopIntent
    data class Snap(val region: SnapRegion) : DesktopIntent
    object ShowDesktop : DesktopIntent
    object CloseActiveWindow : DesktopIntent
    object CycleWindow : DesktopIntent
    data class OpenFile(val path: String) : DesktopIntent

    // Hình nền / DPI
    data class PickWallpaper(val uri: Uri) : DesktopIntent
    data class ApplyWallpaper(val item: WallpaperItem) : DesktopIntent
    data class DeleteWallpaper(val item: WallpaperItem) : DesktopIntent
    object ClearWallpaper : DesktopIntent
    data class SetDpi(val dpi: Int) : DesktopIntent
    object ResetDpi : DesktopIntent
    data class SetKiosk(val on: Boolean) : DesktopIntent

    // Control Center
    data class ToggleWifi(val on: Boolean) : DesktopIntent
    data class ToggleBluetooth(val on: Boolean) : DesktopIntent
    data class AutoBrightnessLock(val on: Boolean) : DesktopIntent
    data class SetBrightness(val v: Int) : DesktopIntent
    data class SetVolume(val v: Int) : DesktopIntent
    data class OpenNotif(val item: NotifItem) : DesktopIntent
    data class DismissNotif(val key: String) : DesktopIntent

    // Nguồn
    object RestartUi : DesktopIntent
    object Shutdown : DesktopIntent
    object Panic : DesktopIntent
}

sealed interface DesktopEffect {
    data class Toast(val msg: String) : DesktopEffect
    data class EnterKiosk(val lock: Boolean) : DesktopEffect
    object Recreate : DesktopEffect
    object ExitToLauncher : DesktopEffect
}
