package com.minipc.desktop.ui.startmenu

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.domain.model.AppInfo
import com.minipc.desktop.domain.usecase.FuzzyMatcher
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.theme.Accent

/** 6.3 – Start Menu: trượt từ trên xuống, tìm kiếm mờ, kéo icon ra Desktop. */
@Composable
fun StartMenu(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val dd = LocalDragDrop.current
    // Giữ composition khi đang kéo (nếu bỏ đi, cử chỉ kéo sẽ bị huỷ) – chỉ làm trong suốt để lộ Desktop.
    val visible = state.startOpen || dd.payload is DragPayload.App
    AnimatedVisibility(
        visible, modifier,
        enter = slideInVertically { -it / 3 } + fadeIn(),
        exit = slideOutVertically { -it / 3 } + fadeOut()
    ) {
        GlassSurface(
            Modifier.width(640.dp).height(480.dp).alpha(if (dd.active) 0f else 1f),
            RoundedCornerShape(20.dp), tint = Color(0xD91C1F24)
        ) { StartContent(state, onIntent) }
    }
}

@Composable
private fun StartContent(state: DesktopState, onIntent: (DesktopIntent) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, state.apps) { FuzzyMatcher.search(query, state.apps) }
    val pinnedApps = remember(state.pinned, state.apps) {
        state.pinned.filter { it.inStartMenu }.mapNotNull { p -> state.apps.firstOrNull { it.packageName == p.packageName } }
    }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, null, tint = Color(0xFFBBBBBB), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text("Nhập để tìm ứng dụng…", color = Color(0xFF999999), fontSize = 14.sp)
                BasicTextField(
                    query, { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp), cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { results.firstOrNull()?.let { onIntent(DesktopIntent.LaunchApp(it.packageName)) } }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(GridCells.Adaptive(92.dp), Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (query.isBlank() && pinnedApps.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { Section("Đã ghim") }
                items(pinnedApps, key = { "p_" + it.packageName }) { AppTile(it, state, onIntent) }
                item(span = { GridItemSpan(maxLineSpan) }) { Section("Tất cả ứng dụng") }
            }
            items(results, key = { it.packageName }) { AppTile(it, state, onIntent) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Mini PC", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.PowerSettingsNew, "Shutdown", tint = Color.White,
                modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).clickable { onIntent(DesktopIntent.Shutdown) }.padding(6.dp))
        }
    }
}

@Composable
private fun Section(t: String) = Text(t, color = Color(0xFFCCCCCC), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))

@Composable
private fun AppTile(app: AppInfo, state: DesktopState, onIntent: (DesktopIntent) -> Unit) {
    val dd = LocalDragDrop.current
    val overlay = LocalOverlay.current
    val onDock = state.pinned.any { it.packageName == app.packageName && it.onDock }
    val inStart = state.pinned.any { it.packageName == app.packageName && it.inStartMenu }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .dragSource(dd, DragPayload.App(app.packageName, app.label))
            .pointerInput(app.packageName) { detectTapGestures(onTap = { onIntent(DesktopIntent.LaunchApp(app.packageName)) }) }
            .secondaryClick { pos ->
                overlay.showMenu(pos, listOf(
                    MenuItem("Mở cửa sổ") { onIntent(DesktopIntent.LaunchApp(app.packageName)) },
                    MenuItem("Mở toàn màn hình") { onIntent(DesktopIntent.LaunchApp(app.packageName, true)) },
                    MenuItem(if (inStart) "Bỏ ghim khỏi Start" else "Ghim vào Start") {
                        onIntent(if (inStart) DesktopIntent.UnpinStart(app.packageName) else DesktopIntent.PinStart(app.packageName))
                    },
                    MenuItem(if (onDock) "Bỏ ghim khỏi Dock" else "Ghim lên Dock") {
                        onIntent(if (onDock) DesktopIntent.UnpinDock(app.packageName) else DesktopIntent.PinDock(app.packageName))
                    },
                    MenuItem("Thông tin ứng dụng") { onIntent(DesktopIntent.AppInfoScreen(app.packageName)) }
                ))
            }.padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app.packageName, 44.dp)
        Spacer(Modifier.height(4.dp))
        Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 13.sp)
    }
}
