package com.minipc.desktop.core.window

import com.minipc.desktop.domain.model.Bounds
import kotlin.math.floor
import kotlin.math.roundToInt

enum class SnapRegion { LEFT, RIGHT, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, MAXIMIZE }

object WindowMath {
    /** Khung mặc định: 60% diện tích, căn giữa vùng dưới Top Dock. */
    fun defaultBounds(w: Int, h: Int, topInset: Int): Bounds {
        val aw = (w * 0.6f).roundToInt()
        val ah = ((h - topInset) * 0.6f).roundToInt()
        val l = (w - aw) / 2
        val t = topInset + (h - topInset - ah) / 2
        return Bounds(l, t, l + aw, t + ah)
    }

    /** Luôn cộng bù top = topInset để thanh tiêu đề không bị dock che. */
    fun region(r: SnapRegion, w: Int, h: Int, topInset: Int): Bounds {
        val midX = w / 2
        val midY = topInset + (h - topInset) / 2
        return when (r) {
            SnapRegion.MAXIMIZE -> Bounds(0, topInset, w, h)
            SnapRegion.LEFT -> Bounds(0, topInset, midX, h)
            SnapRegion.RIGHT -> Bounds(midX, topInset, w, h)
            SnapRegion.TOP_LEFT -> Bounds(0, topInset, midX, midY)
            SnapRegion.TOP_RIGHT -> Bounds(midX, topInset, w, midY)
            SnapRegion.BOTTOM_LEFT -> Bounds(0, midY, midX, h)
            SnapRegion.BOTTOM_RIGHT -> Bounds(midX, midY, w, h)
        }
    }

    fun clampBelowDock(b: Bounds, topInset: Int): Bounds =
        if (b.top >= topInset) b else Bounds(b.left, topInset, b.right, b.bottom + (topInset - b.top))
}

/** Ma trận lưới Desktop: ánh xạ pixel (root) <-> ô (col,row). */
data class GridSpec(
    val originX: Float = 0f, val originY: Float = 0f,
    val widthPx: Float = 0f, val heightPx: Float = 0f,
    val cellW: Float = 1f, val cellH: Float = 1f
) {
    val cols get() = floor(widthPx / cellW).toInt().coerceAtLeast(1)
    val rows get() = floor(heightPx / cellH).toInt().coerceAtLeast(1)

    fun contains(x: Float, y: Float) =
        x >= originX && y >= originY && x < originX + widthPx && y < originY + heightPx

    fun cellOf(x: Float, y: Float): Pair<Int, Int> =
        floor((x - originX) / cellW).toInt().coerceIn(0, cols - 1) to
            floor((y - originY) / cellH).toInt().coerceIn(0, rows - 1)

    /** Pixel góc trên-trái của ô, tính trong hệ toạ độ của vùng lưới. */
    fun cellOffset(col: Int, row: Int) = (col * cellW).roundToInt() to (row * cellH).roundToInt()
}
