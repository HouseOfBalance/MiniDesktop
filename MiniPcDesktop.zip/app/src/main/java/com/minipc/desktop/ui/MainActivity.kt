package com.minipc.desktop.ui

import android.app.ActivityOptions
import android.content.Intent
import android.content.res.Configuration
import android.hardware.input.InputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.minipc.desktop.core.kiosk.ImmersiveController
import com.minipc.desktop.core.kiosk.LauncherUtils
import com.minipc.desktop.core.window.ExternalDisplayMonitor
import com.minipc.desktop.domain.model.ScreenMetrics
import com.minipc.desktop.ui.external.ExternalDesktopActivity
import com.minipc.desktop.ui.external.TouchpadScreen
import com.minipc.desktop.ui.theme.MiniPcTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject lateinit var vm: DesktopViewModel
    @Inject lateinit var monitor: ExternalDisplayMonitor
    private val keys by lazy { KeyRouter(vm) }
    private val handler = Handler(Looper.getMainLooper())
    private var launchedFor = -1

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(id: Int) = checkKeyboard()
        override fun onInputDeviceRemoved(id: Int) = checkKeyboard()
        override fun onInputDeviceChanged(id: Int) = checkKeyboard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ImmersiveController.apply(this)

        // Nuốt toàn bộ thao tác Back ở màn hình chính
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* chặn */ }
        })

        pushScreenMetrics()
        getSystemService(InputManager::class.java).registerInputDeviceListener(inputListener, handler)
        checkKeyboard()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.CREATED) {
                vm.effects.collect { e ->
                    when (e) {
                        is DesktopEffect.Toast -> Toast.makeText(this@MainActivity, e.msg, Toast.LENGTH_SHORT).show()
                        is DesktopEffect.EnterKiosk -> runCatching { if (e.lock) startLockTask() else stopLockTask() }
                        DesktopEffect.Recreate -> recreate()
                        DesktopEffect.ExitToLauncher -> {
                            runCatching { stopLockTask() }
                            LauncherUtils.launchOriginalHome(this@MainActivity)
                            finishAndRemoveTask()
                        }
                    }
                }
            }
        }

        // Cắm màn hình ngoài → chiếu desktop sang đó, điện thoại thành touchpad
        lifecycleScope.launch {
            combine(monitor.displayId, vm.state.map { it.booted && it.settings.externalDesktop }.distinctUntilChanged()) { id, ok -> id to ok }
                .collect { (id, ok) ->
                    if (id == null) launchedFor = -1
                    else if (ok && launchedFor != id && !vm.externalActive.value) { launchedFor = id; launchExternal(id) }
                }
        }
        // Ngừng chiếu → lấy lại kích thước màn hình điện thoại
        lifecycleScope.launch { vm.externalActive.collect { if (!it) pushScreenMetrics() } }

        setContent {
            MiniPcTheme {
                val external by vm.externalActive.collectAsState()
                if (external) TouchpadScreen(vm) else DesktopRoot(vm)
            }
        }
    }

    private fun launchExternal(displayId: Int) {
        runCatching {
            val opts = ActivityOptions.makeBasic().setLaunchDisplayId(displayId)
            startActivity(
                Intent(this, ExternalDesktopActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK),
                opts.toBundle()
            )
        }
    }

    private fun pushScreenMetrics() {
        if (vm.externalActive.value) return
        val dm = resources.displayMetrics
        vm.onIntent(DesktopIntent.UpdateScreen(ScreenMetrics(dm.widthPixels, dm.heightPixels, dm.density)))
    }

    /** Phát hiện bàn phím vật lý/Bluetooth để ẩn bàn phím ảo. */
    private fun checkKeyboard() {
        val has = InputDevice.getDeviceIds().any { id ->
            InputDevice.getDevice(id)?.let { d ->
                !d.isVirtual && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
                    (d.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
            } == true
        } || resources.configuration.keyboard != Configuration.KEYBOARD_NOKEYS
        if (has != vm.state.value.hasHardKeyboard) vm.onIntent(DesktopIntent.HardKeyboard(has))
        if (has) ImmersiveController.hideIme(this)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        pushScreenMetrics()
        checkKeyboard()
        ImmersiveController.apply(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ImmersiveController.apply(this)
    }

    override fun onStart() { super.onStart(); vm.onReturn() }
    override fun onStop() { super.onStop(); vm.onLeave() }
    override fun onResume() { super.onResume(); ImmersiveController.apply(this) }

    /** Bấm Home (launcher) khi đang ở desktop → đóng các menu. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.onIntent(DesktopIntent.CloseOverlays)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (keys.dispatch(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        keys.release()
        getSystemService(InputManager::class.java).unregisterInputDeviceListener(inputListener)
        if (isFinishing) vm.emergencyRestore()   // mọi luồng thoát đều trả DPI
        super.onDestroy()
    }
}
