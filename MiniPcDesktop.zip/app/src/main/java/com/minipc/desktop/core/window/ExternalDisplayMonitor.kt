package com.minipc.desktop.core.window

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Theo dõi màn hình ngoài (HDMI / USB-C / không dây) cắm vào hoặc rút ra. */
@Singleton
class ExternalDisplayMonitor @Inject constructor(@ApplicationContext ctx: Context) {
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val _id = MutableStateFlow(find())
    val displayId: StateFlow<Int?> = _id.asStateFlow()

    init {
        dm.registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) { _id.value = find() }
            override fun onDisplayRemoved(displayId: Int) { _id.value = find() }
            override fun onDisplayChanged(displayId: Int) {}
        }, Handler(Looper.getMainLooper()))
    }

    // Chỉ lấy màn hình dạng "presentation" (màn hình ngoài thật); màn hình ảo của app không thuộc loại này.
    private fun find(): Int? = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        .firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }?.displayId
}
