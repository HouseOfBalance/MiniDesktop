package com.minipc.desktop.core.window

import android.os.IBinder
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.os.SystemClock
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.Executors

/**
 * Gửi cảm ứng/phím vào một màn hình ảo cụ thể, chạy với quyền shell qua Shizuku
 * (IInputManager.injectInputEvent + InputEvent.setDisplayId).
 */
object InputInjector {
    private var service: Any? = null
    private var inject: Method? = null
    private var setDisplay: Method? = null
    private val executor = Executors.newSingleThreadExecutor()

    @Synchronized
    fun available(): Boolean {
        if (service != null) return true
        return runCatching {
            val binder = SystemServiceHelper.getSystemService("input") ?: return false
            val wrapped = ShizukuBinderWrapper(binder)
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            service = stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            setDisplay = InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
            true
        }.getOrDefault(false)
    }

    /** Sự kiện được gửi ở luồng nền riêng để không chặn UI. */
    fun send(ev: InputEvent, displayId: Int) {
        if (!available()) return
        executor.execute {
            runCatching { setDisplay!!.invoke(ev, displayId); inject!!.invoke(service, ev, 0) }
            (ev as? android.view.MotionEvent)?.recycle()
        }
    }

    fun key(displayId: Int, code: Int) {
        val t = SystemClock.uptimeMillis()
        for (action in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            send(KeyEvent(t, t, action, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, android.view.InputDevice.SOURCE_KEYBOARD), displayId)
        }
    }
}
