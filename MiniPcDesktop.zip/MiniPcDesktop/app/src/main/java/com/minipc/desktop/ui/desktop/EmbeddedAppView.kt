package com.minipc.desktop.ui.desktop

import android.graphics.SurfaceTexture
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.minipc.desktop.core.window.AppSessionManager

/**
 * Hiển thị màn hình ảo của một app và chuyển tiếp cảm ứng.
 *  - useSurfaceView = true (cửa sổ trên cùng): SurfaceView – nhẹ nhất, ít tốn GPU.
 *  - false (cửa sổ phía dưới): TextureView – xếp lớp đúng khi bị cửa sổ khác đè lên.
 */
@Composable
fun EmbeddedAppView(sessions: AppSessionManager, windowId: Int, useSurfaceView: Boolean, modifier: Modifier = Modifier) {
    key(useSurfaceView) {
        AndroidView(
            modifier = modifier,
            factory = { c ->
                val v: View = if (useSurfaceView) SurfaceView(c).apply {
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(h: SurfaceHolder) {}
                        override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, ht: Int) = sessions.attachSurface(windowId, h.surface, w, ht)
                        override fun surfaceDestroyed(h: SurfaceHolder) = sessions.detach(windowId)
                    })
                } else TextureView(c).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = sessions.attach(windowId, st, w, h)
                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = sessions.resize(windowId, w, h, st)
                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { sessions.detach(windowId); return true }
                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                    }
                }
                v.setOnTouchListener { view, e -> sessions.touch(windowId, view, e); true }
                v.setOnGenericMotionListener { view, e -> sessions.generic(windowId, view, e) }
                v
            }
        )
    }
}
