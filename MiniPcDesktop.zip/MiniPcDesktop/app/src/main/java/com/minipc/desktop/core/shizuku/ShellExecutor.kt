package com.minipc.desktop.core.shizuku

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import rikka.shizuku.Shizuku
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.concurrent.thread

/**
 * Hàng đợi lệnh trên Dispatchers.IO với 2 làn riêng biệt:
 *  - làn nhanh (mặc định): mở app, resize, bật/tắt… → luôn phản hồi tức thì;
 *  - làn nền (bg = true): dumpsys/top nặng → không bao giờ làm chậm thao tác của người dùng.
 */
@Singleton
class ShellExecutor @Inject constructor(private val privilege: PrivilegeChecker) {
    private class Job(val cmd: String, val result: CompletableDeferred<String>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private inner class Lane {
        private val queue = Channel<Job>(Channel.UNLIMITED)
        private var shell: PersistentShell? = null
        private var shellMode = PrivilegeChecker.Mode.NONE

        init { scope.launch { for (job in queue) job.result.complete(run(job.cmd)) } }

        suspend fun exec(cmd: String): String {
            val d = CompletableDeferred<String>()
            queue.send(Job(cmd, d))
            return d.await()
        }

        private fun run(cmd: String): String {
            return try {
                val mode = privilege.mode.value
                if (mode == PrivilegeChecker.Mode.NONE) return "ERROR: no privilege"
                if (shell == null || shellMode != mode) {
                    shell?.close()
                    shell = PersistentShell { spawn(mode) }
                    shellMode = mode
                }
                shell!!.exec(cmd)
            } catch (e: Throwable) {
                shell?.close(); shell = null
                "ERROR: ${e.message}"
            }
        }
    }

    private val fast = Lane()
    private val slow = Lane()

    val ready get() = privilege.mode.value != PrivilegeChecker.Mode.NONE

    suspend fun exec(cmd: String, bg: Boolean = false): String = (if (bg) slow else fast).exec(cmd)

    fun fire(cmd: String) { scope.launch { fast.exec(cmd) } }

    /** Chạy đồng bộ bằng process mới, không qua hàng đợi – dùng cho crash handler / panic. */
    fun oneShotBlocking(cmd: String, timeoutMs: Long = 3000): String {
        val mode = privilege.mode.value
        if (mode == PrivilegeChecker.Mode.NONE) return ""
        return runCatching {
            val p = spawn(mode)
            p.outputStream.bufferedWriter().use { it.write("$cmd\nexit\n") }
            val out = StringBuilder()
            val t = thread { runCatching { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } }
            t.join(timeoutMs)
            p.destroy()
            out.toString()
        }.getOrDefault("")
    }

    private fun spawn(mode: PrivilegeChecker.Mode): Process = when (mode) {
        PrivilegeChecker.Mode.SHIZUKU -> {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, arrayOf("sh"), null, null) as Process
        }
        PrivilegeChecker.Mode.ROOT -> Runtime.getRuntime().exec("su")
        PrivilegeChecker.Mode.NONE -> error("no privilege")
    }
}
