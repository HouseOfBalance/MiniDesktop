package com.minipc.desktop.core.window

import android.os.IBinder
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import android.os.SystemClock
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method
import java.util.concurrent.Executors

/**
 * Gửi cảm ứng/phím vào một màn hình ảo cụ thể, chạy với quyền shell qua Shizuku
 * (IInputManager.injectInputEvent + InputEvent.setDisplayId).
 */
object InputInjector {
    private var service: Any? = null
    private var inject: Method? = null
    private var setDisplay: Method? = null
    private val executor = Executors.newSingleThreadExecutor()

    @Synchronized
    fun available(): Boolean {
        if (service != null) return true
        return runCatching {
            val binder = SystemServiceHelper.getSystemService("input") ?: return false
            val wrapped = ShizukuBinderWrapper(binder)
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            service = stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            setDisplay = InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
            true
        }.getOrDefault(false)
    }

    /** Gọi khi Shizuku chết/được nối lại để bind lại dịch vụ input. */
    @Synchronized fun reset() { service = null; inject = null; setDisplay = null }

    private var downTime = 0L

    private fun props() = arrayOf(MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE })

    /** Sự kiện chuột (touchpad → màn hình ngoài). */
    fun mouse(displayId: Int, action: Int, x: Float, y: Float, buttons: Int) {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val c = arrayOf(MotionEvent.PointerCoords().apply { this.x = x; this.y = y; pressure = 1f; size = 1f })
        send(MotionEvent.obtain(if (downTime > 0) downTime else now, now, action, 1, props(), c, 0, buttons, 1f, 1f, 0, 0,
            android.view.InputDevice.SOURCE_MOUSE, 0), displayId)
    }

    fun scroll(displayId: Int, x: Float, y: Float, v: Float) {
        val now = SystemClock.uptimeMillis()
        val c = arrayOf(MotionEvent.PointerCoords().apply { this.x = x; this.y = y; setAxisValue(MotionEvent.AXIS_VSCROLL, v) })
        send(MotionEvent.obtain(now, now, MotionEvent.ACTION_SCROLL, 1, props(), c, 0, 0, 1f, 1f, 0, 0,
            android.view.InputDevice.SOURCE_MOUSE, 0), displayId)
    }

    /** Sự kiện được gửi ở luồng nền riêng để không chặn UI. */
    private val pending = java.util.concurrent.atomic.AtomicInteger(0)

    fun send(ev: InputEvent, displayId: Int) {
        if (!available()) { (ev as? MotionEvent)?.recycle(); return }
        // Hàng đợi dồn (app chậm) → bỏ bớt MOVE trung gian để cảm ứng không bị trễ tích luỹ
        if (ev is MotionEvent && ev.actionMasked == MotionEvent.ACTION_MOVE && pending.get() > 6) { ev.recycle(); return }
        pending.incrementAndGet()
        executor.execute {
            try { runCatching { setDisplay!!.invoke(ev, displayId); inject!!.invoke(service, ev, 0) } }
            finally { pending.decrementAndGet(); (ev as? MotionEvent)?.recycle() }
        }
    }

    fun key(displayId: Int, code: Int) {
        val t = SystemClock.uptimeMillis()
        for (action in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            send(KeyEvent(t, t, action, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, android.view.InputDevice.SOURCE_KEYBOARD), displayId)
        }
    }
}
