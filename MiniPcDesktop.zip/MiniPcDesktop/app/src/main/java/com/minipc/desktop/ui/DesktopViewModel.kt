package com.minipc.desktop.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.view.KeyEvent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.minipc.desktop.core.shizuku.DpiScaler
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.core.shizuku.ShellExecutor
import com.minipc.desktop.core.utils.FailSafe
import com.minipc.desktop.core.utils.Permissions
import com.minipc.desktop.core.window.AppSessionManager
import com.minipc.desktop.data.db.*
import com.minipc.desktop.data.preferences.SettingsStore
import com.minipc.desktop.data.repository.*
import com.minipc.desktop.domain.model.*
import com.minipc.desktop.domain.usecase.SpatialGridMap
import com.minipc.desktop.domain.usecase.SpiralSearch
import com.minipc.desktop.ui.tools.Tool
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class DesktopViewModel @Inject constructor(
    @ApplicationContext private val ctx: Context,
    val privilege: PrivilegeChecker,
    private val shell: ShellExecutor,
    private val settings: SettingsStore,
    private val dpi: DpiScaler,
    private val appRepo: AppRepository,
    val iconCache: IconCache,
    private val shortcutDao: ShortcutDao,
    private val pinnedDao: PinnedAppDao,
    private val notifRepo: NotificationRepository,
    val wallpaperRepo: WallpaperRepository,
    val fileRepo: FileRepository,
    val metricsRepo: MetricsRepository,
    status: SystemStatusRepository,
    private val failSafe: FailSafe,
    val sessions: AppSessionManager
) : ViewModel() {

    private val _state = MutableStateFlow(DesktopState())
    val state: StateFlow<DesktopState> = _state.asStateFlow()
    private val _effects = Channel<DesktopEffect>(Channel.BUFFERED)
    val effects = _effects.receiveAsFlow()

    private val gridMap = SpatialGridMap()
    private var nextWinId = 1
    private var leaveJob: Job? = null

    private inline fun mutate(f: DesktopState.() -> DesktopState) = _state.update { it.f() }
    private fun toast(m: String) { _effects.trySend(DesktopEffect.Toast(m)) }

    init {
        privilege.mode.onEach { m -> mutate { copy(privilege = m) } }.launchIn(viewModelScope)
        settings.flow.onEach { s -> mutate { copy(settings = s) } }.launchIn(viewModelScope)
        appRepo.apps.onEach { a -> mutate { copy(apps = a) } }.launchIn(viewModelScope)
        pinnedDao.observeAll().onEach { p -> mutate { copy(pinned = p) } }.launchIn(viewModelScope)
        shortcutDao.observeAll().map { l -> l.map { it.toDomain() } }.onEach { l ->
            gridMap.rebuild(l); mutate { copy(shortcuts = l) }
        }.launchIn(viewModelScope)
        notifRepo.items.onEach { n -> mutate { copy(notifs = n) } }.launchIn(viewModelScope)
        status.screenOn.onEach { v -> mutate { copy(screenOn = v) } }.launchIn(viewModelScope)
        status.battery.onEach { v -> mutate { copy(battery = v) } }.launchIn(viewModelScope)
        status.wifi.onEach { v -> mutate { copy(wifi = v) } }.launchIn(viewModelScope)
        status.clock.onEach { v -> mutate { copy(clockMs = v) } }.launchIn(viewModelScope)
        sessions.failures.onEach { toast(it) }.launchIn(viewModelScope)
        appRepo.start()
        autoStart()
    }

    private fun autoStart() = viewModelScope.launch {
        if (!settings.current().onboardingDone) return@launch
        withTimeoutOrNull(3000) { privilege.mode.first { it != PrivilegeChecker.Mode.NONE } }
        if (corePermissionsReady()) boot()
    }

    fun corePermissionsReady() = privilege.mode.value != PrivilegeChecker.Mode.NONE &&
        Permissions.notificationListenerEnabled(ctx) && Permissions.allFilesAccess(ctx)

    private fun ShortcutEntity.toDomain() = DesktopShortcut(
        id, runCatching { ShortcutType.valueOf(type) }.getOrDefault(ShortcutType.APP),
        packageName, title, filePath, gridCol, gridRow, Bounds.parse(lastBounds)
    )

    // ---------------- Intent handler ----------------
    fun onIntent(i: DesktopIntent) {
        val s = _state.value
        when (i) {
            DesktopIntent.Boot -> boot()
            DesktopIntent.ToggleStart -> mutate { copy(startOpen = !startOpen, controlCenterOpen = false, searchFocus = false) }
            DesktopIntent.OpenSearch -> mutate { copy(startOpen = true, controlCenterOpen = false, searchFocus = true) }
            DesktopIntent.ToggleControlCenter -> mutate { copy(controlCenterOpen = !controlCenterOpen, startOpen = false) }
            DesktopIntent.CloseOverlays -> mutate { copy(startOpen = false, controlCenterOpen = false, searchFocus = false) }
            is DesktopIntent.UpdateScreen -> mutate { copy(screen = i.m) }
            is DesktopIntent.UpdateGrid -> mutate { copy(gridCols = i.cols, gridRows = i.rows) }
            is DesktopIntent.HardKeyboard -> {
                mutate { copy(hasHardKeyboard = i.present) }
                if (dpi.active) applyIme(i.present)
            }

            // ----- Ứng dụng -----
            is DesktopIntent.LaunchApp -> { mutate { copy(startOpen = false) }; if (i.fullscreen) launchExternal(i.pkg) else openApp(i.pkg) }
            is DesktopIntent.PinDock -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg)
                pinnedDao.upsert(PinnedAppEntity(i.pkg, true, o?.inStartMenu ?: false, o?.sortOrder ?: (pinnedDao.maxOrder() + 1)))
            }
            is DesktopIntent.UnpinDock -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg) ?: return@launch
                if (o.inStartMenu) pinnedDao.upsert(o.copy(onDock = false)) else pinnedDao.delete(i.pkg)
            }
            is DesktopIntent.PinStart -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg)
                pinnedDao.upsert(PinnedAppEntity(i.pkg, o?.onDock ?: false, true, o?.sortOrder ?: (pinnedDao.maxOrder() + 1)))
            }
            is DesktopIntent.UnpinStart -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg) ?: return@launch
                if (o.onDock) pinnedDao.upsert(o.copy(inStartMenu = false)) else pinnedDao.delete(i.pkg)
            }
            is DesktopIntent.ForceStop -> {
                s.internalWindows.firstOrNull { it.kind == InternalKind.APP && it.pkg == i.pkg }?.let { onIntent(DesktopIntent.CloseInternal(it.id)) }
                shell.fire("am force-stop ${i.pkg}")
            }
            is DesktopIntent.AppInfoScreen -> ctx.startActivity(Permissions.appInfoIntent(i.pkg))

            // ----- Shortcut -----
            is DesktopIntent.DropApp -> viewModelScope.launch {
                val app = s.apps.firstOrNull { it.packageName == i.pkg } ?: return@launch
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = i.pkg, title = app.label, type = "APP", gridCol = c, gridRow = r))
                } ?: toast("Desktop đã đầy")
            }
            is DesktopIntent.DropFile -> viewModelScope.launch {
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = "", title = i.name, type = "FILE", gridCol = c, gridRow = r, filePath = i.path))
                } ?: toast("Desktop đã đầy")
            }
            is DesktopIntent.DropTool -> viewModelScope.launch {
                val t = Tool.fromKey(i.key) ?: return@launch
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = t.key, title = t.label, type = "TOOL", gridCol = c, gridRow = r))
                } ?: toast("Desktop đã đầy")
            }
            is DesktopIntent.MoveShortcut -> viewModelScope.launch {
                place(i.col, i.row, ignoreId = i.id)?.let { (c, r) -> shortcutDao.move(i.id, c, r) }
            }
            is DesktopIntent.RemoveShortcut -> viewModelScope.launch { shortcutDao.delete(i.id) }
            is DesktopIntent.OpenShortcut -> s.shortcuts.firstOrNull { it.id == i.id }?.let { sc ->
                when (sc.type) {
                    ShortcutType.APP -> if (i.fullscreen) launchExternal(sc.packageName) else openApp(sc.packageName)
                    ShortcutType.TOOL -> Tool.fromKey(sc.packageName)?.let { onIntent(DesktopIntent.OpenInternal(it.kind)) }
                    ShortcutType.FILE -> sc.filePath?.let { p ->
                        if (java.io.File(p).isDirectory) onIntent(DesktopIntent.OpenInternal(InternalKind.FILES, p))
                        else onIntent(DesktopIntent.OpenFile(p))
                    }
                }
            }
            is DesktopIntent.PinShortcutToDock -> s.shortcuts.firstOrNull { it.id == i.id }
                ?.takeIf { it.type == ShortcutType.APP }?.let { onIntent(DesktopIntent.PinDock(it.packageName)) }
            DesktopIntent.ArrangeIcons -> viewModelScope.launch {
                val rows = s.gridRows.coerceAtLeast(1)
                s.shortcuts.sortedBy { it.title.lowercase() }.forEachIndexed { idx, sc -> shortcutDao.move(sc.id, idx / rows, idx % rows) }
            }
            DesktopIntent.NewFolder -> viewModelScope.launch(Dispatchers.IO) {
                val dir = fileRepo.desktopDir()
                var n = 0
                var name = "Thư mục mới"
                while (java.io.File(dir, name).exists()) { n++; name = "Thư mục mới ($n)" }
                fileRepo.createFolder(dir.path, name)
                place(0, 0)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = "", title = name, type = "FILE", gridCol = c, gridRow = r,
                        filePath = java.io.File(dir, name).path))
                }
            }
            DesktopIntent.RefreshApps -> appRepo.scan()

            // ----- Cửa sổ -----
            is DesktopIntent.OpenInternal -> {
                val existing = if (i.kind != InternalKind.FILES) s.internalWindows.firstOrNull { it.kind == i.kind } else null
                mutate { copy(startOpen = false) }
                if (existing != null) reveal(existing.id)
                else {
                    val id = nextWinId++
                    mutate { copy(internalWindows = internalWindows + InternalWindow(id, i.kind, i.path)) }
                    if (s.stageEnabled) applyStage(id)
                }
            }
            is DesktopIntent.CloseInternal -> {
                sessions.close(i.id)
                mutate { copy(internalWindows = internalWindows.filterNot { it.id == i.id }, stageGroup = stageGroup - i.id) }
            }
            is DesktopIntent.FocusInternal -> mutate {
                val w = internalWindows.firstOrNull { it.id == i.id }
                if (w == null || internalWindows.last() == w) this else copy(internalWindows = internalWindows - w + w)
            }
            is DesktopIntent.MinimizeInternal -> mutate {
                copy(internalWindows = internalWindows.map { if (it.id == i.id) it.copy(minimized = true) else it })
            }
            is DesktopIntent.ToggleInternal -> {
                val w = s.internalWindows.firstOrNull { it.id == i.id }
                if (w != null) {
                    val top = s.internalWindows.lastOrNull { !it.minimized }
                    if (w.minimized || top != w) reveal(w.id)
                    else mutate { copy(internalWindows = internalWindows.map { if (it.id == w.id) it.copy(minimized = true) else it }) }
                }
            }
            DesktopIntent.ShowDesktop -> {
                mutate { copy(startOpen = false, controlCenterOpen = false, internalWindows = internalWindows.map { it.copy(minimized = true) }) }
                shell.fire("am start -n ${ctx.packageName}/${MainActivity::class.java.name}")
            }
            DesktopIntent.CloseActiveWindow -> s.internalWindows.lastOrNull { !it.minimized }?.let { onIntent(DesktopIntent.CloseInternal(it.id)) }
            DesktopIntent.CycleWindow -> s.internalWindows.takeIf { it.size > 1 }?.first()?.let { reveal(it.id) }
            is DesktopIntent.OpenFile -> viewModelScope.launch(Dispatchers.IO) {
                if (!fileRepo.open(i.path)) toast("Không có ứng dụng mở tệp này")
            }

            // ----- Stage Manager -----
            DesktopIntent.ToggleStage -> viewModelScope.launch {
                val on = !_state.value.stageEnabled
                mutate { copy(settings = settings.copy(stageManager = on)) }
                settings.setStage(on)
                if (on) _state.value.internalWindows.lastOrNull { !it.minimized }?.let { applyStage(it.id) }
                else mutate { copy(stageGroup = emptySet()) }
            }
            is DesktopIntent.StageSwap -> if (i.addToGroup) { applyStage(i.windowId, add = true) } else reveal(i.windowId)

            // ----- Hình nền / DPI -----
            is DesktopIntent.PickWallpaper -> viewModelScope.launch {
                wallpaperRepo.import(i.uri)?.let { wallpaperRepo.apply(it) } ?: toast("Tệp không hợp lệ")
            }
            is DesktopIntent.ApplyWallpaper -> viewModelScope.launch { wallpaperRepo.apply(i.item) }
            is DesktopIntent.DeleteWallpaper -> viewModelScope.launch { wallpaperRepo.delete(i.item) }
            DesktopIntent.ClearWallpaper -> viewModelScope.launch { wallpaperRepo.clear() }
            is DesktopIntent.SetDpi -> viewModelScope.launch {
                val v = i.dpi.coerceIn(120, 480); dpi.apply(v); settings.setCustomDpi(v)
            }
            DesktopIntent.ResetDpi -> viewModelScope.launch {
                settings.setCustomDpi(0)
                dpi.apply(dpi.optimal(s.screen.widthPx, s.screen.heightPx))
            }
            is DesktopIntent.SetKiosk -> viewModelScope.launch {
                settings.setKiosk(i.on); _effects.send(DesktopEffect.EnterKiosk(i.on))
            }

            // ----- Control Center -----
            is DesktopIntent.ToggleWifi -> shellOrSettings("svc wifi ${if (i.on) "enable" else "disable"}", Settings.ACTION_WIFI_SETTINGS)
            is DesktopIntent.ToggleBluetooth -> shellOrSettings("svc bluetooth ${if (i.on) "enable" else "disable"}", Settings.ACTION_BLUETOOTH_SETTINGS)
            is DesktopIntent.AutoBrightnessLock -> shell.fire("settings put system screen_brightness_mode ${if (i.on) 0 else 1}")
            is DesktopIntent.SetBrightness -> shell.fire("settings put system screen_brightness ${i.v.coerceIn(1, 255)}")
            is DesktopIntent.SetVolume -> ctx.getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_MUSIC, i.v, 0)
            is DesktopIntent.OpenNotif -> openNotification(i.item)
            is DesktopIntent.DismissNotif -> notifRepo.dismiss(i.key)

            // ----- Nguồn -----
            DesktopIntent.RestartUi -> viewModelScope.launch {
                mutate { copy(startOpen = false, controlCenterOpen = false) }
                _effects.send(DesktopEffect.Recreate)
            }
            DesktopIntent.Shutdown -> shutdown()
            DesktopIntent.Panic -> viewModelScope.launch {
                sessions.closeAll()
                failSafe.panicRestore(); settings.setKiosk(false)
                mutate { copy(booted = false, internalWindows = emptyList()) }
                _effects.send(DesktopEffect.ExitToLauncher)
            }
        }
    }

    // ---------------- Cửa sổ app trên màn hình ảo ----------------
    private fun openApp(pkg: String) {
        val s = _state.value
        val app = s.apps.firstOrNull { it.packageName == pkg } ?: return
        s.internalWindows.firstOrNull { it.kind == InternalKind.APP && it.pkg == pkg }?.let { reveal(it.id); return }
        if (!sessions.supported()) { toast("Cần Shizuku (không phải Root) đang chạy để mở app trong cửa sổ"); return }
        val id = nextWinId++
        sessions.open(id, pkg, app.component)
        mutate { copy(internalWindows = internalWindows + InternalWindow(id, InternalKind.APP, pkg = pkg, portrait = isPortrait(app.component), title = app.label)) }
        if (s.stageEnabled) applyStage(id)
    }

    /** App khoá dọc (như TikTok) → cửa sổ dạng điện thoại 9:16, còn lại dạng ngang. */
    private fun isPortrait(component: String): Boolean = runCatching {
        val cn = ComponentName.unflattenFromString(component)!!
        ctx.packageManager.getActivityInfo(cn, 0).screenOrientation in intArrayOf(1, 7, 9, 12)
    }.getOrDefault(false)

    private fun launchExternal(pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun reveal(id: Int) {
        mutate {
            val w = internalWindows.firstOrNull { it.id == id } ?: return@mutate this
            copy(internalWindows = internalWindows.filter { it.id != id } + w.copy(minimized = false))
        }
        if (_state.value.stageEnabled) applyStage(id)
    }

    /** Stage Manager: chỉ nhóm "sân khấu" hiển thị, các cửa sổ còn lại vào dải bên trái. */
    private fun applyStage(id: Int, add: Boolean = false) {
        mutate {
            val g = if (add) stageGroup + id else setOf(id)
            copy(stageGroup = g, internalWindows = internalWindows.map { it.copy(minimized = it.id !in g) })
        }
    }

    private fun openNotification(n: NotifItem) {
        viewModelScope.launch {
            mutate { copy(controlCenterOpen = false) }
            val pkg = n.packageName
            var display = -1
            if (_state.value.apps.any { it.packageName == pkg } && sessions.supported()) {
                openApp(pkg)
                val win = _state.value.internalWindows.firstOrNull { it.kind == InternalKind.APP && it.pkg == pkg }
                var tries = 0
                while (win != null && display < 0 && tries++ < 15) {
                    display = sessions.displayIdOf(win.id)
                    if (display < 0) delay(200)
                }
            }
            notifRepo.open(n, display)
        }
    }

    /** Chuyển phím vật lý vào app đang ở trên cùng (nếu không đang gõ trong Start Menu). */
    fun forwardKey(e: KeyEvent): Boolean {
        val s = _state.value
        if (s.startOpen || s.controlCenterOpen) return false
        val w = s.internalWindows.lastOrNull { !it.minimized } ?: return false
        if (w.kind != InternalKind.APP) return false
        when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_POWER,
            KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT -> return false
        }
        return sessions.forwardKey(w.id, e)
    }

    // ---------------- Helpers ----------------
    private fun place(col: Int, row: Int, ignoreId: Long = -1): Pair<Int, Int>? {
        val s = _state.value
        return SpiralSearch.findFree(col, row, s.gridCols, s.gridRows) { c, r -> gridMap.isOccupied(c, r, ignoreId) }
    }

    private fun shellOrSettings(cmd: String, action: String) {
        if (shell.ready) shell.fire(cmd) else ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun targetDpi(custom: Int): Int =
        if (custom > 0) custom else _state.value.screen.let { dpi.optimal(it.widthPx, it.heightPx) }

    private fun applyIme(hardKeyboard: Boolean) =
        shell.fire("settings put secure show_ime_with_hard_keyboard ${if (hardKeyboard) 0 else 1}")

    /** Trình tự khởi động: ghi nhớ DPI của bạn → áp DPI Desktop. Không đụng tới cờ đa cửa sổ của hệ thống nữa. */
    private fun boot() {
        if (_state.value.booting || _state.value.booted) return
        viewModelScope.launch {
            mutate { copy(booting = true) }
            val st = settings.current()
            if (shell.ready) {
                // Gỡ cờ desktop-mode từ bản cũ (làm app trên màn hình ảo bị bọc khung cửa sổ của ROM);
                // bật cho phép app đổi kích thước theo khung.
                shell.exec("settings put global force_desktop_mode_on_external_displays 0; settings put global enable_freeform_support 0")
                shell.exec("settings put global force_resizable_activities 1")
                dpi.beginSession()
                dpi.apply(targetDpi(st.customDpi))
                applyIme(_state.value.hasHardKeyboard)
            }
            val ok = sessions.supported()
            mutate { copy(compatOk = ok) }
            if (!ok) toast("Chưa mở được cửa sổ app: cần Shizuku đang chạy")
            if (!st.seeded && shortcutDao.getAll().isEmpty()) {
                listOf(Tool.NOTES to (0 to 0), Tool.SETTINGS to (1 to 0), Tool.SHIZUKU to (0 to 1), Tool.ABOUT to (1 to 1)).forEach { (t, pos) ->
                    shortcutDao.insert(ShortcutEntity(packageName = t.key, title = t.label, type = "TOOL", gridCol = pos.first, gridRow = pos.second))
                }
            }
            settings.setSeeded(true)
            settings.setOnboardingDone(true)
            mutate { copy(booted = true, booting = false) }
            _effects.send(DesktopEffect.EnterKiosk(st.kioskLocked))
        }
    }

    /** Shutdown: đóng mọi cửa sổ app → khôi phục DPI → (Activity) quay về launcher. */
    private fun shutdown() {
        viewModelScope.launch {
            sessions.closeAll()
            mutate { copy(internalWindows = emptyList(), startOpen = false, controlCenterOpen = false, stageGroup = emptySet()) }
            dpi.restore()
            shell.exec("settings put secure show_ime_with_hard_keyboard 1")
            mutate { copy(booted = false) }
            _effects.send(DesktopEffect.ExitToLauncher)
        }
    }

    /** Rời app (Activity.onStop): sau 1.5s trả DPI + cài đặt bàn phím về như cũ. */
    fun onLeave() {
        leaveJob?.cancel()
        leaveJob = viewModelScope.launch {
            delay(1500)
            if (dpi.active) {
                dpi.restore()
                shell.exec("settings put secure show_ime_with_hard_keyboard 1")
            }
        }
    }

    /** Quay lại app (Activity.onStart): áp lại DPI Desktop. */
    fun onReturn() {
        leaveJob?.cancel()
        if (!_state.value.booted || dpi.active || !shell.ready) return
        viewModelScope.launch {
            dpi.apply(targetDpi(settings.current().customDpi))
            applyIme(_state.value.hasHardKeyboard)
        }
    }

    /** Gọi từ Activity.onDestroy(isFinishing). */
    fun emergencyRestore() = failSafe.restoreBlocking()
}
