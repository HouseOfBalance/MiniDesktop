package com.minipc.desktop.data.repository

import android.content.*
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.PowerManager
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import javax.inject.Inject
import javax.inject.Singleton

data class BatteryState(val percent: Int = 0, val charging: Boolean = false)
data class WifiState(val enabled: Boolean = false, val connected: Boolean = false, val level: Int = 0) // level 0..4

/** 7.1 – Theo dõi pin, Wi-Fi, thời gian thực, trạng thái màn hình. */
@Singleton
class SystemStatusRepository @Inject constructor(@ApplicationContext private val ctx: Context) {

    val battery: Flow<BatteryState> = callbackFlow {
        fun read(i: Intent?) {
            if (i == null) return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            trySend(BatteryState(lvl * 100 / sc.coerceAtLeast(1),
                st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL))
        }
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = read(i) }
        read(ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED))
        awaitClose { runCatching { ctx.unregisterReceiver(r) } }
    }.distinctUntilChanged()

    @Suppress("DEPRECATION")
    private fun readWifi(): WifiState {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = runCatching { wm.connectionInfo }.getOrNull()
        val connected = wm.isWifiEnabled && info != null && info.networkId != -1
        return WifiState(wm.isWifiEnabled, connected, if (connected) WifiManager.calculateSignalLevel(info!!.rssi, 5) else 0)
    }

    val wifi: Flow<WifiState> = callbackFlow {
        val f = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION); addAction(WifiManager.RSSI_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
        }
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { trySend(readWifi()) } }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        trySend(readWifi())
        awaitClose { runCatching { ctx.unregisterReceiver(r) } }
    }.distinctUntilChanged()

    val clock: Flow<Long> = callbackFlow {
        val f = IntentFilter().apply { addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED) }
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { trySend(System.currentTimeMillis()) } }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        trySend(System.currentTimeMillis())
        awaitClose { runCatching { ctx.unregisterReceiver(r) } }
    }

    val screenOn: Flow<Boolean> = callbackFlow {
        val pm = ctx.getSystemService(PowerManager::class.java)
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { trySend(pm.isInteractive) } }
        ContextCompat.registerReceiver(ctx, r, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF)
        }, ContextCompat.RECEIVER_EXPORTED)
        trySend(pm.isInteractive)
        awaitClose { runCatching { ctx.unregisterReceiver(r) } }
    }.distinctUntilChanged()
}
