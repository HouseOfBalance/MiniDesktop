package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.geometry.Offset
import com.minipc.desktop.core.window.GridSpec
import com.minipc.desktop.domain.model.DesktopShortcut
import com.minipc.desktop.domain.model.ShortcutType
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import java.io.File

class GridHolder { var spec: GridSpec = GridSpec() }

fun shortcutMenu(sc: DesktopShortcut, onIntent: (DesktopIntent) -> Unit): List<MenuItem> =
    if (sc.type == ShortcutType.TOOL) listOf(
        MenuItem("Mở") { onIntent(DesktopIntent.OpenShortcut(sc.id)) },
        MenuItem("Xóa khỏi Desktop") { onIntent(DesktopIntent.RemoveShortcut(sc.id)) }
    ) else if (sc.type == ShortcutType.APP) listOf(
        MenuItem("Mở cửa sổ") { onIntent(DesktopIntent.OpenShortcut(sc.id)) },
        MenuItem("Mở toàn màn hình") { onIntent(DesktopIntent.OpenShortcut(sc.id, true)) },
        MenuItem("Ghim lên Top Dock") { onIntent(DesktopIntent.PinShortcutToDock(sc.id)) },
        MenuItem("Xóa khỏi Desktop") { onIntent(DesktopIntent.RemoveShortcut(sc.id)) },
        MenuItem("Thông tin ứng dụng") { onIntent(DesktopIntent.AppInfoScreen(sc.packageName)) }
    ) else listOf(
        MenuItem("Mở") { onIntent(DesktopIntent.OpenShortcut(sc.id)) },
        MenuItem("Xóa khỏi Desktop") { onIntent(DesktopIntent.RemoveShortcut(sc.id)) }
    )

/** 5.1/5.3 – Lưới Desktop + menu chuột phải vùng trống. */
@Composable
fun DesktopGrid(
    state: DesktopState,
    holder: GridHolder,
    onIntent: (DesktopIntent) -> Unit,
    onWallpaperDialog: () -> Unit,
    onDpiDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dd = LocalDragDrop.current
    val overlay = LocalOverlay.current
    val density = LocalDensity.current
    val cellW = with(density) { Dims.CellW.toPx() }
    val cellH = with(density) { Dims.CellH.toPx() }
    var selected by remember { mutableStateOf<Long?>(null) }
    var lastGrid by remember { mutableStateOf(0 to 0) }

    Box(
        modifier.fillMaxSize()
            .onGloballyPositioned { c ->
                val p = c.positionInRoot()
                val spec = GridSpec(p.x, p.y, c.size.width.toFloat(), c.size.height.toFloat(), cellW, cellH)
                holder.spec = spec
                if (lastGrid != spec.cols to spec.rows) { lastGrid = spec.cols to spec.rows; onIntent(DesktopIntent.UpdateGrid(spec.cols, spec.rows)) }
            }
            .contextClick(onTap = { selected = null; onIntent(DesktopIntent.CloseOverlays) }) { pos ->
                selected = null
                overlay.showMenu(pos, listOf(
                    MenuItem("Đổi hình nền") { onWallpaperDialog() },
                    MenuItem("Sắp xếp icon") { onIntent(DesktopIntent.ArrangeIcons) },
                    MenuItem("Tạo thư mục mới") { onIntent(DesktopIntent.NewFolder) },
                    MenuItem("Cài đặt DPI") { onDpiDialog() }
                ))
            }
    ) {
        val dragging = (dd.payload as? DragPayload.Shortcut)?.id
        state.shortcuts.forEach { sc ->
            key(sc.id) {
                ShortcutIcon(sc, selected == sc.id, dragging == sc.id,
                    IntOffset((sc.gridCol * cellW).toInt(), (sc.gridRow * cellH).toInt()),
                    onSelect = { selected = sc.id }, onIntent = onIntent)
            }
        }
    }
}

@Composable
private fun ShortcutIcon(
    sc: DesktopShortcut, selected: Boolean, hidden: Boolean, offset: IntOffset,
    onSelect: () -> Unit, onIntent: (DesktopIntent) -> Unit
) {
    val dd = LocalDragDrop.current
    val overlay = LocalOverlay.current
    val isDir = remember(sc.filePath) { sc.filePath?.let { File(it).isDirectory } ?: false }
    Column(
        Modifier.offset { offset }.size(Dims.CellW, Dims.CellH).alpha(if (hidden) 0f else 1f)
            .padding(3.dp).clip(RoundedCornerShape(8.dp))
            .background(if (selected) Color(0x44FFFFFF) else Color.Transparent)
            .dragSource(dd, DragPayload.Shortcut(sc.id, sc.packageName, sc.title, sc.type == ShortcutType.FILE,
                if (sc.type == ShortcutType.TOOL) sc.packageName else null))
            .pointerInput(sc.id) { detectTapGestures(onTap = { onSelect() }, onDoubleTap = { onIntent(DesktopIntent.OpenShortcut(sc.id)) }) }
            .secondaryClick { pos -> onSelect(); overlay.showMenu(pos, shortcutMenu(sc, onIntent)) },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        when (sc.type) {
            ShortcutType.APP -> AppIcon(sc.packageName, 54.dp)
            ShortcutType.TOOL -> Tool.fromKey(sc.packageName)?.let { ToolIcon(it, 54.dp) }
            ShortcutType.FILE -> Icon(if (isDir) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null,
                Modifier.size(54.dp), tint = if (isDir) Color(0xFFFFD166) else Color(0xFFE0E0E0))
        }
        Spacer(Modifier.height(6.dp))
        Text(sc.title, color = Color.White, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, lineHeight = 15.sp,
            style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 1f), 6f)))
    }
}

/** Bóng mờ đi theo ngón tay/con trỏ khi kéo. */
@Composable
fun DragShadow(dd: DragDropState) {
    val p = dd.payload ?: return
    val density = LocalDensity.current
    val w = with(density) { Dims.CellW.toPx() }
    val h = with(density) { Dims.CellH.toPx() }
    Column(
        Modifier.offset { IntOffset((dd.position.x - w / 2).toInt(), (dd.position.y - h / 2).toInt()) }
            .size(Dims.CellW, Dims.CellH).alpha(0.8f),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        when (p) {
            is DragPayload.App -> AppIcon(p.pkg, 48.dp)
            is DragPayload.Shortcut -> when {
                p.toolKey != null -> Tool.fromKey(p.toolKey)?.let { ToolIcon(it, 54.dp) }
                !p.isFile -> AppIcon(p.pkg, 54.dp)
                else -> Icon(Icons.Filled.InsertDriveFile, null, Modifier.size(54.dp), tint = Color.White)
            }
            is DragPayload.Tool -> Tool.fromKey(p.key)?.let { ToolIcon(it, 54.dp) }
            is DragPayload.File -> Icon(if (p.isDir) Icons.Filled.Folder else Icons.Filled.InsertDriveFile, null, Modifier.size(48.dp),
                tint = if (p.isDir) Color(0xFFFFD166) else Color.White)
        }
        Text(p.title, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
