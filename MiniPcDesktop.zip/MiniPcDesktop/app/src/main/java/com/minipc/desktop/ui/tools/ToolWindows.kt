package com.minipc.desktop.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.common.LocalOverlay
import com.minipc.desktop.ui.desktop.DpiDialog
import com.minipc.desktop.ui.desktop.WallpaperDialog
import com.minipc.desktop.ui.theme.Accent
import com.minipc.desktop.ui.theme.Brand
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun AboutWindow() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(84.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF6C8CFF), Color(0xFF4A6BE0)))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.DesktopWindows, null, tint = Color.White, modifier = Modifier.size(44.dp)) }
        Text(Brand.NAME, color = Color.White, fontSize = 36.sp)
        Text(Brand.TAGLINE, color = Color(0xFF9AA4C0), fontSize = 16.sp)
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x14FFFFFF)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Làm quen với desktop", color = Color.White, fontSize = 17.sp)
            Text("Kéo tiêu đề để di chuyển. Kéo cạnh hoặc góc để đổi kích thước. Nhấp đúp tiêu đề để phóng to. Chạm biểu tượng trên dock để thu nhỏ hoặc mở lại.",
                color = Color(0xFFB4BCD0), fontSize = 14.sp)
        }
        Text("Đang chạy trên điện thoại", color = Color(0xFF9AA4C0), fontSize = 15.sp)
        Text("Phiên bản 1.0", color = Color(0xFF6F7894), fontSize = 13.sp)
    }
}

@Composable
fun ShizukuWindow(vm: DesktopViewModel, state: DesktopState) {
    val ctx = LocalContext.current
    val ok = state.privilege != PrivilegeChecker.Mode.NONE
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline, null,
            tint = if (ok) Color(0xFF4ADE9A) else Color(0xFFFFB74D), modifier = Modifier.size(44.dp))
        Text(if (ok) "Sẵn sàng chạy trong cửa sổ" else "Chưa kết nối Shizuku", color = Color.White, fontSize = 28.sp)
        Text(if (ok) "Dịch vụ đặc quyền đã kết nối (${state.privilege})." else "Khởi động Shizuku rồi cấp quyền cho Mini PC.", color = Color.White, fontSize = 16.sp)
        OutlinedButton({
            if (!ok && vm.privilege.shizukuRunning()) vm.privilege.requestShizukuPermission()
            else ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
        }, Modifier.fillMaxWidth()) { Text(if (!ok && vm.privilege.shizukuRunning()) "Cấp quyền" else "Mở Shizuku", color = Accent) }
        Text("Ứng dụng Android chạy trong cửa sổ Freeform. Sau khi khởi động lại điện thoại, cần khởi động lại Shizuku. Ứng dụng có nội dung bảo vệ hoặc không hỗ trợ đa cửa sổ có thể không hiển thị.",
            color = Color(0xFFB4BCD0), fontSize = 14.sp)
    }
}

@Composable
fun SettingsWindow(vm: DesktopViewModel, state: DesktopState) {
    val overlay = LocalOverlay.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row2("Hình nền", "Ảnh, GIF hoặc video") { Button({ overlay.showDialog { d -> WallpaperDialog(vm, d) } }) { Text("Thay đổi") } }
        Row2("Mật độ điểm ảnh (DPI)", "Hiện tại: ${if (state.settings.customDpi > 0) state.settings.customDpi else "tự động"}") {
            Button({ overlay.showDialog { d -> DpiDialog(vm, d) } }) { Text("Chỉnh") }
        }
        Row2("Khóa Kiosk", "Ghim màn hình (sẽ chặn mở app khác)") {
            Switch(state.settings.kioskLocked, { vm.onIntent(DesktopIntent.SetKiosk(it)) })
        }
        Row2("Quyền đặc quyền", state.privilege.name) {}
        Row2("Tương thích Freeform", when (state.compatOk) { true -> "Hoạt động"; false -> "ROM có thể chặn"; null -> "Chưa kiểm tra" }) {}
    }
}

@Composable
private fun Row2(title: String, sub: String, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x14FFFFFF)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = Color(0xFF9AA4C0), fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun NotesWindow() {
    val ctx = LocalContext.current
    val file = remember { File(ctx.filesDir, "notes.txt") }
    var text by remember { mutableStateOf(runCatching { file.readText() }.getOrDefault("")) }
    LaunchedEffect(text) { delay(500); runCatching { file.writeText(text) } }
    BasicTextField(
        text, { text = it },
        textStyle = TextStyle(color = Color(0xFFE6E9F5), fontSize = 16.sp, lineHeight = 24.sp),
        cursorBrush = SolidColor(Accent),
        modifier = Modifier.fillMaxSize().padding(20.dp),
        decorationBox = { inner ->
            Box { if (text.isEmpty()) Text("Ghi chú mới…", color = Color(0xFF6F7894), fontSize = 16.sp); inner() }
        }
    )
}
