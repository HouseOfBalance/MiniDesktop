package com.minipc.desktop.ui.topdock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.InternalWindow
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.desktop.ConfirmDialog
import com.minipc.desktop.ui.theme.Accent
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class DockEntry(val pkg: String, val pinned: Boolean, val running: Boolean)

/** Taskbar dạng viên thuốc đặt ở TRÊN cùng: [Apps][Tìm] | app ghim/đang chạy/cửa sổ công cụ | [Cài đặt] giờ/ngày [Nguồn]. */
@Composable
fun TopDock(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val overlay = LocalOverlay.current
    val installed = state.apps.map { it.packageName }.toSet()
    val runningPkgs = state.windows.map { it.packageName }.filter { it in installed }.distinct()
    val pinned = state.pinned.filter { it.onDock && it.packageName in installed }.map { it.packageName }
    val entries = pinned.map { DockEntry(it, true, it in runningPkgs) } +
        runningPkgs.filter { it !in pinned }.map { DockEntry(it, false, true) }
    val activePkg = state.activeWindow?.packageName
    val focusedInternal = state.internalWindows.lastOrNull { !it.minimized }?.id
    val tFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dFmt = remember { SimpleDateFormat("dd/MM", Locale.getDefault()) }

    GlassSurface(modifier.height(Dims.DockHeight), RoundedCornerShape(28.dp), tint = Color(0xCC141A2B)) {
        Row(
            Modifier.fillMaxHeight().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            DockButton(Icons.Filled.Apps, state.startOpen) { onIntent(DesktopIntent.ToggleStart) }
            DockButton(Icons.Filled.Search, false) { onIntent(DesktopIntent.ToggleStart) }
            Sep()
            entries.forEach { AppItem(it, it.pkg == activePkg, onIntent) }
            state.internalWindows.forEach { ToolItem(it, it.id == focusedInternal, onIntent) }
            Sep()
            DockButton(Icons.Filled.Settings, state.controlCenterOpen) { onIntent(DesktopIntent.ToggleControlCenter) }
            Column(Modifier.padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(tFmt.format(Date(state.clockMs)), color = Color.White, fontSize = 17.sp)
                Text(dFmt.format(Date(state.clockMs)), color = Color(0xFF9AA4C0), fontSize = 12.sp)
            }
            DockButton(Icons.Filled.PowerSettingsNew, false, Color(0xFFFF8A80)) {
                overlay.showDialog { d ->
                    ConfirmDialog("Tắt Mini PC", "Đóng toàn bộ cửa sổ, khôi phục DPI và quay về Launcher gốc?",
                        { onIntent(DesktopIntent.Shutdown) }, d)
                }
            }
        }
    }
}

@Composable
private fun Sep() = Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(24.dp).background(Color(0x33FFFFFF)))

@Composable
private fun DockButton(icon: ImageVector, active: Boolean, tint: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Color(0x33FFFFFF) else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun Indicator(modifier: Modifier, active: Boolean) {
    if (active) Box(modifier.padding(bottom = 1.dp).width(18.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Accent))
    else DotIndicator(modifier.padding(bottom = 2.dp))
}

@Composable
private fun AppItem(e: DockEntry, active: Boolean, onIntent: (DesktopIntent) -> Unit) {
    val overlay = LocalOverlay.current
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Color(0x26FFFFFF) else Color.Transparent)
            .clickable { onIntent(DesktopIntent.LaunchApp(e.pkg)) }
            .secondaryClick { pos ->
                overlay.showMenu(pos, buildList {
                    add(MenuItem(if (e.running) "Chuyển tới cửa sổ" else "Mở") { onIntent(DesktopIntent.LaunchApp(e.pkg)) })
                    add(MenuItem(if (e.pinned) "Bỏ ghim khỏi Dock" else "Ghim lên Dock") {
                        onIntent(if (e.pinned) DesktopIntent.UnpinDock(e.pkg) else DesktopIntent.PinDock(e.pkg))
                    })
                    if (e.running) add(MenuItem("Đóng (Buộc dừng)") { onIntent(DesktopIntent.ForceStop(e.pkg)) })
                })
            },
        contentAlignment = Alignment.Center
    ) {
        AppIcon(e.pkg, 30.dp)
        if (e.running) Indicator(Modifier.align(Alignment.BottomCenter), active)
    }
}

@Composable
private fun ToolItem(w: InternalWindow, focused: Boolean, onIntent: (DesktopIntent) -> Unit) {
    val overlay = LocalOverlay.current
    val tool = Tool.fromKind(w.kind)
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (focused) Color(0x26FFFFFF) else Color.Transparent)
            .clickable { onIntent(DesktopIntent.ToggleInternal(w.id)) }
            .secondaryClick { pos -> overlay.showMenu(pos, listOf(MenuItem("Đóng") { onIntent(DesktopIntent.CloseInternal(w.id)) })) },
        contentAlignment = Alignment.Center
    ) {
        ToolIcon(tool, 30.dp, Modifier.alpha(if (w.minimized) 0.6f else 1f))
        Indicator(Modifier.align(Alignment.BottomCenter), focused)
    }
}
