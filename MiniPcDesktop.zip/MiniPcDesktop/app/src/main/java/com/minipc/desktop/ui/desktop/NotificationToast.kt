package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.AppIcon
import kotlinx.coroutines.delay

/** Thẻ thông báo nổi góc phải trên khi có thông báo mới (tự ẩn sau 6 giây), không hiệu ứng. */
@Composable
fun NotificationToast(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val latest = state.notifs.firstOrNull { !it.isSummary }
    val initial = remember { latest?.key to latest?.postTime }
    var visibleKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(latest?.key, latest?.postTime) {
        val k = latest?.key
        if (k != null && (latest.key to latest.postTime) != initial) {
            visibleKey = k; delay(6000); if (visibleKey == k) visibleKey = null
        }
    }
    val n = state.notifs.firstOrNull { it.key == visibleKey } ?: return
    Row(
        modifier.width(380.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF1A2035))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .clickable { visibleKey = null; onIntent(DesktopIntent.OpenNotif(n)) }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(n.packageName, 30.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(n.title.ifEmpty { n.appName }, color = Color.White, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (n.text.isNotEmpty()) Text(n.text, color = Color(0xFF9AA4C0), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Filled.Close, null, tint = Color(0xFF9AA4C0),
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).clickable { visibleKey = null }.padding(7.dp))
    }
}
