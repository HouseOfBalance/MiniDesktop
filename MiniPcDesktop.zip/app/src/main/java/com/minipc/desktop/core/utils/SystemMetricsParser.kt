package com.minipc.desktop.core.utils

import com.minipc.desktop.domain.model.ProcessMetric
import com.minipc.desktop.domain.model.SystemMetrics

object SystemMetricsParser {
    private val pssRe = Regex("^\\s*([\\d,.]+)K: (\\S+) \\(pid (\\d+)")

    /** CPU tổng + % CPU từng process từ `top -b -n 1`. */
    fun parseTop(text: String): Pair<Float, Map<String, Float>> {
        var total = 0f
        val perPkg = HashMap<String, Float>()
        var cpuIdx = -1; var nameIdx = -1; var colCount = 0
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.contains("%cpu") && line.contains("%idle")) {
                val t = Regex("(\\d+)%cpu").find(line)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
                val idle = Regex("(\\d+)%idle").find(line)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
                if (t > 0) total = ((t - idle) / t * 100f).coerceIn(0f, 100f)
                continue
            }
            if (line.startsWith("PID")) {
                val cols = line.replace("S[%CPU]", "S %CPU").split(Regex("\\s+"))
                cpuIdx = cols.indexOfFirst { it.contains("%CPU") }
                nameIdx = cols.size - 1
                colCount = cols.size
                continue
            }
            if (cpuIdx >= 0 && line[0].isDigit()) {
                val parts = line.split(Regex("\\s+"), limit = colCount)
                if (parts.size == colCount) {
                    val cpu = parts[cpuIdx].toFloatOrNull() ?: continue
                    val pkg = parts[nameIdx].substringBefore(':')
                    perPkg[pkg] = (perPkg[pkg] ?: 0f) + cpu
                }
            }
        }
        return total to perPkg
    }

    /** RAM theo process từ phần "Total PSS by process" của dumpsys meminfo. */
    fun parseMeminfoPss(text: String): List<Triple<String, Int, Long>> =
        text.lineSequence().mapNotNull { l ->
            pssRe.find(l)?.let {
                Triple(it.groupValues[2].substringBefore(':'), it.groupValues[3].toInt(),
                    it.groupValues[1].replace(",", "").replace(".", "").toLongOrNull() ?: 0L)
            }
        }.toList()

    fun parseProcMeminfo(text: String): Pair<Long, Long> {
        fun kb(key: String) = Regex("$key:\\s+(\\d+)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val total = kb("MemTotal")
        return (total - kb("MemAvailable")) to total.coerceAtLeast(1)
    }

    fun merge(cpuTotal: Float, cpu: Map<String, Float>, pss: List<Triple<String, Int, Long>>, used: Long, total: Long): SystemMetrics {
        val ram = HashMap<String, Pair<Int, Long>>()
        pss.forEach { (pkg, pid, kb) -> val o = ram[pkg]; ram[pkg] = (o?.first ?: pid) to ((o?.second ?: 0L) + kb) }
        val pkgs = ram.keys + cpu.keys
        val list = pkgs.filter { it.contains('.') }.map {
            ProcessMetric(it, ram[it]?.first ?: 0, cpu[it] ?: 0f, ram[it]?.second ?: 0L)
        }.sortedByDescending { it.ramKb }
        return SystemMetrics(cpuTotal, used, total, list)
    }
}
