package com.minipc.desktop.core.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PrivilegeChecker @Inject constructor() {
    enum class Mode { NONE, SHIZUKU, ROOT }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _mode = MutableStateFlow(Mode.NONE)
    val mode: StateFlow<Mode> = _mode.asStateFlow()
    private var started = false

    private val onReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { refresh() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    fun start() {
        if (started) return
        started = true
        Shizuku.addBinderReceivedListenerSticky(onReceived)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh()
    }

    fun stop() {
        Shizuku.removeBinderReceivedListener(onReceived)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        started = false
    }

    fun refresh() {
        scope.launch {
            _mode.value = when {
                shizukuReady() -> Mode.SHIZUKU
                rootAvailable() -> Mode.ROOT
                else -> Mode.NONE
            }
        }
    }

    fun shizukuRunning() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun shizukuReady() = runCatching {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun requestShizukuPermission() {
        runCatching {
            if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(1001)
        }
    }

    private fun rootAvailable() = runCatching {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        p.waitFor() == 0
    }.getOrDefault(false)
}
