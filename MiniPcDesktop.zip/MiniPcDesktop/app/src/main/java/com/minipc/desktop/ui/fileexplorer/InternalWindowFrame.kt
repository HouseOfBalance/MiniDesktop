package com.minipc.desktop.ui.fileexplorer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.core.window.WindowMath
import com.minipc.desktop.ui.common.LocalOverlay
import com.minipc.desktop.ui.common.MenuItem
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.theme.Navy
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon
import kotlin.math.roundToInt

/** Hình học cửa sổ – giữ ngoài composition để thu nhỏ/mở lại không mất vị trí. */
@Stable
class WindowGeom(x: Float, y: Float, w: Float, h: Float) {
    var x by mutableFloatStateOf(x)
    var y by mutableFloatStateOf(y)
    var w by mutableFloatStateOf(w)
    var h by mutableFloatStateOf(h)
    var maximized by mutableStateOf(false)
    var saved: FloatArray = floatArrayOf()
}

/** Cửa sổ nội bộ kiểu desktop: tiêu đề kéo được, snap, thu nhỏ, phóng to, đóng, kéo cạnh/góc đổi kích thước. */
@Composable
fun InternalWindowFrame(
    title: String, icon: @Composable () -> Unit, geom: WindowGeom, focused: Boolean, rotatable: Boolean,
    onClose: () -> Unit, onMinimize: () -> Unit, onFocus: () -> Unit,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    val cfg = LocalConfiguration.current
    val overlay = LocalOverlay.current
    val screenW = with(density) { cfg.screenWidthDp.dp.toPx() }
    val screenH = with(density) { cfg.screenHeightDp.dp.toPx() }
    val top = with(density) { Dims.Reserved.toPx() }
    val minW = with(density) { 320.dp.toPx() }
    val minH = with(density) { 220.dp.toPx() }
    val shape = RoundedCornerShape(16.dp)
    var snapPos by remember { mutableStateOf(Offset.Zero) }

    fun toggleMax() {
        if (!geom.maximized) {
            geom.saved = floatArrayOf(geom.x, geom.y, geom.w, geom.h)
            geom.x = 0f; geom.y = top; geom.w = screenW; geom.h = screenH - top
        } else if (geom.saved.size == 4) {
            geom.x = geom.saved[0]; geom.y = geom.saved[1]; geom.w = geom.saved[2]; geom.h = geom.saved[3]
        }
        geom.maximized = !geom.maximized
    }

    fun rotate() {
        val titleH = with(density) { 49.dp.toPx() }
        var nw = geom.h - titleH
        var nh = geom.w + titleH
        val k = minOf(1f, (screenH - top) / nh, screenW / nw)
        nw *= k; nh *= k
        geom.maximized = false
        geom.w = nw.coerceAtLeast(minW); geom.h = nh.coerceAtLeast(minH)
        geom.y = geom.y.coerceAtLeast(top)
        geom.x = geom.x.coerceIn(0f, (screenW - geom.w).coerceAtLeast(0f))
    }

    fun snap(r: SnapRegion) {
        if (!geom.maximized && geom.saved.isEmpty()) geom.saved = floatArrayOf(geom.x, geom.y, geom.w, geom.h)
        val b = WindowMath.region(r, screenW.toInt(), screenH.toInt(), top.toInt())
        geom.x = b.left.toFloat(); geom.y = b.top.toFloat(); geom.w = b.width.toFloat(); geom.h = b.height.toFloat()
        geom.maximized = r == SnapRegion.MAXIMIZE
    }

    Box(
        Modifier.offset { IntOffset(geom.x.roundToInt(), geom.y.roundToInt()) }
            .size(with(density) { geom.w.toDp() }, with(density) { geom.h.toDp() })
            .shadow(if (focused) 10.dp else 0.dp, shape).clip(shape).background(Navy)
            .border(1.dp, Color(0x33FFFFFF), shape)
            .pointerInput(Unit) {   // focus mà không nuốt sự kiện
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        if (e.type == PointerEventType.Press) onFocus()
                    }
                }
            }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(48.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { c, d ->
                            c.consume()
                            if (!geom.maximized) { geom.x += d.x; geom.y = (geom.y + d.y).coerceAtLeast(top) }
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures(onDoubleTap = { toggleMax() }) }
                    .padding(start = 12.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                icon()
                Spacer(Modifier.width(10.dp))
                Text(title, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                if (rotatable) TitleBtn(Icons.Filled.ScreenRotation) { rotate() }
                TitleBtn(Icons.Filled.VerticalSplit, Modifier.onGloballyPositioned { snapPos = it.positionInRoot() }) {
                    overlay.showMenu(snapPos.copy(y = snapPos.y + 100f), listOf(
                        MenuItem("Nửa trái") { snap(SnapRegion.LEFT) },
                        MenuItem("Nửa phải") { snap(SnapRegion.RIGHT) },
                        MenuItem("Góc trên trái") { snap(SnapRegion.TOP_LEFT) },
                        MenuItem("Góc trên phải") { snap(SnapRegion.TOP_RIGHT) },
                        MenuItem("Góc dưới trái") { snap(SnapRegion.BOTTOM_LEFT) },
                        MenuItem("Góc dưới phải") { snap(SnapRegion.BOTTOM_RIGHT) },
                        MenuItem("Phóng to") { snap(SnapRegion.MAXIMIZE) }
                    ))
                }
                TitleBtn(Icons.Filled.Remove, onClick = onMinimize)
                TitleBtn(Icons.Filled.CropSquare) { toggleMax() }
                TitleBtn(Icons.Filled.Close, onClick = onClose)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x1FFFFFFF)))
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        }
        // Cạnh phải / cạnh dưới
        Box(Modifier.align(Alignment.CenterEnd).padding(top = 48.dp, bottom = 20.dp).fillMaxHeight().width(8.dp).pointerInput(Unit) {
            detectDragGestures { c, d -> c.consume(); if (!geom.maximized) geom.w = (geom.w + d.x).coerceAtLeast(minW) }
        })
        Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 20.dp).fillMaxWidth().height(8.dp).pointerInput(Unit) {
            detectDragGestures { c, d -> c.consume(); if (!geom.maximized) geom.h = (geom.h + d.y).coerceAtLeast(minH) }
        })
        // 2 góc dưới
        Box(Modifier.align(Alignment.BottomEnd).size(20.dp).pointerInput(Unit) {
            detectDragGestures { c, d ->
                c.consume()
                if (!geom.maximized) { geom.w = (geom.w + d.x).coerceAtLeast(minW); geom.h = (geom.h + d.y).coerceAtLeast(minH) }
            }
        })
        Box(Modifier.align(Alignment.BottomStart).size(20.dp).pointerInput(Unit) {
            detectDragGestures { c, d ->
                c.consume()
                if (!geom.maximized) {
                    val nw = (geom.w - d.x).coerceAtLeast(minW); geom.x += (geom.w - nw); geom.w = nw
                    geom.h = (geom.h + d.y).coerceAtLeast(minH)
                }
            }
        })
    }
}

@Composable
private fun TitleBtn(icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Icon(icon, null, tint = Color(0xFFD0D6E8),
        modifier = modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(11.dp))
}
