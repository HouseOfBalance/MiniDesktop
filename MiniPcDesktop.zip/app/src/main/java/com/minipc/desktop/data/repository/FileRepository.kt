package com.minipc.desktop.data.repository

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.minipc.desktop.domain.model.FileItem
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class QuickLocation(val label: String, val path: String)

@Singleton
class FileRepository @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val root: File get() = Environment.getExternalStorageDirectory()

    fun desktopDir(): File = File(root, "Desktop").apply { mkdirs() }

    fun quickAccess(): List<QuickLocation> {
        val list = mutableListOf(
            QuickLocation("Desktop", desktopDir().path),
            QuickLocation("Downloads", File(root, Environment.DIRECTORY_DOWNLOADS).path),
            QuickLocation("Documents", File(root, Environment.DIRECTORY_DOCUMENTS).path),
            QuickLocation("Pictures", File(root, Environment.DIRECTORY_PICTURES).path),
            QuickLocation("Bộ nhớ trong", root.path)
        )
        File("/storage").listFiles().orEmpty()
            .filter { it.isDirectory && it.name != "emulated" && it.name != "self" && it.canRead() }
            .forEach { list += QuickLocation("USB OTG (${it.name})", it.path) }
        return list
    }

    suspend fun list(path: String): List<FileItem> = withContext(Dispatchers.IO) {
        File(path).listFiles().orEmpty().map { FileItem(it.name, it.path, it.isDirectory, it.length(), it.lastModified()) }
            .sortedWith(compareByDescending<FileItem> { it.isDir }.thenBy { it.name.lowercase() })
    }

    /** Tìm tệp/thư mục theo tên (bỏ dấu, không phân biệt hoa thường) trong thư mục và các thư mục con. */
    suspend fun search(root: String, query: String, max: Int = 300): List<FileItem> = withContext(Dispatchers.IO) {
        val q = com.minipc.desktop.core.utils.StringUtils.normalize(query.trim())
        val out = ArrayList<FileItem>()
        if (q.isEmpty()) return@withContext out
        File(root).walkTopDown().onEnter { !it.name.startsWith(".") }.forEach { f ->
            if (f.path != root && com.minipc.desktop.core.utils.StringUtils.normalize(f.name).contains(q)) {
                out += FileItem(f.name, f.path, f.isDirectory, f.length(), f.lastModified())
                if (out.size >= max) return@withContext out
            }
        }
        out
    }

    fun createFolder(parent: String, name: String) = File(parent, name).mkdirs()
    fun rename(path: String, newName: String): Boolean { val f = File(path); return f.renameTo(File(f.parentFile, newName)) }
    fun delete(path: String) = File(path).deleteRecursively()

    private fun uniqueDest(dir: File, name: String): File {
        var d = File(dir, name); var i = 1
        val base = name.substringBeforeLast('.', name); val ext = name.substringAfterLast('.', "")
        while (d.exists()) { d = File(dir, if (ext.isEmpty()) "$base ($i)" else "$base ($i).$ext"); i++ }
        return d
    }

    fun copy(src: String, destDir: String): Boolean = runCatching {
        val s = File(src); s.copyRecursively(uniqueDest(File(destDir), s.name), false)
    }.getOrDefault(false)

    fun move(src: String, destDir: String): Boolean = runCatching {
        val s = File(src); val d = uniqueDest(File(destDir), s.name)
        s.renameTo(d) || (s.copyRecursively(d, false) && s.deleteRecursively())
    }.getOrDefault(false)

    fun mime(path: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(File(path).extension.lowercase()) ?: "*/*"

    fun isImage(path: String) = mime(path).startsWith("image/")
    fun isText(path: String) = mime(path).startsWith("text/") || File(path).extension.lowercase() in
        setOf("txt", "md", "json", "xml", "log", "csv", "kt", "java", "js", "html", "css", "ini", "yml", "yaml")

    fun readText(path: String, max: Int = 20_000): String =
        runCatching { File(path).bufferedReader().use { r -> CharArray(max).let { buf -> String(buf, 0, r.read(buf).coerceAtLeast(0)) } } }
            .getOrDefault("(Không đọc được tệp)")

    /** Mở tệp bằng ứng dụng tương ứng (mở ngoài desktop như Android thường). */
    fun open(path: String): Boolean = runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(path))
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime(path))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)
}
