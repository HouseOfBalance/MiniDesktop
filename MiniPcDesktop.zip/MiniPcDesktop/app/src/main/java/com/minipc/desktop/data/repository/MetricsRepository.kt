package com.minipc.desktop.data.repository

import com.minipc.desktop.core.shizuku.ShellExecutor
import com.minipc.desktop.core.utils.SystemMetricsParser
import com.minipc.desktop.domain.model.SystemMetrics
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

/** Lấy CPU/RAM mỗi 3 giây qua làn nền – chỉ chạy khi có collector (Task Manager đang mở). */
@Singleton
class MetricsRepository @Inject constructor(private val shell: ShellExecutor) {
    suspend fun sample(): SystemMetrics {
        val top = shell.exec("top -b -n 1", bg = true)
        val proc = shell.exec("cat /proc/meminfo", bg = true)
        val (cpuTotal, cpuMap, ramMap) = SystemMetricsParser.parseTop(top)
        val (used, total) = SystemMetricsParser.parseProcMeminfo(proc)
        return SystemMetricsParser.merge(cpuTotal, cpuMap, ramMap, used, total)
    }

    fun stream(): Flow<SystemMetrics> = flow {
        while (true) { emit(sample()); delay(3000) }
    }
}
