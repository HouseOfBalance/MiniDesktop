package com.minipc.desktop.data.repository

import android.app.ActivityOptions
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.graphics.Rect
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import com.minipc.desktop.domain.model.NotifItem
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRepository @Inject constructor(@ApplicationContext private val ctx: Context) {
    private val _items = MutableStateFlow<List<NotifItem>>(emptyList())
    val items: StateFlow<List<NotifItem>> = _items.asStateFlow()

    fun update(list: List<NotifItem>) { _items.value = list.sortedByDescending { it.postTime } }

    /** Mở PendingIntent dưới dạng cửa sổ Freeform (launchBounds + windowingMode 5 nếu ROM cho phép). */
    fun open(item: NotifItem, bounds: Rect) {
        val opts = ActivityOptions.makeBasic().apply {
            launchBounds = bounds
            runCatching {
                ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType).invoke(this, 5)
            }
        }
        runCatching { item.intent?.send(ctx, 0, null, null, null, null, opts.toBundle()) }
    }

    fun dismiss(key: String) {
        DesktopNotificationListener.instance?.cancelNotification(key)
        _items.value = _items.value.filterNot { it.key == key }
    }
}

/** 7.3 – Dịch vụ lắng nghe thông báo. */
@AndroidEntryPoint
class DesktopNotificationListener : NotificationListenerService() {
    @Inject lateinit var repo: NotificationRepository

    override fun onListenerConnected() { instance = this; sync() }
    override fun onListenerDisconnected() { instance = null }
    override fun onNotificationPosted(sbn: StatusBarNotification?) = sync()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = sync()

    private fun sync() {
        val list = runCatching { activeNotifications }.getOrNull().orEmpty()
            .filter { it.packageName != packageName }.mapNotNull(::toItem)
        repo.update(list)
    }

    private fun toItem(sbn: StatusBarNotification): NotifItem? = runCatching {
        val n = sbn.notification
        val e = n.extras
        val appName = packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        NotifItem(
            key = sbn.key, groupKey = sbn.groupKey, packageName = sbn.packageName, appName = appName,
            title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
            text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty(),
            icon = runCatching { n.smallIcon?.loadDrawable(this)?.toBitmap(48, 48) }.getOrNull(),
            intent = n.contentIntent, postTime = sbn.postTime,
            clearable = sbn.isClearable,
            isSummary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        )
    }.getOrNull()

    companion object { @Volatile var instance: DesktopNotificationListener? = null }
}
