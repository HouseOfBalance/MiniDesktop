package com.minipc.desktop.ui.desktop

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.minipc.desktop.data.repository.WallpaperItem
import com.minipc.desktop.domain.model.WallpaperType
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.theme.Accent
import kotlinx.coroutines.delay

@Composable
fun DialogCard(title: String, width: Int = 420, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.width(width.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF22262D))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, color = Color.White, fontSize = 17.sp)
        content()
    }
}

/** Hộp thoại nhập tên (tạo thư mục, đổi tên…). */
@Composable
fun InputDialog(title: String, initial: String, onOk: (String) -> Unit, dismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    DialogCard(title, 360) {
        BasicTextField(
            text, { text = it }, singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = SolidColor(Accent),
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF30353D)).padding(12.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(dismiss) { Text("Hủy") }
            TextButton({ if (text.isNotBlank()) { onOk(text.trim()); dismiss() } }) { Text("OK") }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, message: String, onOk: () -> Unit, dismiss: () -> Unit) {
    DialogCard(title, 360) {
        Text(message, color = Color(0xFFCCCCCC), fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(dismiss) { Text("Hủy") }
            TextButton({ onOk(); dismiss() }) { Text("Đồng ý") }
        }
    }
}

/** 4.1 – Chọn / thêm / xoá hình nền. */
@Composable
fun WallpaperDialog(vm: DesktopViewModel, dismiss: () -> Unit) {
    var items by remember { mutableStateOf<List<WallpaperItem>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    val current by vm.state.collectAsState()
    LaunchedEffect(tick) { items = vm.wallpaperRepo.list() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.onIntent(DesktopIntent.PickWallpaper(uri))
    }
    LaunchedEffect(current.settings.wallpaperPath) { delay(300); tick++ }

    DialogCard("Hình nền", 560) {
        LazyVerticalGrid(GridCells.Adaptive(120.dp), Modifier.heightIn(max = 300.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { it0 ->
                val sel = current.settings.wallpaperPath == it0.file.absolutePath
                Box(
                    Modifier.aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp))
                        .border(if (sel) 2.dp else 0.dp, Accent, RoundedCornerShape(8.dp))
                        .clickable { vm.onIntent(DesktopIntent.ApplyWallpaper(it0)) }
                ) {
                    AsyncImage(it0.thumb ?: it0.file, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    if (it0.type != WallpaperType.IMAGE)
                        Text(it0.type.name, color = Color.White, fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(3.dp))
                    Text("✕", color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.TopEnd).background(Color(0x99000000)).clickable {
                            vm.onIntent(DesktopIntent.DeleteWallpaper(it0)); }.padding(5.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ picker.launch(arrayOf("image/*", "video/*")) }) { Text("Chọn tệp mới") }
            OutlinedButton({ vm.onIntent(DesktopIntent.ClearWallpaper) }) { Text("Mặc định") }
            Spacer(Modifier.weight(1f))
            TextButton(dismiss) { Text("Đóng") }
        }
    }
}

/** 2.3 – Chỉnh DPI nhanh. */
@Composable
fun DpiDialog(vm: DesktopViewModel, dismiss: () -> Unit) {
    val st by vm.state.collectAsState()
    var v by remember { mutableFloatStateOf(if (st.settings.customDpi > 0) st.settings.customDpi.toFloat() else 240f) }
    DialogCard("Cài đặt DPI", 380) {
        Text("${v.toInt()} dpi", color = Accent, fontSize = 22.sp)
        Slider(v, { v = it }, valueRange = 160f..400f)
        Text("DPI gốc của máy: ${st.settings.originalDpi}", color = Color(0xFFAAAAAA), fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.onIntent(DesktopIntent.SetDpi(v.toInt())) }) { Text("Áp dụng") }
            OutlinedButton({ vm.onIntent(DesktopIntent.ResetDpi) }) { Text("Khôi phục") }
            Spacer(Modifier.weight(1f))
            TextButton(dismiss) { Text("Đóng") }
        }
    }
}
