package com.minipc.desktop.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.minipc.desktop.data.preferences.SettingsStore
import com.minipc.desktop.domain.model.WallpaperType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class WallpaperItem(val file: File, val type: WallpaperType, val thumb: File?)

/** 4.1 – Sao chép hình nền vào filesDir/wallpapers (cô lập) + tạo thumbnail. */
@Singleton
class WallpaperRepository @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val settings: SettingsStore
) {
    private val dir get() = File(ctx.filesDir, "wallpapers").apply { mkdirs() }

    suspend fun import(uri: Uri): WallpaperItem? = withContext(Dispatchers.IO) {
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        val type = when {
            mime.startsWith("video/") -> WallpaperType.VIDEO
            mime == "image/gif" -> WallpaperType.GIF
            mime.startsWith("image/") -> WallpaperType.IMAGE
            else -> return@withContext null
        }
        val ext = mime.substringAfter('/').ifEmpty { "bin" }
        val dest = File(dir, "wp_${System.currentTimeMillis()}.$ext")
        runCatching {
            ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
        }.onFailure { return@withContext null }
        WallpaperItem(dest, type, makeThumb(dest, type))
    }

    suspend fun list(): List<WallpaperItem> = withContext(Dispatchers.IO) {
        dir.listFiles().orEmpty().filter { !it.name.endsWith(".thumb.jpg") }
            .sortedByDescending { it.lastModified() }.map { f ->
                val ext = f.extension.lowercase()
                val type = when {
                    ext in setOf("mp4", "webm", "mkv", "3gpp", "quicktime") -> WallpaperType.VIDEO
                    ext == "gif" -> WallpaperType.GIF
                    else -> WallpaperType.IMAGE
                }
                val t = File(f.path + ".thumb.jpg")
                WallpaperItem(f, type, if (t.exists()) t else makeThumb(f, type))
            }
    }

    suspend fun apply(item: WallpaperItem) = settings.setWallpaper(item.file.absolutePath, item.type)
    suspend fun clear() = settings.setWallpaper(null, WallpaperType.NONE)

    suspend fun delete(item: WallpaperItem) = withContext(Dispatchers.IO) {
        item.file.delete(); item.thumb?.delete()
        if (settings.current().wallpaperPath == item.file.absolutePath) clear()
    }

    private fun makeThumb(f: File, type: WallpaperType): File? = runCatching {
        val bmp: Bitmap? = if (type == WallpaperType.VIDEO) {
            MediaMetadataRetriever().let { r ->
                try { r.setDataSource(f.path); r.getFrameAtTime(0) } finally { r.release() }
            }
        } else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            val o2 = BitmapFactory.Options().apply { inSampleSize = (o.outWidth / 400).coerceAtLeast(1) }
            BitmapFactory.decodeFile(f.path, o2)
        }
        val out = File(f.path + ".thumb.jpg")
        bmp?.let { b ->
            val s = Bitmap.createScaledBitmap(b, 320, (320f * b.height / b.width).toInt().coerceAtLeast(1), true)
            out.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        }
        out.takeIf { it.exists() }
    }.getOrNull()
}
