package com.minipc.desktop.ui.desktop

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.AppIcon
import com.minipc.desktop.ui.common.LocalOverlay
import com.minipc.desktop.ui.common.MenuItem
import com.minipc.desktop.ui.common.secondaryClick

/** Stage Manager: dải app gần đây ở mép trái; chạm để đưa lên sân khấu, chuột phải để gộp/đóng. */
@Composable
fun StageStrip(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    if (!state.stageEnabled || state.stashedApps.isEmpty()) return
    val overlay = LocalOverlay.current
    val labels = remember(state.apps) { state.apps.associate { it.packageName to it.label } }
    Column(modifier.width(92.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        state.stashedApps.take(6).forEach { pkg ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xE61A2035))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
                    .clickable { onIntent(DesktopIntent.StageSwap(pkg)) }
                    .secondaryClick { pos ->
                        overlay.showMenu(pos, listOf(
                            MenuItem("Đưa lên sân khấu") { onIntent(DesktopIntent.StageSwap(pkg)) },
                            MenuItem("Thêm vào stage hiện tại") { onIntent(DesktopIntent.StageSwap(pkg, true)) },
                            MenuItem("Đóng (Buộc dừng)") { onIntent(DesktopIntent.ForceStop(pkg)) }
                        ))
                    }.padding(vertical = 10.dp, horizontal = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppIcon(pkg, 40.dp)
                Spacer(Modifier.height(4.dp))
                Text(labels[pkg] ?: pkg, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
