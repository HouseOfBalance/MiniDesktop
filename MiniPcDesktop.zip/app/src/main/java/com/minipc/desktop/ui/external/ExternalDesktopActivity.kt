package com.minipc.desktop.ui.external

import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.minipc.desktop.core.kiosk.ImmersiveController
import com.minipc.desktop.domain.model.ScreenMetrics
import com.minipc.desktop.ui.Cursor
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopRoot
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.KeyRouter
import com.minipc.desktop.ui.theme.MiniPcTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Desktop đầy đủ chạy trên màn hình ngoài (HDMI / USB-C / không dây). Dùng chung ViewModel với màn hình điện thoại. */
@AndroidEntryPoint
class ExternalDesktopActivity : ComponentActivity() {
    @Inject lateinit var vm: DesktopViewModel
    private val keys by lazy { KeyRouter(vm) }
    private var myDisplayId = -1

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) { if (displayId == myDisplayId) finish() }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        myDisplayId = if (Build.VERSION.SDK_INT >= 30) display?.displayId ?: -1 else windowManager.defaultDisplay.displayId
        ImmersiveController.apply(this)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* chặn */ }
        })
        getSystemService(DisplayManager::class.java).registerDisplayListener(displayListener, Handler(Looper.getMainLooper()))

        vm.externalDisplayId = myDisplayId
        pushMetrics(center = true)
        vm.setExternalActive(true)
        lifecycleScope.launch { vm.closeExternal.collect { finish() } }

        setContent { MiniPcTheme { DesktopRoot(vm, external = true) } }
    }

    private fun pushMetrics(center: Boolean = false) {
        val dm = resources.displayMetrics
        vm.onIntent(DesktopIntent.UpdateScreen(ScreenMetrics(dm.widthPixels, dm.heightPixels, dm.density)))
        if (center) vm.cursor.value = Cursor(dm.widthPixels / 2f, dm.heightPixels / 2f)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        pushMetrics()
        ImmersiveController.apply(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ImmersiveController.apply(this)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (keys.dispatch(e)) return true
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        keys.release()
        getSystemService(DisplayManager::class.java).unregisterDisplayListener(displayListener)
        vm.externalDisplayId = -1
        vm.setExternalActive(false)
        super.onDestroy()
    }
}
