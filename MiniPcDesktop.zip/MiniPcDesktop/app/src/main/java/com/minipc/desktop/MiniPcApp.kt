package com.minipc.desktop

import android.app.Application
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.core.utils.FailSafe
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class MiniPcApp : Application() {
    @Inject lateinit var privilege: PrivilegeChecker
    @Inject lateinit var failSafe: FailSafe

    override fun onCreate() {
        super.onCreate()
        // Cho phép gọi API ẩn (ActivityOptions.setLaunchWindowingMode) để mở app thẳng vào cửa sổ Freeform
        if (android.os.Build.VERSION.SDK_INT >= 28) runCatching { org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L") }
        privilege.start()
        failSafe.installCrashHandler()   // 10.1 – crash bất ngờ vẫn trả DPI về bình thường
    }
}
