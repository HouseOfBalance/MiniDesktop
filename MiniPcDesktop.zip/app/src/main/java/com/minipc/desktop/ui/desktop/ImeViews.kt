package com.minipc.desktop.ui.desktop

import android.content.Context
import android.text.InputType
import android.view.KeyEvent
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

/** InputConnection chuyển chữ gõ trên bàn phím ảo vào app chạy trên màn hình ảo. */
class ForwardingConnection(
    view: View,
    private val onText: (CharSequence) -> Unit,
    private val onKey: (KeyEvent) -> Unit
) : BaseInputConnection(view, false) {
    private var composing: CharSequence = ""

    override fun setComposingText(text: CharSequence, newCursorPosition: Int): Boolean { composing = text; return true }
    override fun commitText(text: CharSequence, newCursorPosition: Int): Boolean { composing = ""; onText(text); return true }
    override fun finishComposingText(): Boolean {
        if (composing.isNotEmpty()) { onText(composing); composing = "" }
        return true
    }
    override fun sendKeyEvent(event: KeyEvent): Boolean { onKey(event); return true }
    override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
        repeat(beforeLength.coerceAtMost(50)) {
            onKey(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL)); onKey(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
        }
        return true
    }
    override fun performEditorAction(actionCode: Int): Boolean {
        onKey(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); onKey(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        return true
    }
}

private fun View.setupIme() { isFocusable = true; isFocusableInTouchMode = true }

class ImeTextureView(c: Context) : TextureView(c) {
    var onText: (CharSequence) -> Unit = {}
    var onKey: (KeyEvent) -> Unit = {}
    init { setupIme() }
    override fun onCheckIsTextEditor() = true
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return ForwardingConnection(this, onText, onKey)
    }
}

class ImeSurfaceView(c: Context) : SurfaceView(c) {
    var onText: (CharSequence) -> Unit = {}
    var onKey: (KeyEvent) -> Unit = {}
    init { setupIme() }
    override fun onCheckIsTextEditor() = true
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        return ForwardingConnection(this, onText, onKey)
    }
}
