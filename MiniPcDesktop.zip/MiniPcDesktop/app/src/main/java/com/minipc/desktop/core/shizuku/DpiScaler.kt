package com.minipc.desktop.core.shizuku

import android.os.Process
import com.minipc.desktop.data.preferences.SettingsStore
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * DPI chỉ được đổi TRONG phiên dùng app và luôn trả về giá trị của người dùng khi rời app:
 *  - nhớ DPI gốc (kể cả khi bạn đang dùng DPI tuỳ chỉnh riêng, không chỉ mặc định nhà sản xuất);
 *  - rời app / tắt / crash / bị vuốt khỏi recents → tự khôi phục (có watchdog chạy ngoài process).
 */
@Singleton
class DpiScaler @Inject constructor(
    private val shell: ShellExecutor,
    private val settings: SettingsStore
) {
    @Volatile var originalDpi = 0
    @Volatile var physicalDpi = 0
    /** true = DPI Desktop đang được áp dụng và cần được trả lại. */
    @Volatile var active = false
    private var watchdogStarted = false
    private val marker = "/data/local/tmp/minipc_dpi_pid"

    val restoreCommand: String
        get() = if (originalDpi > 0 && originalDpi != physicalDpi) "wm density $originalDpi" else "wm density reset"
    val clearMarkerCommand: String get() = "rm -f $marker"

    suspend fun readPhysical(): Int {
        val out = shell.exec("wm density")
        return Regex("Physical density:\\s*(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    suspend fun readCurrent(): Int {
        val out = shell.exec("wm density")
        return (Regex("Override density:\\s*(\\d+)").find(out) ?: Regex("Physical density:\\s*(\\d+)").find(out))
            ?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    /** Gọi 1 lần khi bắt đầu phiên, TRƯỚC khi đổi DPI: ghi nhớ DPI hiện tại của bạn. */
    suspend fun beginSession() {
        val st = settings.current()
        physicalDpi = readPhysical()
        val cur = readCurrent()
        // Nếu DPI hiện tại khác giá trị app từng áp dụng → đó là DPI của bạn. Nếu bằng → app đã thoát bất thường lần trước, giữ giá trị cũ.
        originalDpi = when {
            cur > 0 && cur != st.lastAppliedDpi -> cur
            st.originalDpi > 0 -> st.originalDpi
            else -> cur
        }
        settings.setOriginalDpi(originalDpi)
    }

    /** Tính DPI tối ưu cho Desktop: 200..280 tùy cạnh dài màn hình. */
    fun optimal(widthPx: Int, heightPx: Int): Int =
        (max(widthPx, heightPx) / 1280f * 160f).roundToInt().coerceIn(200, 280)

    suspend fun apply(dpi: Int) {
        val pid = Process.myPid()
        shell.exec("wm density $dpi; echo $pid > $marker")
        settings.setLastApplied(dpi)
        active = true
        startWatchdog(pid)
    }

    /** Trả DPI về giá trị của bạn. */
    suspend fun restore() {
        if (!active) return
        shell.exec("$restoreCommand; $clearMarkerCommand")
        settings.setLastApplied(0)
        active = false
    }

    /**
     * Tiến trình nền độc lập với app: nếu app bị giết (vuốt recents, hệ thống kill…) khi DPI Desktop còn bật,
     * nó tự khôi phục. Dùng file marker chứa PID để không đè lên phiên mới nếu app mở lại nhanh.
     */
    private suspend fun startWatchdog(pid: Int) {
        if (watchdogStarted) return
        watchdogStarted = true
        val script = "while [ -e /proc/$pid/cmdline ]; do sleep 1; done; " +
            "if [ \"\$(cat $marker 2>/dev/null)\" = \"$pid\" ]; then $restoreCommand; rm -f $marker; fi"
        shell.exec("if [ -e /proc/$pid/cmdline ]; then nohup sh -c '$script' >/dev/null 2>&1 & fi")
    }
}
