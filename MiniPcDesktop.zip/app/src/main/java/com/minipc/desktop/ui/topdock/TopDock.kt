package com.minipc.desktop.ui.topdock

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.theme.Dims

private class DockEntry(val pkg: String, val pinned: Boolean, val running: Boolean)

/** 6.1 – Top Compact Dock (kính mờ, cao 40dp, bo 20dp). */
@Composable
fun TopDock(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    val self = state.apps.map { it.packageName }.toSet()
    val runningPkgs = state.windows.map { it.packageName }.filter { it in self }.distinct()
    val pinned = state.pinned.filter { it.onDock && it.packageName in self }.map { it.packageName }
    val pinnedEntries = pinned.map { DockEntry(it, true, it in runningPkgs) }
    val extra = runningPkgs.filter { it !in pinned }.map { DockEntry(it, false, true) }

    GlassSurface(modifier.height(Dims.DockHeight), RoundedCornerShape(20.dp)) {
        Row(
            Modifier.fillMaxHeight().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StartButton { onIntent(DesktopIntent.ToggleStart) }
            pinnedEntries.forEach { DockItem(it, onIntent) }
            if (extra.isNotEmpty()) {
                Box(Modifier.width(1.dp).height(22.dp).background(Color(0x55FFFFFF)))   // vạch ngăn mảnh
                extra.forEach { DockItem(it, onIntent) }
            }
        }
    }
}

@Composable
private fun StartButton(onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(16.dp)) {
            val g = 1.5f
            val s = (size.width - g) / 2
            val c = Color(0xFF4CC2FF)
            listOf(Offset(0f, 0f), Offset(s + g, 0f), Offset(0f, s + g), Offset(s + g, s + g)).forEach {
                drawRoundRect(c, it, Size(s, s), CornerRadius(1.5f))
            }
        }
    }
}

@Composable
private fun DockItem(e: DockEntry, onIntent: (DesktopIntent) -> Unit) {
    val overlay = LocalOverlay.current
    Box(
        Modifier.size(32.dp).clip(RoundedCornerShape(8.dp))
            .clickable { onIntent(DesktopIntent.LaunchApp(e.pkg)) }
            .secondaryClick { pos ->
                overlay.showMenu(pos, buildList {
                    add(MenuItem(if (e.running) "Chuyển tới cửa sổ" else "Mở") { onIntent(DesktopIntent.LaunchApp(e.pkg)) })
                    add(MenuItem(if (e.pinned) "Bỏ ghim khỏi Dock" else "Ghim lên Dock") {
                        onIntent(if (e.pinned) DesktopIntent.UnpinDock(e.pkg) else DesktopIntent.PinDock(e.pkg))
                    })
                    if (e.running) add(MenuItem("Đóng (Buộc dừng)") { onIntent(DesktopIntent.ForceStop(e.pkg)) })
                })
            },
        contentAlignment = Alignment.Center
    ) {
        AppIcon(e.pkg, 26.dp)
        if (e.running) DotIndicator(Modifier.align(Alignment.BottomCenter).padding(bottom = 1.dp))
    }
}
