package com.minipc.desktop.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object Dims {
    val DockHeight = 52.dp
    val DockTop = 6.dp
    val Reserved = 64.dp      // vùng Top Dock chiếm
    val CellW = 96.dp
    val CellH = 104.dp
}

/** Bảng màu thống nhất: chỉ dùng màu đặc (không blur/trong suốt) để vẽ nhanh, đỡ overdraw. */
val Accent = Color(0xFF8C9EFF)
val Navy = Color(0xFF1A2035)        // nền cửa sổ / bảng
val NavyDeep = Color(0xFF111729)    // taskbar
val NavyHigh = Color(0xFF232B45)    // thẻ, ô nhập, nút
val NavyLine = Color(0x22FFFFFF)    // viền mảnh
val TextDim = Color(0xFF9AA4C0)

object Brand {
    const val NAME = "Mini PC"      // đổi tên hiển thị ở đây
    const val TAGLINE = "Không gian nhỏ. Khả năng lớn."
}

@Composable
fun MiniPcTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Color(0xFF0E1220),
        primaryContainer = Color(0xFF2A3560), onPrimaryContainer = Color.White,
        secondary = Color(0xFF6C8CFF), onSecondary = Color.White,
        surface = Navy, onSurface = Color.White,
        surfaceVariant = NavyHigh, onSurfaceVariant = Color(0xFFB4BCD0),
        background = Color.Black, onBackground = Color.White,
        outline = Color(0xFF3A4260), error = Color(0xFFFF6B6B)
    ),
    content = content
)
