package com.minipc.desktop.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.minipc.desktop.domain.model.AppSettings
import com.minipc.desktop.domain.model.WallpaperType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore("mini_pc_settings")

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val ctx: Context) {
    private object K {
        val WP_PATH = stringPreferencesKey("wp_path")
        val WP_TYPE = stringPreferencesKey("wp_type")
        val DPI = intPreferencesKey("custom_dpi")
        val ORIG_DPI = intPreferencesKey("original_dpi")
        val KIOSK = booleanPreferencesKey("kiosk_locked")
        val ONBOARD = booleanPreferencesKey("onboarding_done")
    }

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            wallpaperPath = p[K.WP_PATH],
            wallpaperType = runCatching { WallpaperType.valueOf(p[K.WP_TYPE] ?: "NONE") }.getOrDefault(WallpaperType.NONE),
            customDpi = p[K.DPI] ?: 0,
            originalDpi = p[K.ORIG_DPI] ?: 0,
            kioskLocked = p[K.KIOSK] ?: false,
            onboardingDone = p[K.ONBOARD] ?: false
        )
    }

    suspend fun current() = flow.first()
    suspend fun setWallpaper(path: String?, type: WallpaperType) = ctx.dataStore.edit {
        if (path == null) it.remove(K.WP_PATH) else it[K.WP_PATH] = path
        it[K.WP_TYPE] = type.name
    }
    suspend fun setCustomDpi(v: Int) = ctx.dataStore.edit { it[K.DPI] = v }
    suspend fun setOriginalDpi(v: Int) = ctx.dataStore.edit { it[K.ORIG_DPI] = v }
    suspend fun setKiosk(v: Boolean) = ctx.dataStore.edit { it[K.KIOSK] = v }
    suspend fun setOnboardingDone(v: Boolean) = ctx.dataStore.edit { it[K.ONBOARD] = v }
}
