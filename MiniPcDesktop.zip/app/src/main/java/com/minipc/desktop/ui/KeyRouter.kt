package com.minipc.desktop.ui

import android.os.Handler
import android.os.Looper
import android.view.KeyEvent

/**
 * Phím tắt chung cho cả màn hình điện thoại và màn hình ngoài:
 * Alt+Tab (bảng chuyển cửa sổ), Ctrl+Alt+←/→ (đổi desktop ảo), Win+D, Win (Start), Ctrl+Shift+Esc, Alt+F4,
 * tổ hợp cứu hộ Vol+ & Vol- giữ 3 giây. Phím còn lại được chuyển vào app trên cùng.
 */
class KeyRouter(private val vm: DesktopViewModel) {
    private val handler = Handler(Looper.getMainLooper())
    private var volUp = false
    private var volDown = false
    private var metaAlone = false
    private val panic = Runnable { vm.onIntent(DesktopIntent.Panic) }

    fun dispatch(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> volUp = down
            KeyEvent.KEYCODE_VOLUME_DOWN -> volDown = down
        }
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            handler.removeCallbacks(panic)
            if (volUp && volDown) handler.postDelayed(panic, 3000)
        }

        val s = vm.state.value
        if (!s.booted) return false

        // Thả Alt → xác nhận cửa sổ đang chọn trong bảng Alt+Tab
        if (e.action == KeyEvent.ACTION_UP && (e.keyCode == KeyEvent.KEYCODE_ALT_LEFT || e.keyCode == KeyEvent.KEYCODE_ALT_RIGHT) && s.switcherIndex >= 0) {
            vm.onIntent(DesktopIntent.SwitcherCommit); return true
        }

        if (down && e.repeatCount == 0) {
            when {
                e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_TAB -> { vm.onIntent(DesktopIntent.SwitcherStep(!e.isShiftPressed)); return true }
                e.isCtrlPressed && e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT -> {
                    vm.onIntent(DesktopIntent.SwitchDesktop(s.currentDesktop - 1)); return true
                }
                e.isCtrlPressed && e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    vm.onIntent(DesktopIntent.SwitchDesktop(s.currentDesktop + 1)); return true
                }
                e.isMetaPressed && e.keyCode == KeyEvent.KEYCODE_D -> { vm.onIntent(DesktopIntent.ShowDesktop); return true }
                e.isCtrlPressed && e.isShiftPressed && e.keyCode == KeyEvent.KEYCODE_ESCAPE -> {
                    vm.onIntent(DesktopIntent.OpenInternal(InternalKind.TASKS)); return true
                }
                e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_F4 -> { vm.onIntent(DesktopIntent.CloseActiveWindow); return true }
            }
            metaAlone = e.keyCode == KeyEvent.KEYCODE_META_LEFT || e.keyCode == KeyEvent.KEYCODE_META_RIGHT
        } else if (down) {
            metaAlone = false
        }
        // Phím Win nhả ra mà không kèm phím khác → mở/đóng Start Menu
        if (e.action == KeyEvent.ACTION_UP && metaAlone &&
            (e.keyCode == KeyEvent.KEYCODE_META_LEFT || e.keyCode == KeyEvent.KEYCODE_META_RIGHT)) {
            metaAlone = false
            vm.onIntent(DesktopIntent.ToggleStart)
            return true
        }
        return vm.forwardKey(e)
    }

    fun release() { handler.removeCallbacks(panic) }
}
