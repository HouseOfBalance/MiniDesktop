package com.minipc.desktop.ui

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.media.AudioManager
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.minipc.desktop.core.kiosk.LauncherUtils
import com.minipc.desktop.core.shizuku.*
import com.minipc.desktop.core.utils.FailSafe
import com.minipc.desktop.core.utils.Permissions
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.core.window.WindowMath
import com.minipc.desktop.core.window.WindowTracker
import com.minipc.desktop.data.db.*
import com.minipc.desktop.data.preferences.SettingsStore
import com.minipc.desktop.data.repository.*
import com.minipc.desktop.domain.model.*
import com.minipc.desktop.domain.usecase.*
import com.minipc.desktop.ui.tools.Tool
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class DesktopViewModel @Inject constructor(
    @ApplicationContext private val ctx: Context,
    val privilege: PrivilegeChecker,
    private val shell: ShellExecutor,
    private val settings: SettingsStore,
    private val dpi: DpiScaler,
    private val freeform: FreeformEnabler,
    private val probe: CompatibilityProbe,
    private val appRepo: AppRepository,
    val iconCache: IconCache,
    private val shortcutDao: ShortcutDao,
    private val pinnedDao: PinnedAppDao,
    private val boundsDao: AppBoundsDao,
    private val tracker: WindowTracker,
    private val launchApp: LaunchAppUseCase,
    private val windowActions: WindowActionsUseCase,
    private val notifRepo: NotificationRepository,
    val wallpaperRepo: WallpaperRepository,
    val fileRepo: FileRepository,
    val metricsRepo: MetricsRepository,
    status: SystemStatusRepository,
    private val failSafe: FailSafe
) : ViewModel() {

    private val _state = MutableStateFlow(DesktopState())
    val state: StateFlow<DesktopState> = _state.asStateFlow()
    private val _effects = Channel<DesktopEffect>(Channel.BUFFERED)
    val effects = _effects.receiveAsFlow()

    private val gridMap = SpatialGridMap()
    private val savedBounds = HashMap<String, Bounds>()
    private var nextWinId = 1
    @Volatile private var foreground = true
    private val stashed = HashMap<Int, Bounds>()          // taskId -> bounds gốc (Stage Manager)
    private var stageGroup: Set<String> = emptySet()
    private val clampTries = HashMap<Int, Int>()

    private inline fun mutate(f: DesktopState.() -> DesktopState) = _state.update { it.f() }
    private fun toast(m: String) { _effects.trySend(DesktopEffect.Toast(m)) }

    init {
        privilege.mode.onEach { m -> mutate { copy(privilege = m) } }.launchIn(viewModelScope)
        settings.flow.onEach { s -> mutate { copy(settings = s) } }.launchIn(viewModelScope)
        appRepo.apps.onEach { a -> mutate { copy(apps = a) } }.launchIn(viewModelScope)
        pinnedDao.observeAll().onEach { p -> mutate { copy(pinned = p) } }.launchIn(viewModelScope)
        shortcutDao.observeAll().map { l -> l.map { it.toDomain() } }.onEach { l ->
            gridMap.rebuild(l); mutate { copy(shortcuts = l) }
        }.launchIn(viewModelScope)
        notifRepo.items.onEach { n -> mutate { copy(notifs = n) } }.launchIn(viewModelScope)
        status.screenOn.onEach { v -> mutate { copy(screenOn = v) } }.launchIn(viewModelScope)
        status.battery.onEach { v -> mutate { copy(battery = v) } }.launchIn(viewModelScope)
        status.wifi.onEach { v -> mutate { copy(wifi = v) } }.launchIn(viewModelScope)
        status.clock.onEach { v -> mutate { copy(clockMs = v) } }.launchIn(viewModelScope)
        tracker.windows.onEach { ws ->
            val s = _state.value.screen
            mutate {
                copy(windows = ws, maximizedAppActive = ws.any {
                    it.visible && it.bounds?.coversScreen(s.widthPx, s.heightPx) == true
                })
            }
            persistBounds(ws)
            guardBounds(ws)
            enforceStage(ws)
        }.launchIn(viewModelScope)

        appRepo.start()
        // Vòng quét cửa sổ mỗi 2.5s khi desktop đã chạy
        viewModelScope.launch {
            while (isActive) {
                val s = _state.value
                if (s.booted && shell.ready && s.screenOn && foreground) tracker.refresh()
                delay(if (s.windows.isEmpty()) 5000 else 2000)   // thưa hơn khi không có cửa sổ nào
            }
        }
        autoStart()
    }

    private fun autoStart() = viewModelScope.launch {
        if (!settings.current().onboardingDone) return@launch
        withTimeoutOrNull(3000) { privilege.mode.first { it != PrivilegeChecker.Mode.NONE } }
        if (corePermissionsReady()) boot()
    }

    fun corePermissionsReady() = privilege.mode.value != PrivilegeChecker.Mode.NONE &&
        Permissions.notificationListenerEnabled(ctx) && Permissions.allFilesAccess(ctx)

    private fun ShortcutEntity.toDomain() = DesktopShortcut(
        id, runCatching { ShortcutType.valueOf(type) }.getOrDefault(ShortcutType.APP),
        packageName, title, filePath, gridCol, gridRow, Bounds.parse(lastBounds)
    )

    private suspend fun persistBounds(ws: List<WindowInfo>) {
        ws.filter { it.mode == "freeform" && it.bounds != null && it.packageName != ctx.packageName && it.taskId !in stashed }.forEach { w ->
            val b = w.bounds!!
            if (savedBounds[w.packageName] != b) {
                savedBounds[w.packageName] = b
                boundsDao.upsert(AppBoundsEntity(w.packageName, b.serialize()))
                shortcutDao.updateBounds(w.packageName, b.serialize())
            }
        }
    }

    // ---------------- Intent handler ----------------
    fun onIntent(i: DesktopIntent) {
        val s = _state.value
        when (i) {
            DesktopIntent.Boot -> boot()
            DesktopIntent.ToggleStart -> mutate { copy(startOpen = !startOpen, controlCenterOpen = false, searchFocus = false) }
            DesktopIntent.OpenSearch -> mutate { copy(startOpen = true, controlCenterOpen = false, searchFocus = true) }
            DesktopIntent.ToggleStage -> viewModelScope.launch {
                val on = !_state.value.stageEnabled
                mutate { copy(settings = settings.copy(stageManager = on)) }
                settings.setStage(on)
                if (on) enforceStage(tracker.refresh()) else unstashAll()
            }
            is DesktopIntent.StageSwap -> stageSwap(i.pkg, i.addToGroup)
            DesktopIntent.ToggleControlCenter -> mutate { copy(controlCenterOpen = !controlCenterOpen, startOpen = false) }
            DesktopIntent.CloseOverlays -> mutate { copy(startOpen = false, controlCenterOpen = false, searchFocus = false) }
            is DesktopIntent.UpdateScreen -> mutate { copy(screen = i.m) }
            is DesktopIntent.UpdateGrid -> mutate { copy(gridCols = i.cols, gridRows = i.rows) }
            is DesktopIntent.HardKeyboard -> {
                mutate { copy(hasHardKeyboard = i.present) }
                if (dpi.active) applyIme(i.present)
            }

            is DesktopIntent.LaunchApp -> { mutate { copy(startOpen = false) }; launch(i.pkg, i.fullscreen) }
            is DesktopIntent.PinDock -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg)
                pinnedDao.upsert(PinnedAppEntity(i.pkg, true, o?.inStartMenu ?: false, o?.sortOrder ?: (pinnedDao.maxOrder() + 1)))
            }
            is DesktopIntent.UnpinDock -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg) ?: return@launch
                if (o.inStartMenu) pinnedDao.upsert(o.copy(onDock = false)) else pinnedDao.delete(i.pkg)
            }
            is DesktopIntent.PinStart -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg)
                pinnedDao.upsert(PinnedAppEntity(i.pkg, o?.onDock ?: false, true, o?.sortOrder ?: (pinnedDao.maxOrder() + 1)))
            }
            is DesktopIntent.UnpinStart -> viewModelScope.launch {
                val o = pinnedDao.get(i.pkg) ?: return@launch
                if (o.onDock) pinnedDao.upsert(o.copy(inStartMenu = false)) else pinnedDao.delete(i.pkg)
            }
            is DesktopIntent.ForceStop -> viewModelScope.launch {
                windowActions.forceStop(i.pkg); delay(400); tracker.refresh()
            }
            is DesktopIntent.AppInfoScreen -> ctx.startActivity(Permissions.appInfoIntent(i.pkg))

            is DesktopIntent.DropApp -> viewModelScope.launch {
                val app = s.apps.firstOrNull { it.packageName == i.pkg } ?: return@launch
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = i.pkg, title = app.label, type = "APP", gridCol = c, gridRow = r))
                } ?: toast("Desktop đã đầy")
            }
            is DesktopIntent.DropFile -> viewModelScope.launch {
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = "", title = i.name, type = "FILE", gridCol = c, gridRow = r, filePath = i.path))
                } ?: toast("Desktop đã đầy")
            }
            is DesktopIntent.MoveShortcut -> viewModelScope.launch {
                place(i.col, i.row, ignoreId = i.id)?.let { (c, r) -> shortcutDao.move(i.id, c, r) }
            }
            is DesktopIntent.RemoveShortcut -> viewModelScope.launch { shortcutDao.delete(i.id) }
            is DesktopIntent.OpenShortcut -> s.shortcuts.firstOrNull { it.id == i.id }?.let { sc ->
                when (sc.type) {
                    ShortcutType.APP -> launch(sc.packageName, i.fullscreen)
                    ShortcutType.TOOL -> Tool.fromKey(sc.packageName)?.let { onIntent(DesktopIntent.OpenInternal(it.kind)) }
                    ShortcutType.FILE -> sc.filePath?.let { p ->
                        if (java.io.File(p).isDirectory) onIntent(DesktopIntent.OpenInternal(InternalKind.FILES, p))
                        else onIntent(DesktopIntent.OpenFile(p))
                    }
                }
            }
            is DesktopIntent.DropTool -> viewModelScope.launch {
                val t = Tool.fromKey(i.key) ?: return@launch
                place(i.col, i.row)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = t.key, title = t.label, type = "TOOL", gridCol = c, gridRow = r))
                } ?: toast("Desktop đã đầy")
            }
            DesktopIntent.RefreshApps -> appRepo.scan()
            is DesktopIntent.PinShortcutToDock -> s.shortcuts.firstOrNull { it.id == i.id }
                ?.takeIf { it.type == ShortcutType.APP }?.let { onIntent(DesktopIntent.PinDock(it.packageName)) }
            DesktopIntent.ArrangeIcons -> viewModelScope.launch {
                val rows = s.gridRows.coerceAtLeast(1)
                s.shortcuts.sortedBy { it.title.lowercase() }.forEachIndexed { idx, sc ->
                    shortcutDao.move(sc.id, idx / rows, idx % rows)
                }
            }
            DesktopIntent.NewFolder -> viewModelScope.launch(Dispatchers.IO) {
                val dir = fileRepo.desktopDir()
                var n = 0
                var name = "Thư mục mới"
                while (java.io.File(dir, name).exists()) { n++; name = "Thư mục mới ($n)" }
                fileRepo.createFolder(dir.path, name)
                place(0, 0)?.let { (c, r) ->
                    shortcutDao.insert(ShortcutEntity(packageName = "", title = name, type = "FILE", gridCol = c, gridRow = r,
                        filePath = java.io.File(dir, name).path))
                }
            }

            is DesktopIntent.OpenInternal -> mutate {
                val existing = if (i.kind != InternalKind.FILES) internalWindows.firstOrNull { it.kind == i.kind } else null
                if (existing != null) copy(internalWindows = internalWindows - existing + existing.copy(minimized = false), startOpen = false)
                else copy(internalWindows = internalWindows + InternalWindow(nextWinId++, i.kind, i.path), startOpen = false)
            }
            is DesktopIntent.CloseInternal -> mutate { copy(internalWindows = internalWindows.filterNot { it.id == i.id }) }
            is DesktopIntent.FocusInternal -> mutate {
                val w = internalWindows.firstOrNull { it.id == i.id }
                if (w == null || internalWindows.last() == w) this else copy(internalWindows = internalWindows - w + w)
            }
            is DesktopIntent.MinimizeInternal -> mutate {
                copy(internalWindows = internalWindows.map { if (it.id == i.id) it.copy(minimized = true) else it })
            }
            is DesktopIntent.ToggleInternal -> mutate {
                val w = internalWindows.firstOrNull { it.id == i.id } ?: return@mutate this
                val top = internalWindows.lastOrNull { !it.minimized }
                when {
                    w.minimized -> copy(internalWindows = internalWindows - w + w.copy(minimized = false))
                    top == w -> copy(internalWindows = internalWindows.map { if (it.id == w.id) it.copy(minimized = true) else it })
                    else -> copy(internalWindows = internalWindows - w + w)
                }
            }
            is DesktopIntent.Snap -> s.activeWindow?.let { w ->
                viewModelScope.launch { windowActions.snap(w, i.region, s.screen); delay(300); tracker.refresh() }
            }
            DesktopIntent.ShowDesktop -> {
                mutate { copy(startOpen = false, controlCenterOpen = false, internalWindows = internalWindows.map { it.copy(minimized = true) }) }
                shell.fire("am start -n ${ctx.packageName}/${com.minipc.desktop.ui.MainActivity::class.java.name}")
            }
            DesktopIntent.CloseActiveWindow -> s.activeWindow?.let { onIntent(DesktopIntent.ForceStop(it.packageName)) }
            DesktopIntent.CycleWindow -> s.windows.takeIf { it.size > 1 }?.last()?.let { focus(it) }
            is DesktopIntent.OpenFile -> viewModelScope.launch(Dispatchers.IO) {
                val b = WindowMath.defaultBounds(s.screen.widthPx, s.screen.heightPx, s.screen.topInsetPx)
                if (!fileRepo.open(i.path, Rect(b.left, b.top, b.right, b.bottom))) toast("Không có ứng dụng mở tệp này")
            }

            is DesktopIntent.PickWallpaper -> viewModelScope.launch {
                wallpaperRepo.import(i.uri)?.let { wallpaperRepo.apply(it) } ?: toast("Tệp không hợp lệ")
            }
            is DesktopIntent.ApplyWallpaper -> viewModelScope.launch { wallpaperRepo.apply(i.item) }
            is DesktopIntent.DeleteWallpaper -> viewModelScope.launch { wallpaperRepo.delete(i.item) }
            DesktopIntent.ClearWallpaper -> viewModelScope.launch { wallpaperRepo.clear() }
            is DesktopIntent.SetDpi -> viewModelScope.launch {
                val v = i.dpi.coerceIn(120, 480); dpi.apply(v); settings.setCustomDpi(v)
            }
            // "Tự động": quay về DPI tối ưu của Desktop (DPI gốc của bạn vẫn được trả khi rời app)
            DesktopIntent.ResetDpi -> viewModelScope.launch {
                settings.setCustomDpi(0)
                dpi.apply(dpi.optimal(s.screen.widthPx, s.screen.heightPx))
            }
            is DesktopIntent.SetKiosk -> viewModelScope.launch {
                settings.setKiosk(i.on); _effects.send(DesktopEffect.EnterKiosk(i.on))
            }

            is DesktopIntent.ToggleWifi -> shellOrSettings("svc wifi ${if (i.on) "enable" else "disable"}", Settings.ACTION_WIFI_SETTINGS)
            is DesktopIntent.ToggleBluetooth -> shellOrSettings("svc bluetooth ${if (i.on) "enable" else "disable"}", Settings.ACTION_BLUETOOTH_SETTINGS)
            is DesktopIntent.AutoBrightnessLock -> shell.fire("settings put system screen_brightness_mode ${if (i.on) 0 else 1}")
            is DesktopIntent.SetBrightness -> shell.fire("settings put system screen_brightness ${i.v.coerceIn(1, 255)}")
            is DesktopIntent.SetVolume -> ctx.getSystemService(AudioManager::class.java)
                .setStreamVolume(AudioManager.STREAM_MUSIC, i.v, 0)
            is DesktopIntent.OpenNotif -> {
                val b = WindowMath.defaultBounds(s.screen.widthPx, s.screen.heightPx, s.screen.topInsetPx)
                notifRepo.open(i.item, Rect(b.left, b.top, b.right, b.bottom))
                mutate { copy(controlCenterOpen = false) }
            }
            is DesktopIntent.DismissNotif -> notifRepo.dismiss(i.key)

            DesktopIntent.RestartUi -> viewModelScope.launch {
                freeform.enable(); mutate { copy(startOpen = false, controlCenterOpen = false, internalWindows = emptyList()) }
                _effects.send(DesktopEffect.Recreate)
            }
            DesktopIntent.Shutdown -> shutdown()
            DesktopIntent.Panic -> viewModelScope.launch {
                failSafe.panicRestore(); settings.setKiosk(false)
                mutate { copy(booted = false) }
                _effects.send(DesktopEffect.ExitToLauncher)
            }
        }
    }

    // ---------------- Helpers ----------------
    private fun place(col: Int, row: Int, ignoreId: Long = -1): Pair<Int, Int>? {
        val s = _state.value
        return SpiralSearch.findFree(col, row, s.gridCols, s.gridRows) { c, r -> gridMap.isOccupied(c, r, ignoreId) }
    }

    private fun focus(w: WindowInfo) {
        val comp = w.component ?: _state.value.apps.firstOrNull { it.packageName == w.packageName }?.component ?: return
        shell.fire("am start -n $comp")
    }

    private fun launch(pkg: String, fullscreen: Boolean) {
        val s = _state.value
        val app = s.apps.firstOrNull { it.packageName == pkg } ?: return
        if (s.stageEnabled && !fullscreen && s.windows.any { it.packageName == pkg }) { onIntent(DesktopIntent.StageSwap(pkg)); return }
        viewModelScope.launch {
            if (shell.ready) {
                if (!launchApp(app.component, pkg, s.screen, fullscreen)) toast("ROM chưa chuyển app sang cửa sổ Freeform được")
            } else {
                ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            delay(500); tracker.refresh()
        }
    }

    // ---------------- Giữ cửa sổ dưới taskbar ----------------
    private fun guardBounds(ws: List<WindowInfo>) {
        val sc = _state.value.screen
        ws.filter { it.mode == "freeform" && it.taskId !in stashed && it.packageName != ctx.packageName }.forEach { w ->
            val b = w.bounds ?: return@forEach
            val tries = clampTries[w.taskId] ?: 0
            if (b.top < sc.topInsetPx - 4 && tries < 3) {
                clampTries[w.taskId] = tries + 1
                val c = WindowMath.clampBelowDock(b, sc.topInsetPx)
                shell.fire("am task resize ${w.taskId} ${c.left} ${c.top} ${c.right} ${minOf(c.bottom, sc.heightPx)}")
            }
        }
    }

    // ---------------- Stage Manager ----------------
    private fun stageBoundsFor(): Bounds {
        val sc = _state.value.screen
        return WindowMath.stageBounds(sc.widthPx, sc.heightPx, sc.topInsetPx, (104 * sc.density).toInt(), (10 * sc.density).toInt())
    }

    private fun stash(w: WindowInfo) {
        val sc = _state.value.screen
        val b = w.bounds ?: stageBoundsFor()
        stashed[w.taskId] = b
        val o = WindowMath.stashBounds(sc.widthPx, b)
        shell.fire("am task resize ${w.taskId} ${o.left} ${o.top} ${o.right} ${o.bottom}")
    }

    private fun unstash(w: WindowInfo) {
        stashed.remove(w.taskId)
        val b = stageBoundsFor()
        shell.fire("am task resize ${w.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
    }

    /** Luôn giữ đúng 1 "sân khấu" (app đang dùng); các app khác được cất sang dải bên trái. */
    private fun enforceStage(ws: List<WindowInfo>) {
        val s = _state.value
        if (!s.stageEnabled || !s.booted || !foreground) return
        stashed.keys.retainAll(ws.map { it.taskId }.toSet())
        val top = ws.firstOrNull { it.taskId !in stashed }
        if (top != null && top.packageName !in stageGroup) {
            stageGroup = setOf(top.packageName)
            val b = stageBoundsFor()
            shell.fire("am task resize ${top.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
        }
        ws.filter { it.taskId !in stashed && it.packageName !in stageGroup }.forEach { stash(it) }
        val apps = ws.filter { it.taskId in stashed }.map { it.packageName }.distinct()
        if (apps != s.stashedApps || stageGroup != s.stageGroup) mutate { copy(stashedApps = apps, stageGroup = stageGroup) }
    }

    private fun stageSwap(pkg: String, add: Boolean) {
        viewModelScope.launch {
            val ws = tracker.windows.value
            val target = ws.filter { it.packageName == pkg }
            if (target.isEmpty()) return@launch
            if (!add) ws.filter { it.taskId !in stashed && it.packageName in stageGroup && it.packageName != pkg }.forEach { stash(it) }
            stageGroup = if (add) stageGroup + pkg else setOf(pkg)
            target.filter { it.taskId in stashed }.forEach { unstash(it) }
            (target.first().component ?: _state.value.apps.firstOrNull { it.packageName == pkg }?.component)
                ?.let { shell.exec("am start -n $it") }
            if (add) arrangeGroup(ws)
            delay(300); tracker.refresh()
        }
    }

    /** Nhiều app trong cùng stage: chia đều chiều ngang sân khấu. */
    private fun arrangeGroup(ws: List<WindowInfo>) {
        val g = ws.filter { it.packageName in stageGroup }
        if (g.isEmpty()) return
        val b = stageBoundsFor()
        g.forEachIndexed { i, w ->
            val l = b.left + b.width * i / g.size; val r = b.left + b.width * (i + 1) / g.size
            shell.fire("am task resize ${w.taskId} $l ${b.top} $r ${b.bottom}")
        }
    }

    private fun unstashAll() {
        tracker.windows.value.filter { it.taskId in stashed }.forEach { w ->
            val b = stashed[w.taskId] ?: stageBoundsFor()
            shell.fire("am task resize ${w.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
        }
        stashed.clear(); stageGroup = emptySet()
        mutate { copy(stashedApps = emptyList(), stageGroup = emptySet()) }
    }

    private fun shellOrSettings(cmd: String, action: String) {
        if (shell.ready) shell.fire(cmd) else ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Trình tự khởi động Desktop: DPI gốc → cờ Freeform → DPI Desktop → kiểm tra tương thích. */
    private fun boot() {
        if (_state.value.booting || _state.value.booted) return
        viewModelScope.launch {
            mutate { copy(booting = true) }
            val st = settings.current()
            if (shell.ready) {
                dpi.beginSession()            // ghi nhớ DPI hiện tại của bạn trước khi đổi
                freeform.enable()
                dpi.apply(targetDpi(st.customDpi))
                applyIme(_state.value.hasHardKeyboard)
                mutate { copy(compatOk = null) }
                val ok = probe.run()
                mutate { copy(compatOk = ok) }
                if (!ok) toast("ROM có thể chặn chế độ Freeform")
            }
            if (!st.seeded && shortcutDao.getAll().isEmpty()) {
                listOf(Tool.NOTES to (0 to 0), Tool.SETTINGS to (1 to 0), Tool.SHIZUKU to (0 to 1), Tool.ABOUT to (1 to 1)).forEach { (t, pos) ->
                    shortcutDao.insert(ShortcutEntity(packageName = t.key, title = t.label, type = "TOOL", gridCol = pos.first, gridRow = pos.second))
                }
            }
            settings.setSeeded(true)
            settings.setOnboardingDone(true)
            mutate { copy(booted = true, booting = false) }
            _effects.send(DesktopEffect.EnterKiosk(st.kioskLocked))
        }
    }

    /** Shutdown: đóng cửa sổ → khôi phục DPI → (Activity) stopLockTask → Launcher gốc. */
    private fun shutdown() {
        viewModelScope.launch {
            _state.value.windows.forEach { shell.exec("am force-stop ${it.packageName}") }
            mutate { copy(internalWindows = emptyList(), startOpen = false, controlCenterOpen = false) }
            dpi.restore()
            shell.exec("settings put secure show_ime_with_hard_keyboard 1")
            mutate { copy(booted = false) }
            _effects.send(DesktopEffect.ExitToLauncher)
        }
    }

    private fun targetDpi(custom: Int): Int =
        if (custom > 0) custom else _state.value.screen.let { dpi.optimal(it.widthPx, it.heightPx) }

    private fun applyIme(hardKeyboard: Boolean) =
        shell.fire("settings put secure show_ime_with_hard_keyboard ${if (hardKeyboard) 0 else 1}")

    private var leaveJob: Job? = null

    /** Rời app (Activity.onStop): ngừng quét ngay; sau 1.5s trả DPI + cài đặt bàn phím, gỡ Stage Manager. */
    fun onLeave() {
        foreground = false
        leaveJob?.cancel()
        leaveJob = viewModelScope.launch {
            delay(1500)
            unstashAll()
            if (dpi.active) {
                dpi.restore()
                shell.exec("settings put secure show_ime_with_hard_keyboard 1")
            }
        }
    }

    /** Quay lại app (Activity.onStart): áp lại DPI Desktop. */
    fun onReturn() {
        foreground = true
        leaveJob?.cancel()
        if (!_state.value.booted || dpi.active || !shell.ready) return
        viewModelScope.launch {
            dpi.apply(targetDpi(settings.current().customDpi))
            applyIme(_state.value.hasHardKeyboard)
        }
    }

    /** Gọi từ Activity.onDestroy(isFinishing). */
    fun emergencyRestore() = failSafe.restoreBlocking()
}
