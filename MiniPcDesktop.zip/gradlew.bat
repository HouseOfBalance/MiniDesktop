@echo off
setlocal
set VER=8.7
set BASE=%USERPROFILE%\.gradle\minipc-gradle
set DIST=%BASE%\gradle-%VER%
if not exist "%DIST%\bin\gradle.bat" (
  mkdir "%BASE%" 2>nul
  echo Dang tai Gradle %VER% ...
  powershell -NoProfile -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%VER%-bin.zip -OutFile '%BASE%\g.zip'; Expand-Archive -Force '%BASE%\g.zip' '%BASE%'; Remove-Item '%BASE%\g.zip'"
)
call "%DIST%\bin\gradle.bat" %*
