package com.minipc.desktop.di

import android.content.Context
import androidx.room.Room
import com.minipc.desktop.data.db.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun db(@ApplicationContext c: Context): AppDatabase =
        Room.databaseBuilder(c, AppDatabase::class.java, "minipc.db").build()

    @Provides fun shortcutDao(d: AppDatabase) = d.shortcutDao()
    @Provides fun pinnedDao(d: AppDatabase) = d.pinnedAppDao()
    @Provides fun boundsDao(d: AppDatabase) = d.appBoundsDao()
}
