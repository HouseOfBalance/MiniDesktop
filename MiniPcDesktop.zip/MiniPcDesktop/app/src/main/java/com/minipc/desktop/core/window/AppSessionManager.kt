package com.minipc.desktop.core.window

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import com.minipc.desktop.core.shizuku.ShellExecutor
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Mỗi cửa sổ app = 1 VirtualDisplay riêng. App chạy trên màn hình ảo đó, hình ảnh được vẽ vào TextureView
 * nằm trong khung cửa sổ của Mini PC – hoàn toàn độc lập với đa cửa sổ của Android.
 */
@Singleton
class AppSessionManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val shell: ShellExecutor
) {
    class Session(val id: Int, val pkg: String, val component: String) {
        var vd: VirtualDisplay? = null
        var displayId = -1
        var surface: Surface? = null
        var w = 0
        var h = 0
        var secondaryHeld = false
        var ownsSurface = true
    }

    private val sessions = HashMap<Int, Session>()
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _failures = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val failures = _failures.asSharedFlow()

    private val dpi get() = ctx.resources.displayMetrics.densityDpi

    fun supported() = shell.ready && InputInjector.available()
    fun open(id: Int, pkg: String, component: String) { sessions.getOrPut(id) { Session(id, pkg, component) } }
    fun displayIdOf(id: Int) = sessions[id]?.displayId ?: -1

    private fun fit(w: Int, h: Int): Pair<Int, Int> {
        val m = maxOf(w, h)
        val k = if (m > 1920) 1920f / m else 1f
        return (w * k).toInt().coerceAtLeast(64) to (h * k).toInt().coerceAtLeast(64)
    }

    /** TextureView đã có Surface → tạo (hoặc gắn lại) màn hình ảo. */
    fun attach(id: Int, st: SurfaceTexture, vw: Int, vh: Int) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        s.w = w; s.h = h
        st.setDefaultBufferSize(w, h)
        if (s.ownsSurface) s.surface?.release()
        val surf = Surface(st)
        s.ownsSurface = true
        s.surface = surf
        val vd = s.vd
        if (vd == null) createDisplay(s, surf) else runCatching { vd.surface = surf; vd.resize(w, h, dpi) }
    }

    /** Dùng cho SurfaceView (cửa sổ trên cùng): Surface do hệ thống quản lý, ít tốn GPU hơn TextureView. */
    fun attachSurface(id: Int, surf: Surface, vw: Int, vh: Int) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        s.w = w; s.h = h
        if (s.ownsSurface) s.surface?.release()
        s.ownsSurface = false
        s.surface = surf
        val vd = s.vd
        if (vd == null) createDisplay(s, surf) else runCatching { vd.surface = surf; vd.resize(w, h, dpi) }
    }

    fun resize(id: Int, vw: Int, vh: Int, st: SurfaceTexture) {
        val s = sessions[id] ?: return
        val (w, h) = fit(vw, vh)
        if (w == s.w && h == s.h) return
        s.w = w; s.h = h
        st.setDefaultBufferSize(w, h)
        runCatching { s.vd?.resize(w, h, dpi) }
    }

    /** Cửa sổ bị thu nhỏ/gỡ khỏi màn hình: ngắt Surface, app vẫn chạy trên màn hình ảo. */
    fun detach(id: Int) {
        val s = sessions[id] ?: return
        runCatching { s.vd?.surface = null }
        if (s.ownsSurface) s.surface?.release()
        s.surface = null
    }

    private fun createDisplay(s: Session, surf: Surface) {
        if (!supported()) { _failures.tryEmit("Cần Shizuku đang chạy để mở app trong cửa sổ"); return }
        val pub = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        // Không bật SHOULD_SHOW_SYSTEM_DECORATIONS: cờ này khiến ROM coi đây là màn hình desktop và thêm thanh tiêu đề cửa sổ nổi
        val full = pub or (1 shl 6) /* SUPPORTS_TOUCH */
        val name = "MiniPC-${s.pkg}"
        val vd = runCatching { dm.createVirtualDisplay(name, s.w, s.h, dpi, surf, full) }.getOrNull()
            ?: runCatching { dm.createVirtualDisplay(name, s.w, s.h, dpi, surf, pub) }.getOrNull()
        if (vd == null) { _failures.tryEmit("ROM không cho tạo màn hình ảo"); return }
        s.vd = vd
        s.displayId = vd.display.displayId
        scope.launch {
            // windowingMode 1 = toàn màn hình trên màn hình ảo → app lấp đầy khung, không có thanh/bong bóng cửa sổ của hệ thống
            val out = shell.exec("am start --display ${s.displayId} --windowingMode 1 -n ${s.component}")
            if (out.contains("Error", true)) _failures.tryEmit("Không mở được ${s.pkg} trên màn hình ảo")
        }
    }

    fun close(id: Int) {
        val s = sessions.remove(id) ?: return
        runCatching { s.vd?.release() }
        if (s.ownsSurface) s.surface?.release()
        shell.fire("am force-stop ${s.pkg}")
    }

    fun closeAll() { sessions.keys.toList().forEach { close(it) } }

    // ---------- Chuyển tiếp input ----------
    fun touch(id: Int, v: View, e: MotionEvent) {
        val s = sessions[id] ?: return
        if (s.displayId < 0 || v.width == 0 || v.height == 0) return
        val mouse = e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
        if ((mouse && (e.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) || s.secondaryHeld) {
            // Chuột phải = nút Back
            if (e.actionMasked == MotionEvent.ACTION_DOWN) { s.secondaryHeld = true; InputInjector.key(s.displayId, KeyEvent.KEYCODE_BACK) }
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) s.secondaryHeld = false
            return
        }
        val c = MotionEvent.obtain(e)
        c.transform(Matrix().apply { setScale(s.w.toFloat() / v.width, s.h.toFloat() / v.height) })
        c.source = InputDevice.SOURCE_TOUCHSCREEN
        InputInjector.send(c, s.displayId)
    }

    fun generic(id: Int, v: View, e: MotionEvent): Boolean {
        val s = sessions[id] ?: return false
        if (s.displayId < 0 || e.actionMasked != MotionEvent.ACTION_SCROLL || v.width == 0) return false
        val c = MotionEvent.obtain(e)
        c.transform(Matrix().apply { setScale(s.w.toFloat() / v.width, s.h.toFloat() / v.height) })
        c.source = InputDevice.SOURCE_MOUSE
        InputInjector.send(c, s.displayId)
        return true
    }

    fun forwardKey(id: Int, e: KeyEvent): Boolean {
        val s = sessions[id] ?: return false
        if (s.displayId < 0) return false
        InputInjector.send(KeyEvent.changeAction(e, e.action), s.displayId)
        return true
    }
}
