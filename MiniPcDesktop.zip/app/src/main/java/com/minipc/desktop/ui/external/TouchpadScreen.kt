package com.minipc.desktop.ui.external

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.ui.DesktopViewModel
import kotlin.math.abs

/** Khi đang chiếu lên màn hình ngoài, màn hình điện thoại biến thành touchpad điều khiển con trỏ trên đó. */
@Composable
fun TouchpadScreen(vm: DesktopViewModel) {
    var held by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0F1A)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Đang chiếu lên màn hình ngoài", color = Color.White, fontSize = 22.sp)
        Text("1 ngón: di chuyển · chạm: click trái · chạm 2 ngón: click phải · 2 ngón vuốt: cuộn",
            color = Color(0xFF9AA4C0), fontSize = 13.sp)
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF1A2035))
                .pointerInput(Unit) { touchpad(vm) },
            contentAlignment = Alignment.Center
        ) { Text("TOUCHPAD", color = Color(0xFF3A4260), fontSize = 28.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ vm.click(MotionEvent.BUTTON_PRIMARY) }) { Text("Chuột trái") }
            Button({ vm.click(MotionEvent.BUTTON_SECONDARY) }) { Text("Chuột phải") }
            OutlinedButton({ held = !held; vm.toggleHold() }) { Text(if (held) "Thả giữ" else "Giữ & kéo") }
            Spacer(Modifier.weight(1f))
            OutlinedButton({ vm.stopExternal() }) { Text("Dừng chiếu") }
        }
    }
}

private suspend fun PointerInputScope.touchpad(vm: DesktopViewModel) {
    val slop = viewConfiguration.touchSlop
    awaitPointerEventScope {
        while (true) {
            val first = awaitFirstDown(requireUnconsumed = false)
            val t0 = first.uptimeMillis
            var lastTime = t0
            var maxPointers = 1
            var travelled = 0f
            var last = first.position
            var lastY = first.position.y
            do {
                val ev = awaitPointerEvent()
                lastTime = ev.changes.first().uptimeMillis
                val down = ev.changes.filter { it.pressed }
                if (down.size > maxPointers) maxPointers = down.size
                if (down.size >= 2) {
                    val cy = down.map { it.position.y }.average().toFloat()
                    travelled += abs(cy - lastY)
                    vm.scrollWheel((cy - lastY) / 25f)
                    lastY = cy
                    last = down[0].position
                } else if (down.size == 1) {
                    val p = down[0]
                    val d = p.position - last
                    travelled += d.getDistance()
                    if (maxPointers == 1) vm.moveCursor(d.x * 1.8f, d.y * 1.8f)
                    last = p.position
                    lastY = p.position.y
                }
                ev.changes.forEach { it.consume() }
            } while (ev.changes.any { it.pressed })
            // Chạm nhanh, gần như không di chuyển → click
            if (travelled < slop * 2 && lastTime - t0 < 300) {
                vm.click(if (maxPointers >= 2) MotionEvent.BUTTON_SECONDARY else MotionEvent.BUTTON_PRIMARY)
            }
        }
    }
}
