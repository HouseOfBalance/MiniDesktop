package com.minipc.desktop.core.shizuku

import com.minipc.desktop.data.preferences.SettingsStore
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.roundToInt

@Singleton
class DpiScaler @Inject constructor(
    private val shell: ShellExecutor,
    private val settings: SettingsStore
) {
    /** Đọc "Physical density: N" từ `wm density`. */
    suspend fun readPhysical(): Int {
        val out = shell.exec("wm density")
        return Regex("Physical density:\\s*(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    suspend fun readCurrent(): Int {
        val out = shell.exec("wm density")
        return (Regex("Override density:\\s*(\\d+)").find(out) ?: Regex("Physical density:\\s*(\\d+)").find(out))
            ?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    /** Lưu DPI gốc làm mốc khôi phục (chỉ lưu lần đầu). */
    suspend fun saveOriginalIfNeeded() {
        if (settings.current().originalDpi == 0) {
            val p = readPhysical()
            if (p > 0) settings.setOriginalDpi(p)
        }
    }

    /** Tính DPI tối ưu cho Desktop: 200..280 tùy cạnh dài màn hình. */
    fun optimal(widthPx: Int, heightPx: Int): Int =
        (max(widthPx, heightPx) / 1280f * 160f).roundToInt().coerceIn(200, 280)

    suspend fun apply(dpi: Int) { shell.exec("wm density $dpi") }

    suspend fun reset() { shell.exec("wm density reset") }
}
