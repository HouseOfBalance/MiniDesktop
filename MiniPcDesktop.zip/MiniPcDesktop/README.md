# Mini PC Desktop Environment (Android / Kotlin / Compose)

Biến điện thoại thành môi trường Desktop: Top Dock + Start Menu kiểu Windows 11, cửa sổ Freeform,
hình nền video/GIF, Control Center, thông báo, File Explorer, Task Manager.

## Chạy thử
1. Mở thư mục này bằng **Android Studio Koala+** (JDK 17), đợi Gradle sync.
2. Cài & chạy Shizuku (hoặc máy đã root) trên thiết bị Android 8.0+.
3. Run app → làm theo Onboarding 3 bước (Shizuku/Root → Đọc thông báo → Truy cập tệp) → **Khởi động Mini PC**.

## Cứu hộ nếu giao diện lỗi
- Chạm **5 lần** vào góc trên-trái trong 3 giây, hoặc giữ **Vol+ & Vol-** 3 giây → reset DPI, thoát Kiosk, về Launcher gốc.
- Hoặc dùng adb: `adb shell wm density reset`.

## Ánh xạ 10 giai đoạn → code
| GĐ | Nội dung | File chính |
|---|---|---|
| 1 | Gradle, package, Room, DataStore | `app/build.gradle.kts`, `data/db/Database.kt`, `data/preferences/SettingsStore.kt` |
| 2 | Shizuku/Root, cờ Freeform, DPI | `core/shizuku/*` |
| 3 | Kiosk, Home, Back, bàn phím/chuột | `core/kiosk/Kiosk.kt`, `ui/MainActivity.kt`, `ui/common/Common.kt` (secondaryClick) |
| 4 | Wallpaper Engine | `data/repository/WallpaperRepository.kt`, `ui/desktop/WallpaperLayer.kt` |
| 5 | Lưới shortcut, kéo thả, SpiralSearch | `core/window/WindowMath.kt`, `domain/usecase/Algorithms.kt`, `ui/desktop/DesktopGrid.kt` |
| 6 | Top Dock, Start Menu, Fuzzy | `ui/topdock`, `ui/startmenu`, `data/repository/AppRepository.kt` |
| 7 | System Tray, Control Center, thông báo | `ui/systemtray`, `data/repository/NotificationRepository.kt` |
| 8 | Freeform launcher, snap, Task Manager | `domain/usecase/WindowUseCases.kt`, `ui/desktop/WindowHelperOverlay.kt`, `ui/taskmanager` |
| 9 | File Explorer dạng cửa sổ | `ui/fileexplorer` |
| 10 | Panic, crash handler, Onboarding | `core/utils/FailSafe.kt`, `ui/onboarding`, `ui/DesktopScreen.kt` |

## Cách cửa sổ app hoạt động (độc lập với đa cửa sổ của Android)
- Mỗi app = 1 `VirtualDisplay` riêng (`core/window/AppSessionManager.kt`), mở bằng `am start --display <id>`.
- Hình ảnh vẽ vào `TextureView` trong khung cửa sổ Mini PC; cảm ứng/phím được chuyển vào đúng màn hình ảo qua `IInputManager.injectInputEvent` (Shizuku).
- App khoá dọc (TikTok…) tự mở dạng khung điện thoại 9:16; có nút xoay trên thanh tiêu đề. Chuột phải = Back.
- Taskbar chỉ hiện app ghim + cửa sổ đang mở bên trong Mini PC; app chạy ngoài không xuất hiện.
- **Cần Shizuku** (Root không đủ để chuyển input). App có DRM/FLAG_SECURE có thể hiện đen.
