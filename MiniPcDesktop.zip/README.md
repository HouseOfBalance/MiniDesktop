# Mini PC Desktop Environment (Android / Kotlin / Compose)

Biến điện thoại thành môi trường Desktop: Top Dock + Start Menu kiểu Windows 11, cửa sổ Freeform,
hình nền video/GIF, Control Center, thông báo, File Explorer, Task Manager.

## Chạy thử
1. Mở thư mục này bằng **Android Studio Koala+** (JDK 17), đợi Gradle sync.
2. Cài & chạy Shizuku (hoặc máy đã root) trên thiết bị Android 8.0+.
3. Run app → làm theo Onboarding 3 bước (Shizuku/Root → Đọc thông báo → Truy cập tệp) → **Khởi động Mini PC**.

## Cứu hộ nếu giao diện lỗi
- Chạm **5 lần** vào góc trên-trái trong 3 giây, hoặc giữ **Vol+ & Vol-** 3 giây → reset DPI, thoát Kiosk, về Launcher gốc.
- Hoặc dùng adb: `adb shell wm density reset`.

## Ánh xạ 10 giai đoạn → code
| GĐ | Nội dung | File chính |
|---|---|---|
| 1 | Gradle, package, Room, DataStore | `app/build.gradle.kts`, `data/db/Database.kt`, `data/preferences/SettingsStore.kt` |
| 2 | Shizuku/Root, cờ Freeform, DPI | `core/shizuku/*` |
| 3 | Kiosk, Home, Back, bàn phím/chuột | `core/kiosk/Kiosk.kt`, `ui/MainActivity.kt`, `ui/common/Common.kt` (secondaryClick) |
| 4 | Wallpaper Engine | `data/repository/WallpaperRepository.kt`, `ui/desktop/WallpaperLayer.kt` |
| 5 | Lưới shortcut, kéo thả, SpiralSearch | `core/window/WindowMath.kt`, `domain/usecase/Algorithms.kt`, `ui/desktop/DesktopGrid.kt` |
| 6 | Top Dock, Start Menu, Fuzzy | `ui/topdock`, `ui/startmenu`, `data/repository/AppRepository.kt` |
| 7 | System Tray, Control Center, thông báo | `ui/systemtray`, `data/repository/NotificationRepository.kt` |
| 8 | Freeform launcher, snap, Task Manager | `domain/usecase/WindowUseCases.kt`, `ui/desktop/WindowHelperOverlay.kt`, `ui/taskmanager` |
| 9 | File Explorer dạng cửa sổ | `ui/fileexplorer` |
| 10 | Panic, crash handler, Onboarding | `core/utils/FailSafe.kt`, `ui/onboarding`, `ui/DesktopScreen.kt` |

## Cách cửa sổ app hoạt động (độc lập với đa cửa sổ của Android)
- Mỗi app = 1 `VirtualDisplay` riêng (`core/window/AppSessionManager.kt`), mở bằng `am start --display <id>`.
- Hình ảnh vẽ vào `TextureView` trong khung cửa sổ Mini PC; cảm ứng/phím được chuyển vào đúng màn hình ảo qua `IInputManager.injectInputEvent` (Shizuku).
- App khoá dọc (TikTok…) tự mở dạng khung điện thoại 9:16; có nút xoay trên thanh tiêu đề. Chuột phải = Back.
- Taskbar chỉ hiện app ghim + cửa sổ đang mở bên trong Mini PC; app chạy ngoài không xuất hiện.
- **Cần Shizuku** (Root không đủ để chuyển input). App có DRM/FLAG_SECURE có thể hiện đen.

## Tính năng Mini PC
- **Màn hình ngoài:** cắm HDMI/USB-C → desktop tự chiếu sang đó, điện thoại thành touchpad (1 ngón di chuyển, chạm = click, 2 ngón chạm = chuột phải, 2 ngón vuốt = cuộn). Bật/tắt trong Cài đặt.
- **Desktop ảo (tối đa 6):** nút Layers trên taskbar, hoặc Ctrl+Alt+←/→. Chuột phải icon taskbar → chuyển cửa sổ sang desktop khác.
- **Alt+Tab:** giữ Alt bấm Tab (thêm Shift để đi ngược), thả Alt để chuyển. Rê chuột lên icon taskbar xem trước cửa sổ.
- **Snap:** kéo thanh tiêu đề sát mép trái/phải (nửa màn hình) hoặc mép trên (phóng to).
- **Nhiều cửa sổ cùng một app:** chuột phải icon app → "Cửa sổ mới".
- **Bàn phím ảo trong cửa sổ app:** nút bàn phím trên thanh tiêu đề (chỉ hiện khi bạn bấm); có bàn phím vật lý thì gõ thẳng.
- **File Explorer:** tìm kiếm (cả thư mục con), ảnh xem trước, kéo tệp giữa các cửa sổ hoặc thả lên thư mục trên desktop.
- **Shizuku chết giữa chừng:** hiện banner, tự thử nối lại mỗi 3 giây.
