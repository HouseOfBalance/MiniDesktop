package com.minipc.desktop.ui.onboarding

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.core.utils.Permissions
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.theme.Accent

private class Step(val title: String, val desc: String, val done: Boolean, val action: String, val onClick: () -> Unit)

/** 10.2 – Wizard cấp quyền lần đầu: 4 bước, nút Khởi động chỉ sáng khi đủ quyền. */
@Composable
fun OnboardingScreen(vm: DesktopViewModel, state: DesktopState) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) { tick++; vm.privilege.refresh() } }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val priv = state.privilege != PrivilegeChecker.Mode.NONE
    val steps = remember(tick, state.privilege) {
        listOf(
            Step("1. Kết nối Shizuku / Root",
                if (priv) "Đã kết nối (${state.privilege})" else if (vm.privilege.shizukuRunning()) "Shizuku đang chạy – cần cấp quyền cho app" else "Mở Shizuku và khởi động dịch vụ, hoặc cấp quyền Root",
                priv, if (vm.privilege.shizukuRunning()) "Cấp quyền" else "Mở Shizuku") {
                if (vm.privilege.shizukuRunning()) vm.privilege.requestShizukuPermission()
                else ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
                    ?: vm.privilege.refresh()
            },
            Step("2. Quyền đọc thông báo", "Cho phép Mini PC hiển thị thông báo trong Control Center",
                Permissions.notificationListenerEnabled(ctx), "Cấp quyền") { Permissions.openNotificationListenerSettings(ctx) },
            Step("3. Quyền truy cập tệp", "Cho phép File Explorer đọc/ghi bộ nhớ",
                Permissions.allFilesAccess(ctx), "Cấp quyền") { Permissions.openAllFilesSettings(ctx) }
        )
    }
    val ready = steps.all { it.done }

    Box(Modifier.fillMaxSize().background(Color(0xFF0E1116)), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 560.dp).verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Mini PC Desktop", color = Color.White, fontSize = 26.sp)
            Text("Hoàn tất 3 bước để bắt đầu", color = Color(0xFFAAAAAA), fontSize = 14.sp)
            steps.forEach { s ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1F26)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.Icon(if (s.done) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null,
                        tint = if (s.done) Color(0xFF66BB6A) else Color(0xFF777777))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = Color.White, fontSize = 15.sp)
                        Text(s.desc, color = Color(0xFF9AA4B2), fontSize = 12.sp)
                    }
                    if (!s.done) OutlinedButton(s.onClick) { Text(s.action, fontSize = 12.sp) }
                }
            }
            Button(
                { vm.onIntent(DesktopIntent.Boot) }, enabled = ready && !state.booting, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
            ) { Text(if (state.booting) "Đang khởi động…" else "Khởi động Mini PC", fontSize = 16.sp) }
        }
    }
}
