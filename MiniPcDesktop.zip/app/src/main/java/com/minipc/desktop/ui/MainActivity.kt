package com.minipc.desktop.ui

import android.content.Intent
import android.content.res.Configuration
import android.hardware.input.InputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.minipc.desktop.core.kiosk.ImmersiveController
import com.minipc.desktop.core.kiosk.LauncherUtils
import com.minipc.desktop.domain.model.ScreenMetrics
import com.minipc.desktop.ui.theme.MiniPcTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val vm: DesktopViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var volUp = false
    private var volDown = false
    private var metaAlone = false
    private val panic = Runnable { vm.onIntent(DesktopIntent.Panic) }

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(id: Int) = checkKeyboard()
        override fun onInputDeviceRemoved(id: Int) = checkKeyboard()
        override fun onInputDeviceChanged(id: Int) = checkKeyboard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ImmersiveController.apply(this)

        // 3.2 – Nuốt toàn bộ thao tác Back ở màn hình chính
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* chặn */ }
        })

        vm.originalHomeComponent = LauncherUtils.findOriginalHome(this)?.flattenToShortString()
        pushScreenMetrics()
        getSystemService(InputManager::class.java).registerInputDeviceListener(inputListener, handler)
        checkKeyboard()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.CREATED) {
                vm.effects.collect { e ->
                    when (e) {
                        is DesktopEffect.Toast -> Toast.makeText(this@MainActivity, e.msg, Toast.LENGTH_SHORT).show()
                        is DesktopEffect.EnterKiosk -> runCatching { if (e.lock) startLockTask() else stopLockTask() }
                        DesktopEffect.Recreate -> recreate()
                        DesktopEffect.ExitToLauncher -> {
                            // Luồng cuối của Shutdown: gỡ ghim → Launcher gốc
                            runCatching { stopLockTask() }
                            LauncherUtils.launchOriginalHome(this@MainActivity)
                            finishAndRemoveTask()
                        }
                    }
                }
            }
        }

        setContent { MiniPcTheme { DesktopRoot(vm) } }
    }

    private fun pushScreenMetrics() {
        val dm = resources.displayMetrics
        vm.onIntent(DesktopIntent.UpdateScreen(ScreenMetrics(dm.widthPixels, dm.heightPixels, dm.density)))
    }

    /** 3.3 – Phát hiện bàn phím vật lý/Bluetooth để ẩn bàn phím ảo. */
    private fun checkKeyboard() {
        val has = InputDevice.getDeviceIds().any { id ->
            InputDevice.getDevice(id)?.let { d ->
                !d.isVirtual && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
                    (d.sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD
            } == true
        } || resources.configuration.keyboard != Configuration.KEYBOARD_NOKEYS
        if (has != vm.state.value.hasHardKeyboard) vm.onIntent(DesktopIntent.HardKeyboard(has))
        if (has) ImmersiveController.hideIme(this)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        pushScreenMetrics()
        checkKeyboard()
        ImmersiveController.apply(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ImmersiveController.apply(this)
    }

    override fun onResume() { super.onResume(); ImmersiveController.apply(this) }

    /** Bấm Home (launcher) khi đang ở desktop → đóng các menu. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.onIntent(DesktopIntent.CloseOverlays)
    }

    /** 3.3 + 10.1 – Phím tắt hệ thống & tổ hợp cứu hộ Vol+ / Vol- giữ 3 giây. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> volUp = down
            KeyEvent.KEYCODE_VOLUME_DOWN -> volDown = down
        }
        if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP || e.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            handler.removeCallbacks(panic)
            if (volUp && volDown) handler.postDelayed(panic, 3000)
        }

        if (vm.state.value.booted) {
            if (down && e.repeatCount == 0) {
                when {
                    e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_TAB -> { vm.onIntent(DesktopIntent.CycleWindow); return true }
                    e.isMetaPressed && e.keyCode == KeyEvent.KEYCODE_D -> { vm.onIntent(DesktopIntent.ShowDesktop); return true }
                    e.isCtrlPressed && e.isShiftPressed && e.keyCode == KeyEvent.KEYCODE_ESCAPE -> {
                        vm.onIntent(DesktopIntent.OpenInternal(InternalKind.TASKS)); return true
                    }
                    e.isAltPressed && e.keyCode == KeyEvent.KEYCODE_F4 -> { vm.onIntent(DesktopIntent.CloseActiveWindow); return true }
                }
                metaAlone = e.keyCode == KeyEvent.KEYCODE_META_LEFT || e.keyCode == KeyEvent.KEYCODE_META_RIGHT
            } else if (down) {
                metaAlone = false
            }
            // Phím Win nhả ra mà không kèm phím khác → mở/đóng Start Menu
            if (e.action == KeyEvent.ACTION_UP && metaAlone &&
                (e.keyCode == KeyEvent.KEYCODE_META_LEFT || e.keyCode == KeyEvent.KEYCODE_META_RIGHT)) {
                metaAlone = false
                vm.onIntent(DesktopIntent.ToggleStart)
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        handler.removeCallbacks(panic)
        getSystemService(InputManager::class.java).unregisterInputDeviceListener(inputListener)
        if (isFinishing) vm.emergencyRestore()   // mọi luồng thoát đều trả DPI
        super.onDestroy()
    }
}
