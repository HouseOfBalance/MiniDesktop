package com.minipc.desktop.core.utils

import com.minipc.desktop.domain.model.ProcessMetric
import com.minipc.desktop.domain.model.SystemMetrics

object SystemMetricsParser {
    private val resRe = Regex("^([\\d.]+)([KMGT]?)$")

    private fun parseRes(s: String): Long {
        val m = resRe.find(s) ?: return 0L
        val v = m.groupValues[1].toDoubleOrNull() ?: return 0L
        return when (m.groupValues[2]) { "M" -> v * 1024; "G" -> v * 1024 * 1024; "T" -> v * 1024 * 1024 * 1024; else -> v }.toLong()
    }

    /** CPU tổng + (%CPU, RAM KB) từng process từ một lần `top -b -n 1`. */
    fun parseTop(text: String): Triple<Float, Map<String, Float>, Map<String, Long>> {
        var total = 0f
        val cpu = HashMap<String, Float>()
        val ram = HashMap<String, Long>()
        var cpuIdx = -1; var resIdx = -1; var nameIdx = -1; var colCount = 0
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.contains("%cpu") && line.contains("%idle")) {
                val t = Regex("(\\d+)%cpu").find(line)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
                val idle = Regex("(\\d+)%idle").find(line)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
                if (t > 0) total = ((t - idle) / t * 100f).coerceIn(0f, 100f)
                continue
            }
            if (line.startsWith("PID")) {
                val cols = line.replace("S[%CPU]", "S %CPU").split(Regex("\\s+"))
                cpuIdx = cols.indexOfFirst { it.contains("%CPU") }
                resIdx = cols.indexOf("RES")
                nameIdx = cols.size - 1
                colCount = cols.size
                continue
            }
            if (cpuIdx >= 0 && line[0].isDigit()) {
                val parts = line.split(Regex("\\s+"), limit = colCount)
                if (parts.size == colCount) {
                    val pkg = parts[nameIdx].substringBefore(':')
                    cpu[pkg] = (cpu[pkg] ?: 0f) + (parts[cpuIdx].toFloatOrNull() ?: 0f)
                    if (resIdx >= 0) ram[pkg] = (ram[pkg] ?: 0L) + parseRes(parts[resIdx])
                }
            }
        }
        return Triple(total, cpu, ram)
    }

    fun parseProcMeminfo(text: String): Pair<Long, Long> {
        fun kb(key: String) = Regex("$key:\\s+(\\d+)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val total = kb("MemTotal")
        return (total - kb("MemAvailable")) to total.coerceAtLeast(1)
    }

    fun merge(cpuTotal: Float, cpu: Map<String, Float>, ram: Map<String, Long>, used: Long, total: Long): SystemMetrics {
        val list = (cpu.keys + ram.keys).filter { it.contains('.') }
            .map { ProcessMetric(it, 0, cpu[it] ?: 0f, ram[it] ?: 0L) }
            .sortedByDescending { it.ramKb }
        return SystemMetrics(cpuTotal, used, total, list)
    }
}
