package com.minipc.desktop.core.shizuku

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** Activity trong suốt, tự đóng sau 1.5s – chỉ để thử mở ở windowingMode 5 (Freeform). */
class ProbeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 1500)
    }
}
