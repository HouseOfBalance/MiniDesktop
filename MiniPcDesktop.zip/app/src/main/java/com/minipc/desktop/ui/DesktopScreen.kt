package com.minipc.desktop.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.minipc.desktop.domain.model.ShortcutType
import com.minipc.desktop.domain.model.WallpaperType
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.desktop.*
import com.minipc.desktop.ui.fileexplorer.FileExplorerWindow
import com.minipc.desktop.ui.fileexplorer.InternalWindowFrame
import com.minipc.desktop.ui.onboarding.OnboardingScreen
import com.minipc.desktop.ui.startmenu.StartMenu
import com.minipc.desktop.ui.systemtray.ControlCenter
import com.minipc.desktop.ui.systemtray.SystemTray
import com.minipc.desktop.ui.taskmanager.TaskManagerWindow
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.topdock.TopDock
import java.io.File

@Composable
fun DesktopRoot(vm: DesktopViewModel) {
    val state by vm.state.collectAsState()
    val overlay = remember { UiOverlay() }
    val dd = remember { DragDropState() }

    CompositionLocalProvider(LocalIconCache provides vm.iconCache, LocalOverlay provides overlay, LocalDragDrop provides dd) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (!state.booted) OnboardingScreen(vm, state)
            else DesktopScreen(vm, state, overlay, dd)
            OverlayHost(overlay)
        }
    }
}

@Composable
private fun DesktopScreen(vm: DesktopViewModel, state: DesktopState, overlay: UiOverlay, dd: DragDropState) {
    val onIntent: (DesktopIntent) -> Unit = vm::onIntent
    val holder = remember { GridHolder() }
    val density = LocalDensity.current
    val s = state.settings

    // VisibilityTracker: chỉ phát video khi Activity resumed, màn hình bật và không có app phóng to che desktop.
    var resumed by remember { mutableStateOf(true) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) resumed = true else if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val playing = resumed && state.screenOn && !state.maximizedAppActive

    // Backdrop cho GlassSurface
    val backdrop: (@Composable () -> Unit)? = remember(s.wallpaperPath, s.wallpaperType) {
        if (s.wallpaperType == WallpaperType.VIDEO) null
        else {
            val f: @Composable () -> Unit = { StaticBackdrop(s.wallpaperPath, s.wallpaperType) }
            f
        }
    }

    // Kéo thả: bắt đầu kéo từ Start Menu → đóng menu (menu vẫn giữ composition, chỉ trong suốt)
    LaunchedEffect(dd.payload) { if (dd.payload is DragPayload.App) onIntent(DesktopIntent.CloseOverlays) }

    val screenShortcutMenu: (Long, androidx.compose.ui.geometry.Offset) -> Unit = { id, pos ->
        state.shortcuts.firstOrNull { it.id == id }?.let { overlay.showMenu(pos, shortcutMenu(it, onIntent)) }
    }
    dd.onReleaseWithoutMove = { p, pos ->
        when (p) {
            is DragPayload.Shortcut -> screenShortcutMenu(p.id, pos)
            is DragPayload.File -> p.onRelease?.invoke(pos)
            else -> {}
        }
    }
    dd.onDrop = { p, pos ->
        val spec = holder.spec
        if (spec.contains(pos.x, pos.y)) {
            val (c, r) = spec.cellOf(pos.x, pos.y)
            when (p) {
                is DragPayload.App -> onIntent(DesktopIntent.DropApp(p.pkg, c, r))
                is DragPayload.Shortcut -> onIntent(DesktopIntent.MoveShortcut(p.id, c, r))
                is DragPayload.File -> onIntent(DesktopIntent.DropFile(p.path, p.title, c, r))
            }
        }
    }

    CompositionLocalProvider(LocalBackdrop provides backdrop) {
        Box(Modifier.fillMaxSize()) {
            // 1. Hình nền
            WallpaperLayer(s.wallpaperPath, s.wallpaperType, playing)

            // 2. Lưới shortcut (chừa vùng Top Dock)
            Box(Modifier.fillMaxSize().padding(top = Dims.Reserved).windowInsetsPadding(WindowInsets.displayCutout)) {
                DesktopGrid(state, holder, onIntent,
                    onWallpaperDialog = { overlay.showDialog { d -> WallpaperDialog(vm, d) } },
                    onDpiDialog = { overlay.showDialog { d -> DpiDialog(vm, d) } })
            }

            // 3. Cửa sổ nội bộ (File Explorer, Task Manager)
            state.internalWindows.forEachIndexed { idx, w ->
                key(w.id) {
                    val off = with(density) { (idx % 6 * 28).dp.toPx() }
                    val title = if (w.kind == InternalKind.FILES) "File Explorer" else "Task Manager"
                    InternalWindowFrame(title, 160f + off, 120f + off, 760, 460,
                        onClose = { onIntent(DesktopIntent.CloseInternal(w.id)) },
                        onFocus = { onIntent(DesktopIntent.FocusInternal(w.id)) }) {
                        if (w.kind == InternalKind.FILES) FileExplorerWindow(vm, w.path) else TaskManagerWindow(vm, state)
                    }
                }
            }

            // 4. Cụm nút căn chỉnh cửa sổ
            WindowHelperOverlay(state.activeWindow != null, onIntent,
                Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp))

            // 5. Scrim đóng menu khi chạm ra ngoài
            if (state.startOpen || state.controlCenterOpen) {
                Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onIntent(DesktopIntent.CloseOverlays) } })
            }

            // 6. Dock + Tray (né tai thỏ bằng displayCutout insets)
            Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
                TopDock(state, onIntent, Modifier.align(Alignment.TopCenter).padding(top = Dims.DockTop))
                SystemTray(state, onIntent, Modifier.align(Alignment.TopEnd).padding(top = Dims.DockTop, end = 8.dp))
                // 7. Start Menu / Control Center
                StartMenu(state, onIntent, Modifier.align(Alignment.TopCenter).padding(top = Dims.Reserved))
                ControlCenter(state, onIntent, Modifier.align(Alignment.TopEnd).padding(top = Dims.Reserved, end = 8.dp))
            }

            // 8. Bóng kéo thả
            DragShadow(dd)

            // 9. Cảnh báo ROM
            if (state.compatOk == false) {
                androidx.compose.material3.Text(
                    "ROM có thể chặn Freeform – cửa sổ có thể không hoạt động", color = Color(0xFFFFB74D),
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp), fontSize = 12.sp)
            }

            // 10. Góc cứu hộ: chạm 5 lần liên tiếp ở góc trên-trái trong 3 giây
            PanicCorner(Modifier.align(Alignment.TopStart)) { onIntent(DesktopIntent.Panic) }
        }
    }
}

@Composable
private fun PanicCorner(modifier: Modifier, onPanic: () -> Unit) {
    var taps by remember { mutableStateOf(listOf<Long>()) }
    Box(modifier.size(56.dp).pointerInput(Unit) {
        detectTapGestures {
            val now = System.currentTimeMillis()
            taps = taps.filter { now - it < 3000 } + now
            if (taps.size >= 5) { taps = emptyList(); onPanic() }
        }
    })
}
