package com.minipc.desktop.ui.topdock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.core.window.AppSessionManager
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.InternalKind
import com.minipc.desktop.ui.InternalWindow
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.desktop.ConfirmDialog
import com.minipc.desktop.ui.theme.Accent
import com.minipc.desktop.ui.theme.Dims
import com.minipc.desktop.ui.tools.Tool
import com.minipc.desktop.ui.tools.ToolIcon
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Taskbar dạng viên thuốc đặt ở TRÊN cùng. Chỉ hiện app ghim + cửa sổ đang mở BÊN TRONG Mini PC
 * (thuộc desktop ảo hiện tại). Rê chuột lên icon → xem trước cửa sổ.
 */
@Composable
fun TopDock(state: DesktopState, onIntent: (DesktopIntent) -> Unit, clock: StateFlow<Long>, sessions: AppSessionManager, modifier: Modifier = Modifier) {
    val overlay = LocalOverlay.current
    val installed = remember(state.apps) { state.apps.map { it.packageName }.toSet() }
    val wins = state.internalWindows.filter { it.desktop == state.currentDesktop }
    val appWins = wins.filter { it.kind == InternalKind.APP }
    val pinned = state.pinned.filter { it.onDock && it.packageName in installed }.map { it.packageName }
    val shownIds = pinned.mapNotNull { pkg -> appWins.firstOrNull { it.pkg == pkg }?.id }.toSet()
    val extraWins = appWins.filter { it.id !in shownIds }
    val toolWins = wins.filter { it.kind != InternalKind.APP }
    val focusedId = wins.lastOrNull { !it.minimized }?.id
    var deskPos by remember { mutableStateOf(Offset.Zero) }

    GlassSurface(modifier.height(Dims.DockHeight), RoundedCornerShape(28.dp), tint = Color(0xFF111729)) {
        Row(
            Modifier.fillMaxHeight().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            DockButton(Icons.Filled.Apps, state.startOpen) { onIntent(DesktopIntent.ToggleStart) }
            DockButton(Icons.Filled.Search, false) { onIntent(DesktopIntent.OpenSearch) }
            Sep()
            pinned.forEach { pkg ->
                val w = appWins.firstOrNull { it.pkg == pkg }
                AppItem(pkg, w, w != null && w.id == focusedId, true, state.desktops, onIntent, sessions)
            }
            extraWins.forEach { AppItem(it.pkg!!, it, it.id == focusedId, false, state.desktops, onIntent, sessions) }
            toolWins.forEach { ToolItem(it, it.id == focusedId, onIntent) }
            Sep()
            Box(Modifier.onGloballyPositioned { deskPos = it.positionInRoot() }) {
                DockButton(Icons.Filled.Layers, false) { overlay.showMenu(Offset(deskPos.x, deskPos.y + 120f), desktopMenu(state, onIntent)) }
            }
            DockButton(Icons.Filled.Settings, state.controlCenterOpen) { onIntent(DesktopIntent.ToggleControlCenter) }
            ClockText(clock)
            DockButton(Icons.Filled.PowerSettingsNew, false, Color(0xFFFF8A80)) {
                overlay.showDialog { d ->
                    ConfirmDialog("Tắt Mini PC", "Đóng toàn bộ cửa sổ, khôi phục DPI và quay về launcher?",
                        { onIntent(DesktopIntent.Shutdown) }, d)
                }
            }
        }
    }
}

private fun desktopMenu(state: DesktopState, onIntent: (DesktopIntent) -> Unit) = buildList {
    for (i in 0 until state.desktops)
        add(MenuItem((if (i == state.currentDesktop) "✓ " else "    ") + "Desktop ${i + 1}") { onIntent(DesktopIntent.SwitchDesktop(i)) })
    add(MenuItem("+ Thêm desktop", state.desktops < 6) { onIntent(DesktopIntent.AddDesktop) })
    add(MenuItem("– Xóa desktop cuối", state.desktops > 1) { onIntent(DesktopIntent.RemoveDesktop) })
}

@Composable
private fun ClockText(clock: StateFlow<Long>) {
    val ms by clock.collectAsState()
    val tFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dFmt = remember { SimpleDateFormat("dd/MM", Locale.getDefault()) }
    Column(Modifier.padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tFmt.format(Date(ms)), color = Color.White, fontSize = 17.sp)
        Text(dFmt.format(Date(ms)), color = Color(0xFF9AA4C0), fontSize = 12.sp)
    }
}

@Composable
private fun Sep() = Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(24.dp).background(Color(0x33FFFFFF)))

@Composable
private fun DockButton(icon: ImageVector, active: Boolean, tint: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Color(0x2E8C9EFF) else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = if (active) Accent else tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun Indicator(modifier: Modifier, active: Boolean) {
    if (active) Box(modifier.padding(bottom = 1.dp).width(18.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Accent))
    else DotIndicator(modifier.padding(bottom = 2.dp))
}

/** Rê chuột vào/ra → bật/tắt thẻ xem trước cửa sổ. */
private fun Modifier.hoverPreview(
    key: Any?, anchor: () -> Offset, onEnter: (Offset) -> Unit, onExit: () -> Unit
): Modifier = pointerInput(key) {
    awaitPointerEventScope {
        while (true) {
            val e = awaitPointerEvent(PointerEventPass.Initial)
            when (e.type) {
                PointerEventType.Enter -> onEnter(anchor())
                PointerEventType.Exit -> onExit()
            }
        }
    }
}

@Composable
private fun AppItem(
    pkg: String, win: InternalWindow?, focused: Boolean, pinned: Boolean, desktops: Int,
    onIntent: (DesktopIntent) -> Unit, sessions: AppSessionManager
) {
    val overlay = LocalOverlay.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    val size = with(LocalDensity.current) { 42.dp.toPx() }
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (focused) Color(0x2E8C9EFF) else Color.Transparent)
            .onGloballyPositioned { origin = it.positionInRoot() }
            .hoverPreview(win?.id, { Offset(origin.x + size / 2, origin.y + size) },
                onEnter = { anchor ->
                    if (win != null) {
                        val title = win.title ?: pkg
                        overlay.hover = HoverInfo(title, anchor, sessions.cachedThumb(win.id)) { AppIcon(pkg, 56.dp) }
                        sessions.captureThumb(win.id) { bmp ->
                            if (bmp != null && overlay.hover?.title == title) overlay.hover = HoverInfo(title, anchor, bmp) { AppIcon(pkg, 56.dp) }
                        }
                    }
                },
                onExit = { overlay.hover = null })
            .clickable {
                overlay.hover = null
                if (win != null) onIntent(DesktopIntent.ToggleInternal(win.id)) else onIntent(DesktopIntent.LaunchApp(pkg))
            }
            .secondaryClick { pos ->
                overlay.hover = null
                overlay.showMenu(pos, buildList {
                    add(MenuItem(if (win != null) "Chuyển tới cửa sổ" else "Mở") { onIntent(DesktopIntent.LaunchApp(pkg)) })
                    add(MenuItem("Cửa sổ mới") { onIntent(DesktopIntent.LaunchApp(pkg, false, true)) })
                    add(MenuItem(if (pinned) "Bỏ ghim khỏi Dock" else "Ghim lên Dock") {
                        onIntent(if (pinned) DesktopIntent.UnpinDock(pkg) else DesktopIntent.PinDock(pkg))
                    })
                    if (win != null) {
                        for (d in 0 until desktops) if (d != win.desktop)
                            add(MenuItem("Chuyển sang Desktop ${d + 1}") { onIntent(DesktopIntent.MoveToDesktop(win.id, d)) })
                        add(MenuItem("Đóng cửa sổ") { onIntent(DesktopIntent.CloseInternal(win.id)) })
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) {
        AppIcon(pkg, 30.dp)
        if (win != null) Indicator(Modifier.align(Alignment.BottomCenter), focused)
    }
}

@Composable
private fun ToolItem(w: InternalWindow, focused: Boolean, onIntent: (DesktopIntent) -> Unit) {
    val overlay = LocalOverlay.current
    val tool = Tool.fromKind(w.kind)
    var origin by remember { mutableStateOf(Offset.Zero) }
    val size = with(LocalDensity.current) { 42.dp.toPx() }
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(if (focused) Color(0x2E8C9EFF) else Color.Transparent)
            .onGloballyPositioned { origin = it.positionInRoot() }
            .hoverPreview(w.id, { Offset(origin.x + size / 2, origin.y + size) },
                onEnter = { anchor -> overlay.hover = HoverInfo(tool.label, anchor, null) { ToolIcon(tool, 64.dp) } },
                onExit = { overlay.hover = null })
            .clickable { overlay.hover = null; onIntent(DesktopIntent.ToggleInternal(w.id)) }
            .secondaryClick { pos -> overlay.hover = null; overlay.showMenu(pos, listOf(MenuItem("Đóng") { onIntent(DesktopIntent.CloseInternal(w.id)) })) },
        contentAlignment = Alignment.Center
    ) {
        ToolIcon(tool, 30.dp)
        Indicator(Modifier.align(Alignment.BottomCenter), focused)
    }
}
