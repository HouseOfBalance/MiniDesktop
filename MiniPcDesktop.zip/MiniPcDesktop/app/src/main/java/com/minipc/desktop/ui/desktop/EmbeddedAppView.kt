package com.minipc.desktop.ui.desktop

import android.graphics.SurfaceTexture
import android.view.TextureView
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.minipc.desktop.core.window.AppSessionManager

/** Hiển thị màn hình ảo của một app (TextureView để xếp lớp đúng với các cửa sổ khác) và chuyển tiếp cảm ứng. */
@Composable
fun EmbeddedAppView(sessions: AppSessionManager, windowId: Int, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            TextureView(c).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) = sessions.attach(windowId, st, w, h)
                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = sessions.resize(windowId, w, h, st)
                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { sessions.detach(windowId); return true }
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
                setOnTouchListener { v, e -> sessions.touch(windowId, v, e); true }
                setOnGenericMotionListener { v, e -> sessions.generic(windowId, v, e) }
            }
        }
    )
}
