package com.minipc.desktop.data.repository

import android.content.*
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.Process
import android.util.DisplayMetrics
import android.util.LruCache
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.minipc.desktop.core.utils.StringUtils
import com.minipc.desktop.domain.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/** 6.2 – Bộ nhớ đệm icon: LruCache + ổ đĩa. */
@Singleton
class IconCache @Inject constructor(@ApplicationContext ctx: Context) {
    private val mem = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, v: Bitmap) = v.byteCount / 1024
    }
    private val dir = File(ctx.cacheDir, "icons").apply { mkdirs() }
    private fun file(key: String) = File(dir, key.replace('/', '_') + ".png")

    fun get(key: String): Bitmap? = mem.get(key) ?: file(key).takeIf { it.exists() }
        ?.let { BitmapFactory.decodeFile(it.path) }?.also { mem.put(key, it) }

    fun has(key: String) = mem.get(key) != null || file(key).exists()

    fun put(key: String, d: Drawable) {
        val bmp = d.toBitmap(128, 128)
        mem.put(key, bmp)
        runCatching { file(key).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }

    fun remove(key: String) { mem.remove(key); file(key).delete() }
}

/** 6.2 – Quét app bằng LauncherApps + lắng nghe cài/gỡ gói. */
@Singleton
class AppRepository @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val iconCache: IconCache
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()
    private var started = false

    fun start() {
        if (started) return
        started = true
        scan()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action != Intent.ACTION_PACKAGE_ADDED) i.data?.schemeSpecificPart?.let { iconCache.remove(it) }
                scan()
            }
        }, f, ContextCompat.RECEIVER_EXPORTED)
    }

    fun scan() {
        scope.launch {
            mutex.withLock {
                delay(300) // gom nhiều sự kiện liên tiếp
                _apps.value = doScan()
            }
        }
    }

    private fun doScan(): List<AppInfo> {
        val la = ctx.getSystemService(LauncherApps::class.java)
        return la.getActivityList(null, Process.myUserHandle())
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .map { info ->
                val pkg = info.applicationInfo.packageName
                if (!iconCache.has(pkg)) runCatching { iconCache.put(pkg, info.getIcon(DisplayMetrics.DENSITY_XXHIGH)) }
                else iconCache.get(pkg)   // nạp sẵn vào RAM ở luồng nền → mở Ngăn ứng dụng không bị giật
                val label = info.label.toString()
                AppInfo(pkg, label, info.componentName.flattenToShortString(), StringUtils.normalize(label))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
