package com.minipc.desktop.ui.taskmanager

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.core.shizuku.PrivilegeChecker
import com.minipc.desktop.domain.model.SystemMetrics
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.common.AppIcon
import com.minipc.desktop.ui.theme.Accent

/** 8.3 – Task Manager: biểu đồ CPU/RAM tổng thể + bảng tiến trình + End Task. Chỉ lấy số liệu khi cửa sổ đang mở. */
@Composable
fun TaskManagerWindow(vm: DesktopViewModel, state: DesktopState) {
    var m by remember { mutableStateOf(SystemMetrics()) }
    val cpuHist = remember { mutableStateListOf<Float>() }
    val ramHist = remember { mutableStateListOf<Float>() }
    val enabled = state.privilege != PrivilegeChecker.Mode.NONE

    LaunchedEffect(enabled) {
        if (!enabled) return@LaunchedEffect
        vm.metricsRepo.stream().collect { s ->
            m = s
            cpuHist.add(s.cpuTotalPercent); ramHist.add(s.ramUsedKb * 100f / s.ramTotalKb)
            if (cpuHist.size > 40) cpuHist.removeAt(0)
            if (ramHist.size > 40) ramHist.removeAt(0)
        }
    }
    val labels = remember(state.apps) { state.apps.associate { it.packageName to it.label } }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!enabled) { Text("Cần Shizuku/Root để đọc số liệu hệ thống.", color = Color(0xFFFFB74D), fontSize = 13.sp); return@Column }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chart("CPU ${"%.0f".format(m.cpuTotalPercent)}%", cpuHist, Color(0xFF66BB6A), Modifier.weight(1f))
            Chart("RAM ${m.ramUsedKb / 1024} / ${m.ramTotalKb / 1024} MB", ramHist, Accent, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            Text("Ứng dụng", color = Color(0xFF9FB4C7), fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text("CPU", color = Color(0xFF9FB4C7), fontSize = 11.sp, modifier = Modifier.width(54.dp))
            Text("RAM", color = Color(0xFF9FB4C7), fontSize = 11.sp, modifier = Modifier.width(74.dp))
            Spacer(Modifier.width(84.dp))
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            items(m.processes, key = { it.packageName }) { p ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0x22FFFFFF)).padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(p.packageName, 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(labels[p.packageName] ?: p.packageName, color = Color.White, fontSize = 12.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text("%.1f%%".format(p.cpuPercent), color = Color.White, fontSize = 12.sp, modifier = Modifier.width(54.dp))
                    Text("${p.ramKb / 1024} MB", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(74.dp))
                    Button({ vm.onIntent(DesktopIntent.ForceStop(p.packageName)) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                        contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.height(28.dp).width(84.dp)) {
                        Text("Buộc dừng", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun Chart(title: String, data: List<Float>, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Color(0x22FFFFFF)).padding(10.dp)) {
        Text(title, color = Color.White, fontSize = 12.sp)
        Canvas(Modifier.fillMaxWidth().height(70.dp).padding(top = 6.dp)) {
            if (data.size < 2) return@Canvas
            val path = Path()
            data.forEachIndexed { i, v ->
                val x = size.width * i / 39f
                val y = size.height * (1f - (v / 100f).coerceIn(0f, 1f))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(width = 3f))
            drawLine(Color(0x33FFFFFF), Offset(0f, size.height), Offset(size.width, size.height), 1f)
        }
    }
}
