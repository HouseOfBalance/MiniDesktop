package com.minipc.desktop.ui.systemtray

import android.bluetooth.BluetoothManager
import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.minipc.desktop.domain.model.NotifItem
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopState
import com.minipc.desktop.ui.common.AppIcon
import com.minipc.desktop.ui.common.GlassSurface
import com.minipc.desktop.ui.theme.Accent

/** 7.2/7.3 – Control Center: nút gạt, thanh trượt, thông báo gom nhóm, nút nguồn. */
@Composable
fun ControlCenter(state: DesktopState, onIntent: (DesktopIntent) -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        state.controlCenterOpen, modifier,
        enter = slideInVertically { -it / 4 } + fadeIn(), exit = slideOutVertically { -it / 4 } + fadeOut()
    ) {
        GlassSurface(Modifier.width(360.dp), RoundedCornerShape(20.dp), tint = Color(0xD91C1F24)) {
            ControlContent(state, onIntent)
        }
    }
}

@Composable
private fun ControlContent(state: DesktopState, onIntent: (DesktopIntent) -> Unit) {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var bt by remember { mutableStateOf(runCatching { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true }.getOrDefault(false)) }
    var lockBrightness by remember { mutableStateOf(Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 1) == 0) }
    var brightness by remember { mutableFloatStateOf(Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128).toFloat()) }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var dpi by remember { mutableFloatStateOf(if (state.settings.customDpi > 0) state.settings.customDpi.toFloat() else 240f) }

    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // QuickToggles
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("Wi-Fi", Icons.Filled.Wifi, state.wifi.enabled, Modifier.weight(1f)) { onIntent(DesktopIntent.ToggleWifi(!state.wifi.enabled)) }
            Tile("Bluetooth", Icons.Filled.Bluetooth, bt, Modifier.weight(1f)) { bt = !bt; onIntent(DesktopIntent.ToggleBluetooth(bt)) }
            Tile("Khóa sáng", Icons.Filled.BrightnessMedium, lockBrightness, Modifier.weight(1f)) {
                lockBrightness = !lockBrightness; onIntent(DesktopIntent.AutoBrightnessLock(lockBrightness))
            }
        }
        // Sliders
        SliderRow(Icons.Filled.VolumeUp, volume, 0f..maxVol.toFloat(), { volume = it; onIntent(DesktopIntent.SetVolume(it.toInt())) })
        SliderRow(Icons.Filled.LightMode, brightness, 1f..255f, { brightness = it }, { onIntent(DesktopIntent.SetBrightness(brightness.toInt())) })
        SliderRow(Icons.Filled.AspectRatio, dpi, 160f..400f, { dpi = it }, { onIntent(DesktopIntent.SetDpi(dpi.toInt())) }, "${dpi.toInt()}")

        // Notifications
        Text("Thông báo", color = Color(0xFFCCCCCC), fontSize = 12.sp)
        val hasChildren = state.notifs.filter { !it.isSummary }.mapNotNull { it.groupKey }.toSet()
        val visible = state.notifs.filterNot { it.isSummary && it.groupKey in hasChildren }
        val groups = visible.groupBy { it.groupKey ?: it.key }.values.toList()
        if (groups.isEmpty()) Text("Không có thông báo", color = Color(0xFF888888), fontSize = 13.sp)
        LazyColumn(Modifier.heightIn(max = 240.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(groups, key = { it.first().groupKey ?: it.first().key }) { g ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (g.size > 1) Text("${g.first().appName} · ${g.size}", color = Color(0xFF9FB4C7), fontSize = 11.sp)
                    g.forEach { n -> key(n.key) { NotifRow(n, onIntent) } }
                }
            }
        }

        // PowerBar
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ onIntent(DesktopIntent.RestartUi) }, Modifier.weight(1f)) {
                Icon(Icons.Filled.RestartAlt, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Khởi động lại UI", fontSize = 12.sp)
            }
            Button({ onIntent(DesktopIntent.Shutdown) }, Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) {
                Icon(Icons.Filled.PowerSettingsNew, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Shutdown", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Tile(label: String, icon: ImageVector, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(if (on) Accent else Color(0x33FFFFFF))
            .clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (on) Color.Black else Color.White)
        Text(label, color = if (on) Color.Black else Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun SliderRow(
    icon: ImageVector, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit, onFinish: (() -> Unit)? = null, trailing: String? = null
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Slider(value, onChange, Modifier.weight(1f).padding(horizontal = 8.dp), valueRange = range,
            onValueChangeFinished = onFinish)
        if (trailing != null) Text(trailing, color = Color.White, fontSize = 11.sp, modifier = Modifier.width(30.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotifRow(n: NotifItem, onIntent: (DesktopIntent) -> Unit) {
    val body: @Composable () -> Unit = {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0x33FFFFFF))
                .clickable { onIntent(DesktopIntent.OpenNotif(n)) }.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIcon(n.packageName, 28.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(n.title.ifEmpty { n.appName }, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (n.text.isNotEmpty()) Text(n.text, color = Color(0xFFCCCCCC), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
    if (!n.clearable) { body(); return }
    // Vuốt ngang → cancelNotification()
    val st = rememberSwipeToDismissBoxState(confirmValueChange = {
        if (it != SwipeToDismissBoxValue.Settled) { onIntent(DesktopIntent.DismissNotif(n.key)); true } else false
    })
    SwipeToDismissBox(st, backgroundContent = {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).background(Color(0x44FF5555)))
    }) { body() }
}
