package com.minipc.desktop.core.window

import com.minipc.desktop.core.shizuku.ShellExecutor
import com.minipc.desktop.domain.model.Bounds
import com.minipc.desktop.domain.model.WindowInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Đọc danh sách task đang chạy qua `dumpsys activity activities` (best-effort, định dạng thay đổi theo ROM).
 * Thứ tự: phần tử đầu = cửa sổ trên cùng (active).
 */
@Singleton
class WindowTracker @Inject constructor(private val shell: ShellExecutor) {
    private val _windows = MutableStateFlow<List<WindowInfo>>(emptyList())
    val windows: StateFlow<List<WindowInfo>> = _windows.asStateFlow()

    suspend fun refresh(): List<WindowInfo> {
        val out = shell.exec("dumpsys activity activities | grep -E 'Task(Record)?\\{|mBounds=|realActivity='")
        if (out.startsWith("ERROR")) return _windows.value
        val list = parse(out)
        _windows.value = list
        return list
    }

    companion object {
        private val taskRe = Regex("Task(?:Record)?\\{[^#]*#(\\d+)(.*)")
        private val pkgRe = Regex("A=(?:\\d+:)?([\\w.]+)")
        private val modeRe = Regex("mode=(\\w+)")
        private val typeRe = Regex("type=(\\w+)")
        private val visRe = Regex("visible=(true|false)")
        private val boundsRe = Regex("mBounds=Rect\\((-?\\d+), (-?\\d+) - (-?\\d+), (-?\\d+)\\)")
        private val compRe = Regex("realActivity=(\\S+)")

        fun parse(text: String): List<WindowInfo> {
            class Tmp(val id: Int, val pkg: String, val mode: String, val vis: Boolean) {
                var bounds: Bounds? = null; var comp: String? = null
            }
            val result = LinkedHashMap<Int, Tmp>()
            var cur: Tmp? = null
            for (line in text.lineSequence()) {
                val t = taskRe.find(line)
                if (t != null) {
                    val id = t.groupValues[1].toInt()
                    val rest = t.groupValues[2]
                    val pkg = pkgRe.find(rest)?.groupValues?.get(1)
                    val type = typeRe.find(rest)?.groupValues?.get(1) ?: "standard"
                    cur = if (pkg != null && type == "standard" && id > 0 && !result.containsKey(id)) {
                        Tmp(id, pkg, modeRe.find(rest)?.groupValues?.get(1) ?: "fullscreen",
                            visRe.find(rest)?.groupValues?.get(1) != "false").also { result[id] = it }
                    } else null
                    continue
                }
                val c = cur ?: continue
                boundsRe.find(line)?.let { m ->
                    val (l, tp, r, b) = m.destructured
                    if (c.bounds == null) c.bounds = Bounds(l.toInt(), tp.toInt(), r.toInt(), b.toInt())
                }
                compRe.find(line)?.let { if (c.comp == null) c.comp = it.groupValues[1] }
            }
            return result.values.map { WindowInfo(it.id, it.pkg, it.comp, it.bounds, it.mode, it.vis) }
        }
    }
}
