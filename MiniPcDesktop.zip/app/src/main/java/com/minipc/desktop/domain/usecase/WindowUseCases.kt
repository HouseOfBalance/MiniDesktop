package com.minipc.desktop.domain.usecase

import com.minipc.desktop.core.shizuku.ShellExecutor
import com.minipc.desktop.core.window.SnapRegion
import com.minipc.desktop.core.window.WindowMath
import com.minipc.desktop.core.window.WindowTracker
import com.minipc.desktop.data.db.AppBoundsDao
import com.minipc.desktop.data.db.AppBoundsEntity
import com.minipc.desktop.data.db.ShortcutDao
import com.minipc.desktop.domain.model.Bounds
import com.minipc.desktop.domain.model.ScreenMetrics
import com.minipc.desktop.domain.model.WindowInfo
import kotlinx.coroutines.delay
import javax.inject.Inject

/** 8.1 – Mở app dạng cửa sổ tự do (hoặc toàn màn hình / focus cửa sổ đang có). */
class LaunchAppUseCase @Inject constructor(
    private val shell: ShellExecutor,
    private val tracker: WindowTracker,
    private val boundsDao: AppBoundsDao,
    private val shortcutDao: ShortcutDao
) {
    suspend operator fun invoke(component: String, pkg: String, screen: ScreenMetrics, fullscreen: Boolean) {
        val existing = tracker.windows.value.firstOrNull { it.packageName == pkg }
        if (existing != null && !fullscreen) { shell.exec("am start -n $component"); return }
        if (fullscreen) { shell.exec("am start -n $component --windowingMode 1"); return }

        val saved = Bounds.parse(boundsDao.get(pkg) ?: shortcutDao.getAll().firstOrNull { it.packageName == pkg }?.lastBounds)
        val b = WindowMath.clampBelowDock(
            saved ?: WindowMath.defaultBounds(screen.widthPx, screen.heightPx, screen.topInsetPx), screen.topInsetPx
        )
        shell.exec("am start -n $component --windowingMode 5")
        // `am start` không có tuỳ chọn --bounds → đợi task xuất hiện rồi resize theo taskId.
        repeat(8) {
            delay(250)
            val w = tracker.refresh().firstOrNull { it.packageName == pkg }
            if (w != null) { resize(w.taskId, b); return }
        }
    }

    private suspend fun resize(taskId: Int, b: Bounds) {
        shell.exec("am task resize $taskId ${b.left} ${b.top} ${b.right} ${b.bottom}")
    }
}

/** 8.2 – Snap / maximize cửa sổ đang active. */
class WindowActionsUseCase @Inject constructor(
    private val shell: ShellExecutor,
    private val boundsDao: AppBoundsDao,
    private val shortcutDao: ShortcutDao
) {
    suspend fun snap(win: WindowInfo, region: SnapRegion, s: ScreenMetrics) {
        val b = WindowMath.region(region, s.widthPx, s.heightPx, s.topInsetPx)
        shell.exec("am task resize ${win.taskId} ${b.left} ${b.top} ${b.right} ${b.bottom}")
        boundsDao.upsert(AppBoundsEntity(win.packageName, b.serialize()))
        shortcutDao.updateBounds(win.packageName, b.serialize())
    }

    suspend fun forceStop(pkg: String) { shell.exec("am force-stop $pkg") }
}
