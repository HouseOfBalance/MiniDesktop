package com.minipc.desktop.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object Dims {
    val DockHeight = 40.dp
    val DockTop = 6.dp
    val Reserved = 52.dp      // vùng Top Dock chiếm
    val CellW = 84.dp
    val CellH = 96.dp
}

val Accent = Color(0xFF4CC2FF)

@Composable
fun MiniPcTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Color.Black,
        surface = Color(0xFF1C1F24), onSurface = Color.White,
        background = Color.Black, onBackground = Color.White
    ),
    content = content
)
