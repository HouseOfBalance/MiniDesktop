package com.minipc.desktop.ui.fileexplorer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.toSize
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.minipc.desktop.domain.model.FileItem
import com.minipc.desktop.ui.DesktopIntent
import com.minipc.desktop.ui.DesktopViewModel
import com.minipc.desktop.ui.common.*
import com.minipc.desktop.ui.desktop.ConfirmDialog
import com.minipc.desktop.ui.desktop.InputDialog
import com.minipc.desktop.ui.theme.Accent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Clip(val path: String, val cut: Boolean)

/** 9.1/9.2 – File Explorer 2 cột: quick access bên trái, lưới/danh sách bên phải, thao tác tệp, kéo ra Desktop. */
@Composable
fun FileExplorerWindow(vm: DesktopViewModel, windowId: Int, initialPath: String?) {
    val repo = vm.fileRepo
    val overlay = LocalOverlay.current
    val dd = LocalDragDrop.current
    val scope = rememberCoroutineScope()
    val quick = remember { repo.quickAccess() }
    var path by remember { mutableStateOf(initialPath ?: repo.desktopDir().path) }
    var files by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    var grid by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<String?>(null) }
    var clip by remember { mutableStateOf<Clip?>(null) }
    var preview by remember { mutableStateOf<String?>(null) }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var bounds by remember { mutableStateOf<Rect?>(null) }
    val curPath by rememberUpdatedState(path)

    LaunchedEffect(path, tick) { files = repo.list(path) }
    LaunchedEffect(query, path, tick) {
        if (query.isBlank()) results = emptyList() else { delay(300); results = repo.search(path, query) }
    }
    val shown = if (query.isBlank()) files else results

    fun io(block: () -> Unit) { scope.launch(Dispatchers.IO) { block(); tick++ } }
    DisposableEffect(windowId) {
        dd.fileTargets[windowId] = FileTarget({ bounds }) { src, move -> io { if (move) repo.move(src, curPath) else repo.copy(src, curPath) } }
        onDispose { dd.fileTargets.remove(windowId) }
    }

    fun open(f: FileItem) { if (f.isDir) { path = f.path; selected = null } else vm.onIntent(DesktopIntent.OpenFile(f.path)) }

    fun fileMenu(f: FileItem): List<MenuItem> = listOf(
        MenuItem("Mở") { open(f) },
        MenuItem("Xem nhanh", repo.isImage(f.path) || repo.isText(f.path)) { preview = f.path },
        MenuItem("Đổi tên") {
            overlay.showDialog { d -> InputDialog("Đổi tên", f.name, { n -> io { repo.rename(f.path, n) } }, d) }
        },
        MenuItem("Sao chép") { clip = Clip(f.path, false) },
        MenuItem("Cắt") { clip = Clip(f.path, true) },
        MenuItem("Xóa") {
            overlay.showDialog { d -> ConfirmDialog("Xóa", "Xóa \"${f.name}\"?", { io { repo.delete(f.path) } }, d) }
        }
    )

    fun emptyMenu(): List<MenuItem> = listOf(
        MenuItem("Thư mục mới") {
            overlay.showDialog { d -> InputDialog("Thư mục mới", "Thư mục mới", { n -> io { repo.createFolder(path, n) } }, d) }
        },
        MenuItem("Dán", clip != null) {
            clip?.let { c -> io { if (c.cut) repo.move(c.path, path) else repo.copy(c.path, path); if (c.cut) clip = null } }
        }
    )

    Row(Modifier.fillMaxSize().onGloballyPositioned { bounds = Rect(it.positionInRoot(), it.size.toSize()) }) {
        // Cột trái: truy cập nhanh
        Column(Modifier.width(150.dp).fillMaxHeight().background(Color(0xFF181B20)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            quick.forEach { q ->
                val sel = path == q.path
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (sel) Color(0x33FFFFFF) else Color.Transparent)
                        .clickable { path = q.path; selected = null }.padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (q.label.startsWith("USB")) Icons.Filled.Usb else Icons.Filled.Folder, null, tint = Accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(q.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        // Cột phải
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().height(40.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Tool(Icons.Filled.ArrowUpward) { File(path).parent?.let { path = it; selected = null } }
                Text(path, color = Color(0xFFCCCCCC), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                Row(
                    Modifier.width(150.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2A2F3C)).padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Search, null, tint = Color(0xFF9AA4C0), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Tìm…", color = Color(0xFF7D87A5), fontSize = 12.sp)
                        androidx.compose.foundation.text.BasicTextField(
                            query, { query = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Tool(Icons.Filled.CreateNewFolder) { emptyMenu()[0].action() }
                Tool(Icons.Filled.ContentPaste, clip != null) { emptyMenu()[1].action() }
                Tool(if (grid) Icons.Filled.ViewList else Icons.Filled.GridView) { grid = !grid }
            }
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .contextClick(onTap = { selected = null }) { overlay.showMenu(it, emptyMenu()) }
            ) {
                if (grid) LazyVerticalGrid(GridCells.Adaptive(88.dp), Modifier.fillMaxSize().padding(6.dp)) {
                    items(shown, key = { it.path }) { f ->
                        Item(f, selected == f.path, true, dd, overlay, { selected = f.path }, { open(f) }, ::fileMenu, !f.isDir && repo.isImage(f.path))
                    }
                } else LazyColumn(Modifier.fillMaxSize().padding(6.dp)) {
                    items(shown, key = { it.path }) { f ->
                        Item(f, selected == f.path, false, dd, overlay, { selected = f.path }, { open(f) }, ::fileMenu, !f.isDir && repo.isImage(f.path))
                    }
                }
                if (files.isEmpty()) Text("Thư mục trống", color = Color(0xFF777777), fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
            }
        }
    }

    preview?.let { p -> Preview(vm, p) { preview = null } }
}

@Composable
private fun Tool(icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Icon(icon, null, tint = if (enabled) Color.White else Color(0xFF555555),
        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).clickable(enabled = enabled, onClick = onClick).padding(7.dp))
}

@Composable
private fun Item(
    f: FileItem, selected: Boolean, gridMode: Boolean, dd: DragDropState, overlay: UiOverlay,
    onSelect: () -> Unit, onOpen: () -> Unit, menu: (FileItem) -> List<MenuItem>, isImg: Boolean = false
) {
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    val mod = Modifier.clip(RoundedCornerShape(8.dp))
        .background(if (selected) Color(0x33FFFFFF) else Color.Transparent)
        .dragSource(dd, DragPayload.File(f.path, f.name, f.isDir) { pos -> onSelect(); overlay.showMenu(pos, menu(f)) })
        .pointerInput(f.path) { detectTapGestures(onTap = { onSelect() }, onDoubleTap = { onOpen() }) }
        .secondaryClick { pos -> onSelect(); overlay.showMenu(pos, menu(f)) }
    val icon = if (f.isDir) Icons.Filled.Folder else Icons.Filled.InsertDriveFile
    val tint = if (f.isDir) Color(0xFFFFD166) else Color(0xFFE0E0E0)
    if (gridMode) Column(mod.fillMaxWidth().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (isImg) AsyncImage(File(f.path), null, Modifier.size(44.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        else Icon(icon, null, tint = tint, modifier = Modifier.size(44.dp))
        Text(f.name, color = Color.White, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    } else Row(mod.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Text(f.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(if (f.isDir) "" else "${f.size / 1024} KB", color = Color(0xFFAAAAAA), fontSize = 11.sp, modifier = Modifier.width(70.dp))
        Text(fmt.format(Date(f.modified)), color = Color(0xFFAAAAAA), fontSize = 11.sp)
    }
}

/** Xem nhanh ảnh / văn bản ngay trong cửa sổ. */
@Composable
private fun Preview(vm: DesktopViewModel, path: String, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val isImg = vm.fileRepo.isImage(path)
    val scroll = androidx.compose.foundation.rememberScrollState()
    LaunchedEffect(path) { if (!isImg) text = vm.fileRepo.readText(path) }
    Box(Modifier.fillMaxSize().background(Color(0xF0101215)).pointerInput(Unit) { detectTapGestures { } }) {
        if (isImg) AsyncImage(File(path), null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(12.dp))
        else Text(text, color = Color(0xFFE6E6E6), fontSize = 12.sp,
            modifier = Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp))
        Icon(Icons.Filled.Close, null, tint = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(36.dp).clip(RoundedCornerShape(18.dp))
                .background(Color(0x66000000)).clickable(onClick = onClose).padding(8.dp))
    }
}

