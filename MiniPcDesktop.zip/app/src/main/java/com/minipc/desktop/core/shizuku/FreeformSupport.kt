package com.minipc.desktop.core.shizuku

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

/** 2.2 – Bật các cờ Freeform / đa nhiệm thực. */
@Singleton
class FreeformEnabler @Inject constructor(private val shell: ShellExecutor) {
    suspend fun enable() {
        shell.exec("settings put global enable_freeform_support 1")
        shell.exec("settings put global force_resizable_activities 1")
        shell.exec("settings put global enable_non_resizable_multi_window 1")
        // Android 10+: cho phép nhiều cửa sổ cùng Resumed; thêm cờ desktop mode trên màn ngoài (vô hại nếu không hỗ trợ)
        shell.exec("settings put global force_desktop_mode_on_external_displays 1")
    }
}

/** 2.2 – Mở ProbeActivity ở windowingMode 5 rồi đọc dumpsys để biết ROM có chặn Freeform không. */
@Singleton
class CompatibilityProbe @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val shell: ShellExecutor
) {
    suspend fun run(): Boolean {
        shell.exec("am start -n ${ctx.packageName}/${ProbeActivity::class.java.name} --windowingMode 5")
        delay(900)
        val out = shell.exec(
            "dumpsys activity activities | grep -A 20 ProbeActivity | " +
                "grep -ciE 'mode=freeform|windowingMode=freeform|WINDOWING_MODE_FREEFORM'"
        )
        return (out.trim().toIntOrNull() ?: 0) > 0
    }
}
