package com.minipc.desktop.domain.usecase

import com.minipc.desktop.core.utils.StringUtils
import com.minipc.desktop.domain.model.AppInfo
import com.minipc.desktop.domain.model.DesktopShortcut
import kotlin.math.abs
import kotlin.math.min

/** 6.3 – Tìm kiếm mờ: bỏ dấu, Prefix, Acronym, Levenshtein. */
object FuzzyMatcher {
    fun search(query: String, apps: List<AppInfo>): List<AppInfo> {
        val q = StringUtils.normalize(query).trim()
        if (q.isEmpty()) return apps
        return apps.map { it to score(q, it.searchKey) }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<AppInfo, Int>> { it.second }.thenBy { it.first.label.lowercase() })
            .map { it.first }
    }

    fun score(q: String, t: String): Int {
        if (t == q) return 1000
        if (t.startsWith(q)) return 900
        val words = t.split(' ', '-', '_', '.').filter { it.isNotEmpty() }
        if (words.any { it.startsWith(q) }) return 800
        if (words.map { it.first() }.joinToString("").startsWith(q)) return 700
        if (t.contains(q)) return 500
        val maxDist = when { q.length <= 3 -> 0; q.length <= 6 -> 1; else -> 2 }
        if (maxDist == 0) return 0
        val d = (words + t.take(q.length)).minOf { levenshtein(q, it.take(q.length + 1)) }
        return if (d <= maxDist) 300 - d * 50 else 0
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) {
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }
}

/** 5.2 – Bản đồ ô lưới, kiểm tra va chạm O(1). */
class SpatialGridMap {
    private val map = HashMap<Long, Long>()
    private fun key(c: Int, r: Int) = c.toLong() * 100_000L + r

    fun rebuild(list: List<DesktopShortcut>) {
        map.clear(); list.forEach { map[key(it.gridCol, it.gridRow)] = it.id }
    }

    fun isOccupied(c: Int, r: Int, ignoreId: Long = -1): Boolean {
        val o = map[key(c, r)] ?: return false
        return o != ignoreId
    }
}

/** 5.2 – Tìm ô trống gần nhất theo vòng xoắn (vòng vuông mở rộng dần). */
object SpiralSearch {
    fun findFree(col: Int, row: Int, cols: Int, rows: Int, occupied: (Int, Int) -> Boolean): Pair<Int, Int>? {
        val maxR = maxOf(cols, rows)
        for (radius in 0..maxR) {
            for (dc in -radius..radius) for (dr in -radius..radius) {
                if (maxOf(abs(dc), abs(dr)) != radius) continue
                val c = col + dc; val r = row + dr
                if (c in 0 until cols && r in 0 until rows && !occupied(c, r)) return c to r
            }
        }
        return null
    }
}
